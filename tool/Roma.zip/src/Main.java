package src;

import jxl.Sheet;
import jxl.Workbook;
import jxl.read.biff.BiffException;
import jxl.write.Label;
import jxl.write.WritableSheet;
import jxl.write.WritableWorkbook;

import jxl.write.WriteException;
import org.apache.tools.zip.ZipEntry;
import org.apache.tools.zip.ZipFile;
import src.callGraphAnalyze.callgraphAnalysis;
import src.callGraphAnalyze.flowdroid.MySetupApplication;
import org.apache.commons.cli.*;
import org.xmlpull.v1.XmlPullParserException;
import soot.*;
import soot.jimple.infoflow.InfoflowConfiguration;
import soot.jimple.infoflow.android.InfoflowAndroidConfiguration;
import soot.jimple.infoflow.android.SetupApplication;
import soot.jimple.toolkits.callgraph.CallGraph;
import soot.jimple.toolkits.callgraph.Edge;
import src.modelConstruct.TraceConstruction;

import java.io.*;
import java.util.*;

public class Main {
    protected final Options options = new Options();
    private static final String OPTION_APK_FILE = "a";
    private static final String OPTION_PLATFORMS_DIR = "p";
    private static final String OPTION_CALLBACK_FILE = "c";
    private static final String OPTION_SINKS_FILE = "s";
    private static final String OPTION_OUTPUT_DIR = "o";
    private static final String OPTION_INTER_RESULT = "i";

    private String apkFile = "";
    private String apkFileName = "";
    private String platformsDir = "";
    private String callbackFile = "";
    private String sinksFile = "";
    private String outputDir = "";
    private String tempPath = "";
    private boolean hasinterresult = false;

    private InfoflowAndroidConfiguration config;
    private static MySetupApplication setupApplication;

    private static CallGraph callGraph;

    Main(){
        options.addOption(OPTION_APK_FILE, "apkfile", true, "APK file to analyze");
        options.addOption(OPTION_PLATFORMS_DIR, "platformsdir", true, "Path to the platforms directory from the Android SDK");
        options.addOption(OPTION_CALLBACK_FILE, "callbackfile", true, "Definition file for callbacks");
        options.addOption(OPTION_SINKS_FILE, "sinksfile", true, "Definition file for sinks");
        options.addOption(OPTION_OUTPUT_DIR, "outputdir", true, "Path to the output directory");
        options.addOption(OPTION_INTER_RESULT, "hasinterresult", false, "Print the intermediate result");
    }

    public static void main(String[] args) throws IOException, XmlPullParserException, BiffException, WriteException {
        long beginTime = System.currentTimeMillis();
        Main main = new Main();
        main.parseArgs(args);
        main.initSootConfig();
        main.createOutputExcel();
        main.run();

        main.deleteTemps(main.tempPath);
        long finishTime = System.currentTimeMillis();
        double minuteRequired = (finishTime - beginTime) / 1000.0;
        main.recordTime(minuteRequired);
    }

    private void parseArgs(String[] args){
        final HelpFormatter formatter = new HelpFormatter();
        if (args.length == 0) {
            formatter.printHelp("GUIFlow [OPTIONS]", options);
            return;
        }

        // Parse the command-line parameters
        CommandLineParser parser = new DefaultParser();
        final InfoflowAndroidConfiguration config = new InfoflowAndroidConfiguration();
        try {
            CommandLine cmd = parser.parse(options, args);

            // Do we need to display the user manual?
            if (cmd.hasOption("?") || cmd.hasOption("help")) {
                formatter.printHelp("GUIFlow [OPTIONS]", options);
                return;
            }
            apkFile = cmd.getOptionValue(OPTION_APK_FILE);
            if (apkFile == null || apkFile.isEmpty()){
                System.err.println(String.format("Target APK file %s does not exist", apkFile));
                return;
            }
            apkFile = getRealAPkFile(apkFile);

            platformsDir = cmd.getOptionValue(OPTION_PLATFORMS_DIR);
            if (platformsDir == null || platformsDir.isEmpty()) {
                System.err.println(String.format("Platform dir %s does not exist", platformsDir));
                return;
            }

            callbackFile = cmd.getOptionValue(OPTION_CALLBACK_FILE);
            if (callbackFile == null || callbackFile.isEmpty()){
                System.err.println(String.format("Callback file %s does not exist", callbackFile));
                return;
            }

            sinksFile = cmd.getOptionValue(OPTION_SINKS_FILE);
            if (sinksFile == null || sinksFile.isEmpty()){
                System.err.println(String.format("Sinks file %s does not exist", sinksFile));
                return;
            }

            outputDir = cmd.getOptionValue(OPTION_OUTPUT_DIR);
            if (outputDir == null || outputDir.isEmpty()) {
                System.err.println(String.format("Output dir %s does not exist", outputDir));
                return;
            }

            if(cmd.hasOption(OPTION_INTER_RESULT))
                hasinterresult = true;

        } catch (ParseException | IOException e) {
            e.printStackTrace();
        }
    }

    private String getRealAPkFile(String apkFileLocation) throws IOException {
        String realApkFile = apkFileLocation;

        String basePath = apkFileLocation.substring(0, apkFileLocation.lastIndexOf("/"));
        String[] paths = apkFileLocation.split("/");
        apkFileName = paths[paths.length - 1];

        // 旧的文件或目录
        File oldName = new File(apkFileLocation);
        // 新的文件或目录
        String apkFileToZipPath = apkFileLocation;
        if(apkFileName.endsWith(".apk"))
            return realApkFile;
//            apkFileToZipPath = apkFileLocation.substring(0, apkFileLocation.length() - 4) + ".zip";
        if(apkFileName.endsWith(".xapk"))
            apkFileToZipPath = apkFileLocation.substring(0, apkFileLocation.length() - 5) + ".zip";

        if(!apkFileToZipPath.endsWith(".zip"))
            throw new java.io.IOException("The input file " + apkFileLocation + " is not valid");

        File newName = new File(apkFileToZipPath);

        if (newName.exists()) {  //  确保新的文件名不存在
            throw new java.io.IOException("file exists");
        }

        oldName.renameTo(newName);

        tempPath = basePath + "/temp_" + apkFileName + "/";
        File dir = new File(tempPath);
        try {
            ZipFile zipFile = new ZipFile(newName);
            unzip(zipFile, dir);
        } catch (Exception ignored) {
            newName.renameTo(oldName);
            return realApkFile;
        };

        newName.renameTo(oldName);

        for (File file : dir.listFiles()) {
            if((file.getName().endsWith(".apk") || file.getName().endsWith(".xapk")) && file.getName().equals(apkFileName)) {
                realApkFile = file.getPath();
                return realApkFile;
            }
        }
        return realApkFile;
    }

    private void unzip(ZipFile zipFile, File dir) throws IOException {
        if(!dir.exists())
            dir.mkdir();
        int count = -1;
        File file = null;
        InputStream is = null;
        FileOutputStream fos = null;
        BufferedOutputStream bos = null;
        try {
            Enumeration<?> entries = zipFile.getEntries();
            while (entries.hasMoreElements()) {
                byte buf[] = new byte[2048];
                ZipEntry entry = (ZipEntry) entries.nextElement();
                String filename = entry.getName();
                boolean ismkdir = false;
                if (filename.lastIndexOf("/") != -1) { //检查此文件是否带有文件夹
                    ismkdir = true;
                }
                filename = dir.getPath() + "/" + filename;
                if (entry.isDirectory()) { //如果是文件夹先创建
                    file = new File(filename);
                    file.mkdirs();
                    continue;
                }
                file = new File(filename);
                if (!file.exists()) { //如果是目录先创建
                    if (ismkdir) {
                        new File(filename.substring(0, filename.lastIndexOf("/"))).mkdirs(); //目录先创建
                    }
                }
                file.createNewFile(); //创建文件
                is = zipFile.getInputStream(entry);
                fos = new FileOutputStream(file);
                bos = new BufferedOutputStream(fos, 2048);
                while ((count = is.read(buf)) > -1) {
                    bos.write(buf, 0, count);
                }
                bos.flush();
                bos.close();
                fos.close();
                is.close();
            }
            zipFile.close();
        } catch (IOException ioe) {
            throw new java.io.IOException("unzip ["+ apkFile +"] fail");
        } finally {
            try {
                if (bos != null) {
                    bos.close();
                }
                if (fos != null) {
                    fos.close();
                }
                if (is != null) {
                    is.close();
                }
                if (zipFile != null) {
                    zipFile.close();
                }
            } catch (Exception ignored) {
            }
        }
    }

    private SetupApplication initSootConfig() throws IOException, XmlPullParserException {
        String androidJarPath = Scene.v().getAndroidJarPath(platformsDir, apkFile);

        setupApplication = new MySetupApplication(androidJarPath, apkFile);
        config = setupApplication.getConfig();
        config.setCallgraphAlgorithm(InfoflowConfiguration.CallgraphAlgorithm.CHA);
        config.getAnalysisFileConfig().setSourceSinkFile(sinksFile);
        config.setMergeDexFiles(true);
        setupApplication.setCallbackFile(callbackFile);

        setupApplication.constructCallgraph();

        return setupApplication;
    }

    private void createOutputExcel() throws IOException, WriteException, BiffException {
//        File file = new File(outputDir, "result.xls");
//        //create excel if not exist
//        if(!file.exists()) {
//            file.createNewFile();
//            WritableWorkbook workbook = Workbook.createWorkbook(file);
//            //create sheet
//            WritableSheet sheet = workbook.createSheet("result",0);
//            String[] title={"app id", "time", "race1", "race2"};
//            Label label = null;
//            for (int i = 0;i < title.length; ++i){
//                label = new Label(i,0, title[i]);
//                sheet.addCell(label);
//            }
//            workbook.write();
//            workbook.close();
//        }
//        FileInputStream in = new FileInputStream(file);
//        Workbook book = Workbook.getWorkbook(in);
//        WritableWorkbook wbook = Workbook.createWorkbook(file, book);
//        WritableSheet sh = wbook.getSheet(0);
//        int length = sh.getRows();
//        Label label = new Label(0, length, apkFileName);
//        sh.addCell(label);
//        wbook.write();
//        wbook.close();
//        book.close();
        File file1 = new File(outputDir, "tested.txt");
        if(!file1.exists())
            file1.createNewFile();
        String path = file1.getPath();
        writeToFiles(path, apkFileName);
    }

    private void recordTime(double time) throws BiffException, IOException, WriteException {
//        File file = new File(outputDir, "result.xls");
//        FileInputStream in = new FileInputStream(file);
//        Workbook book = Workbook.getWorkbook(in);
//        WritableWorkbook wbook = Workbook.createWorkbook(file, book);
//        WritableSheet sh = wbook.getSheet(0);
//        int length = sh.getRows();
//        Label label = new Label(1, length - 1, String.valueOf(time));
//        sh.addCell(label);
//        wbook.write();
//        wbook.close();
//        book.close();
        File file1 = new File(outputDir, "time.txt");
        if(!file1.exists())
            file1.createNewFile();
        String path = file1.getPath();
        writeToFiles(path, apkFileName + "\t" + time);
    }

    private void run() throws XmlPullParserException, IOException, BiffException, WriteException {
        callgraphAnalysis sourcesSinks = new callgraphAnalysis(setupApplication, outputDir, hasinterresult);
        sourcesSinks.analyzeCallGraph();
        TraceConstruction traceConstruction = new TraceConstruction(setupApplication, sourcesSinks.getCallGraph(), sourcesSinks.getWidgetInfo(), sourcesSinks.getRealVUISources(), outputDir);
        traceConstruction.constructAndCheckExecutionTrace();
    }

    private void deleteTemps(String path) {
        File dir = new File(path);
        if(dir.isDirectory()) {
            for(File file: dir.listFiles()) {
                if(file.isDirectory())
                    deleteTemps(file.getPath());
                else
                    file.delete();
            }
        }
        dir.delete();
    }

    private void writeToFiles(String fileName, String line) throws IOException {
        File file = new File(fileName);
        if(!file.exists())
            file.createNewFile();
        FileWriter fw = new FileWriter(fileName, true);
        PrintWriter pw = new PrintWriter(fw);
        pw.println(line);
        pw.flush();
        pw.close();
        fw.close();
    }

}
