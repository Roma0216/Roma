package src.Solver;

import com.microsoft.z3.*;
import monosat.Graph;
import monosat.Lit;
import soot.util.HashMultiMap;
import soot.util.MultiMap;
import src.modelConstruct.ExecutionTrace;
import src.modelConstruct.element.*;

import javax.sound.sampled.FloatControl;
import java.util.*;
import java.util.stream.Collectors;

import static monosat.Logic.assertTrue;

public class CheckExecutionTrace {
    private final ExecutionTrace executionTrace;
    Map<RealExpr, Instruction> ExprToIns = new HashMap<>();
    Map<Instruction, RealExpr> InsToExpr = new HashMap<>();
    private final Set<RealExpr> exprs = new HashSet<>();
    private final Context ctx;
    private final Solver solver;

    private RealExpr postVUIExpr;
    private RealExpr postGUIExpr;
    private RealExpr VSinkExpr;
    private RealExpr GSinkExpr;


    private static int times = 0;

    public CheckExecutionTrace(ExecutionTrace executionTrace, boolean isVUIbeforeGUI) {//, Graph graph, Map<Integer, Instruction> nodeToIns, int VSink, int GSink) {
        System.out.println("---------------------------start adding constraints");
        if(isVUIbeforeGUI) {
            System.out.println(executionTrace);
            ++times;
        }
        this.executionTrace = executionTrace;
        Map<Integer, List<Instruction>> traces = executionTrace.getTraces();
        Map<Integer, List<Instruction>> tasks = executionTrace.getTasks();

        HashMap<String, String> cfg = new HashMap<>();
        ctx = new Context(cfg);
        solver = ctx.mkSolver();

        //Create exprs
        Map<Instruction, RealExpr> InsToExpr = new HashMap<>();
        for(int threadId: traces.keySet())
            createNodes(traces.get(threadId));
        for(int taskId: tasks.keySet())
            createNodes(tasks.get(taskId));

        //add constraints
        addConstraints();

        if(isVUIbeforeGUI) {
            solver.add(ctx.mkLt(postVUIExpr, postGUIExpr));
            solver.add(ctx.mkGt(VSinkExpr, GSinkExpr));
        }
        else {
            solver.add(ctx.mkLt(postGUIExpr, postVUIExpr));
            solver.add(ctx.mkGt(GSinkExpr, VSinkExpr));
        }
        System.out.println("---------------------------end adding constraints");
    }

    public static int getTimes() {
        return times;
    }

    private void createNodes(List<Instruction> instructions) {
        int base = exprs.size();
        for(int i = 0; i < instructions.size(); ++i) {
            Instruction ins = instructions.get(i);
            RealExpr expr = ctx.mkRealConst(ins + "_" + (base + i));
            exprs.add(expr);
            ExprToIns.put(expr, ins);
            InsToExpr.put(ins, expr);
            if(ins instanceof ExecuteTask && ins.isMainThread())
                solver.add(ctx.mkEq(expr, ctx.mkReal(0)));
            else if(ins.equals(executionTrace.getPostTaskG()) || ins.equals(executionTrace.getPostTaskV())) {
                solver.add(ctx.mkGt(expr, ctx.mkReal(0))); //postG/V < begin(main, xxx) or postG/V > end(main, xxx)
                if(ins.equals(executionTrace.getPostTaskG()))
                    postGUIExpr = expr;
                if(ins.equals(executionTrace.getPostTaskV()))
                    postVUIExpr = expr;
            }
            else {
                solver.add(ctx.mkGt(expr, ctx.mkReal(0)));
                if (ins instanceof VUIsink)
                    VSinkExpr = expr;
                if (ins instanceof GUIsink)
                    GSinkExpr = expr;
            }
        }
    }

    private void addConstraints() {
        Map<Integer, List<Instruction>> tasks = executionTrace.getTasks();
        for(int taskId: tasks.keySet()) {
            List<Instruction> task = tasks.get(taskId);
            if(task.get(0).isMainThread()) {
                TaskBegin taskBegin = (TaskBegin) task.get(0);
                TaskEnd taskEnd = (TaskEnd) task.get(task.size() - 1);
                solver.add(ctx.mkOr(ctx.mkLt(postGUIExpr, InsToExpr.get(taskBegin)), ctx.mkGt(postGUIExpr, InsToExpr.get(taskEnd))));
                solver.add(ctx.mkOr(ctx.mkLt(postVUIExpr, InsToExpr.get(taskBegin)), ctx.mkGt(postVUIExpr, InsToExpr.get(taskEnd))));
            }
        }

        check_NO_Q_PO();
        check_ASYNC_PO();
        check_POST();
        check_FIFO();
        check_FORK();
        check_JOIN();
        check_DISABLE();
        check_LOCK();
    }

    private void check_NO_Q_PO() {
        Map<Integer, List<Instruction>> traces = executionTrace.getTraces();
        for(int threadId: traces.keySet()) {
            List<Instruction> trace = traces.get(threadId);
            RealExpr preExpr = InsToExpr.get(trace.get(0));
            for(int i = 1; i < trace.size(); ++i) {
                if(trace.get(i - 1) instanceof ExecuteTask)
                    break;
                RealExpr currentExpr = InsToExpr.get(trace.get(i));
                solver.add(ctx.mkLt(preExpr, currentExpr));
//                System.out.println("add constraint " + trace.get(i - 1) + " < " + trace.get(i));
                preExpr = currentExpr;
            }
        }
    }

    private void check_ASYNC_PO() {
        Map<Integer, List<Instruction>> tasks = executionTrace.getTasks();
        for(int taskId: tasks.keySet()) {
            List<Instruction> task = tasks.get(taskId);
            RealExpr preExpr = InsToExpr.get(task.get(0));
            for(int i = 1; i < task.size(); ++i) {
                RealExpr currentExpr = InsToExpr.get(task.get(i));
                solver.add(ctx.mkLt(preExpr, currentExpr));
//                System.out.println("add constraint " + task.get(i - 1) + " < " + task.get(i));
                preExpr = currentExpr;
            }
        }
    }

    private void check_POST() {
        Map<Integer, List<Instruction>> traces = executionTrace.getTraces();
        for(int threadId: traces.keySet()) {
            List<Instruction> trace = traces.get(threadId);
            for(Instruction ins: trace) {
                if(ins instanceof PostTask) {
                    RealExpr postExpr = InsToExpr.get(ins);
                    List<Instruction> taskRelateToPost = executionTrace.getTaskByPost((PostTask) ins);
                    if(taskRelateToPost.size() >= 1) {
                        Instruction taskBegin = taskRelateToPost.get(0);
                        RealExpr beginExpr = InsToExpr.get(taskBegin);
                        solver.add(ctx.mkLt(postExpr, beginExpr));
//                        System.out.println("add constraint " + ins + " < " + taskBegin);
                    }
                }
            }
        }
    }

    private void check_FORK() {
        Map<Integer, List<Instruction>> tasks = executionTrace.getTasks();
        for(int taskId: tasks.keySet()) {
            List<Instruction> task = tasks.get(taskId);
            for(Instruction ins: task) {
                if(ins instanceof Fork) {
                    Fork fork = (Fork) ins;
                    ThreadBegin init = executionTrace.getThreadInitByFork(fork);
                    if(init != null) {
                        RealExpr forkExpr = InsToExpr.get(fork);
                        RealExpr initExpr = InsToExpr.get(init);
                        solver.add(ctx.mkLt(forkExpr, initExpr));
//                        System.out.println("add constraint " + fork + " < " + init);
                    }
                }
            }
        }
    }

    private void check_JOIN() {
        Map<Integer, List<Instruction>> tasks = executionTrace.getTasks();
        for(int taskId: tasks.keySet()) {
            List<Instruction> task = tasks.get(taskId);
            for(Instruction ins: task) {
                if(ins instanceof Join) {
                    Join join = (Join) ins;
                    ThreadEnd exit = executionTrace.getThreadEndByJoin(join);
                    if(exit != null) {
                        RealExpr exitExpr = InsToExpr.get(exit);
                        RealExpr joinExpr = InsToExpr.get(join);
                        solver.add(ctx.mkLt(exitExpr, joinExpr));
//                        System.out.println("add constraint " + exit + " < " + join);
                    }
                }
            }
        }
    }

    private void check_FIFO() {
//        Lit l = graph.addEdge(postTaskV, postTaskG);
//        if(solver.solve()) {
//            System.out.println(l.value());
//        }
        MultiMap<Integer, Instruction> threadIdToPosts = executionTrace.getPostsToSameThreads();
        for(int threadId: threadIdToPosts.keySet()) {
            ArrayList<Instruction> postTasks = new ArrayList<>(threadIdToPosts.get(threadId));
            //System.out.println(instructions);
            for(int i = 0; i < postTasks.size() - 1; ++i) {
                Instruction post1 = postTasks.get(i);
                RealExpr postExpr1 = InsToExpr.get(post1);
                List<Instruction> taskOfPost1 = executionTrace.getTaskByPost((PostTask) post1);
                if(taskOfPost1.size() == 0)
                    continue;
                RealExpr begin1 = InsToExpr.get(taskOfPost1.get(0));
                RealExpr end1 = InsToExpr.get(taskOfPost1.get(taskOfPost1.size() - 1));
                for(int j = i + 1; j < postTasks.size(); ++j) {
                    Instruction post2 = postTasks.get(j);
                    RealExpr postExpr2 = InsToExpr.get(post2);
                    List<Instruction> taskOfPost2 = executionTrace.getTaskByPost((PostTask) post2);
                    if(taskOfPost2.size() == 0)
                        continue;
                    RealExpr begin2 = InsToExpr.get(taskOfPost2.get(0));
                    RealExpr end2 = InsToExpr.get(taskOfPost2.get(taskOfPost2.size() - 1));

                    solver.add(ctx.mkOr(ctx.mkGt(postExpr1, postExpr2), ctx.mkLt(end1, begin2)));
//                    System.out.println("add constraint (" + post1 + " > " + post2 + " or " + taskOfPost1.get(taskOfPost1.size() - 1) + " < " + taskOfPost2.get(0) + ")");

                    solver.add(ctx.mkOr(ctx.mkGt(postExpr2, postExpr1), ctx.mkLt(end2, begin1)));
//                    System.out.println("add constraint (" + post2 + " > " + post1 + " or " + taskOfPost2.get(taskOfPost2.size() - 1) + " < " + taskOfPost1.get(0) + ")");
                }
            }
        }
    }

    private void check_DISABLE() {
        List<Instruction> disables = executionTrace.getInsByType(Instruction.Type.DISABLE);
        List<Instruction> enables = executionTrace.getInsByType(Instruction.Type.ENABLE);
        if(disables.size() == 0) {
            return;
        }
        if(disables.size() != enables.size()) {
            System.out.println("Num of acquire does not equal num of release");
            System.exit(-1);
        }

        Disable disable = (Disable) disables.get(0);
        Enable enable = (Enable) enables.get(0);
        if(disable.getTaskId() != enable.getTaskId())
            return;
        List<Instruction> disabledTask = executionTrace.getTaskByTaskId(disable.getTaskId());
        TaskBegin taskBeginOfDisabledTask = (TaskBegin) disabledTask.get(0);
        TaskEnd taskEndOfDisabledTask = (TaskEnd) disabledTask.get(disabledTask.size() - 1);
        RealExpr disableExpr = InsToExpr.get(disable);
        RealExpr enableExpr = InsToExpr.get(enable);
        RealExpr beginExpr = InsToExpr.get(taskBeginOfDisabledTask);
        RealExpr endExpr = InsToExpr.get(taskEndOfDisabledTask);
        solver.add(ctx.mkOr(ctx.mkLt(endExpr, disableExpr), ctx.mkLt(enableExpr, beginExpr)));
//        System.out.println("add constraint (" + taskEndOfDisabledTask + " < " + disable + " or " + enable + " < " + taskBeginOfDisabledTask + ")");
    }

    private void check_LOCK() {
        List<Instruction> locks = executionTrace.getInsByType(Instruction.Type.LOCK);
        List<Instruction> unlocks = executionTrace.getInsByType(Instruction.Type.UNLOCK);
//        Map<Lock, Map<Lock, Lit>> Locks_To_Lit = new HashMap<>();
        if(locks.size() < 2) {
            return;
        }
        if(locks.size() != unlocks.size()) {
            System.out.println("The size of lock does not equal the size of unlock.");
            System.exit(-1);
        }

        for(int i = 0; i < locks.size(); ++i) {
            Lock lock1 = (Lock) locks.get(i);
            Unlock unlock1 = lock1.getUnlockPair();
            RealExpr lock1Expr = InsToExpr.get(lock1);
            RealExpr unlockExpr1 = InsToExpr.get(unlock1);
            for(int j = i + 1; j < locks.size(); ++j) {
                Lock lock2 = (Lock) locks.get(j);
                Unlock unlock2 = lock2.getUnlockPair();
                RealExpr lock2Expr = InsToExpr.get(lock2);
                RealExpr unlockExpr2 = InsToExpr.get(unlock2);
                solver.add(ctx.mkOr(ctx.mkLt(unlockExpr2, lock1Expr), ctx.mkLt(unlockExpr1, lock2Expr))); // add unlock2 < lock1 or unlock1 < lock2
            }
        }
    }

    public int check() {
        Status result = solver.check();
        if(result == Status.SATISFIABLE) {
            System.out.println("---------------------------start finding counterexample");
            System.out.println("Counterexample: ");
            Model model = solver.getModel();
            MultiMap<Integer, Instruction> valueToIns = new HashMultiMap<>();
            for(RealExpr expr: exprs) {
                Expr expr_value = model.eval(expr, false);
                if(!(expr_value instanceof RatNum)) {
                    throw new RuntimeException(expr_value + " is not a RatNum!");
                }
                RatNum ratNum = (RatNum) expr_value;
//                System.out.print(expr + ": ");
                int value = ratNum.getNumerator().getInt();
//                System.out.println(value);
                valueToIns.put(value, ExprToIns.get(expr));
            }
            List<Integer> keys = valueToIns.keySet().stream().sorted().collect(Collectors.toList());
            for(int value: keys) {
                for(Instruction ins: valueToIns.get(value))
                    System.out.println(ins);
            }
            System.out.println("---------------------------end finding counterexample");
            return 1;
        } else {
            System.out.println("unsatisfiable");
            return 0;
        }
    }
}
