package src.modelConstruct;

import soot.util.HashMultiMap;
import src.modelConstruct.element.*;
import src.modelConstruct.element.Instruction.Type;
import soot.util.MultiMap;

import java.util.*;

public class ExecutionTrace {
    private Map<Integer, List<Instruction>> tasks = new HashMap<>();
    private Map<Integer, List<Instruction>> traces = new HashMap<>();
    Instruction postTaskV = null;
    Instruction postTaskG = null;

    public ExecutionTrace() {
        //test();
    }

    public void addTask(List<Instruction> task) {
        if(task.size() <= 0)
            return;
        Instruction instruction = task.get(0);
        if(instruction instanceof TaskBegin) {
            TaskBegin taskBeginIns = (TaskBegin) instruction;
            int taskId = taskBeginIns.getTask();
            tasks.put(taskId, task);
        }
    }

    public void deleteTask(int taskId) {
        tasks.remove(taskId);
    }

    public List<Instruction> getTaskByTaskId(int id) {
        List<Instruction> res =  tasks.get(id);
        return (res == null) ? new LinkedList<>() : res;
    }

    public void addTrace(List<Instruction> trace) {
        if(trace.size() <= 0)
            return;
        Instruction instruction = trace.get(0);
        int thread = instruction.getCurrentThread();
        traces.put(thread, trace);
        return;
    }

    public void deleteTrace(int threadId) {
        traces.remove(threadId);
    }

    public List<Instruction> getTraceByThreadId(int id) {
        List<Instruction> res = traces.get(id);
        return (res == null) ? new LinkedList<>() : res;
    }

    public Map<Integer, List<Instruction>> getTasks() {
        return tasks;
    }

    public Map<Integer, List<Instruction>> getTraces() {
        return traces;
    }

//    public Instruction getPostByTask(int taskId) {
//        for(int threadId: traces.keySet()) {
//            List<Instruction> trace = traces.get(threadId);
//            for(Instruction ins: trace) {
//                if(ins instanceof PostTask && ((PostTask) ins).getTask() == taskId)
//                    return ins;
//            }
//        }
//        System.out.println("cannot find correspond task of task " + taskId);
//        return null;
//    }

    public List<Instruction> getInsByType(Type type) {
        List<Instruction> results = new LinkedList<>();
        if(type == Type.THREADBEGIN || type == Type.THREADEND || type == Type.EXECUTETASK || type == Type.POST || type == Type.ALL) {
            for(int threadId: traces.keySet()) {
                List<Instruction> trace = traces.get(threadId);
                for(Instruction ins: trace) {
                    if(ins.getType().equals(type) || type == Type.ALL)
                        results.add(ins);
                }
            }
        }
        if(type != Type.THREADBEGIN && type != Type.THREADEND && type != Type.EXECUTETASK && type != Type.POST){
            for(int taskId: tasks.keySet()) {
                List<Instruction> task = tasks.get(taskId);
                for(Instruction ins: task) {
                    if(ins.getType().equals(type) || type == Type.ALL)
                        results.add(ins);
                }
            }
        }
        return results;
    }

    public List<Instruction> getTaskByPost(PostTask postTask) {
        int taskId = postTask.getTask();
        return getTaskByTaskId(taskId);
    }

    public MultiMap<Integer, Instruction> getPostsToSameThreads() {
        MultiMap<Integer, Instruction> threadIdToPosts = new HashMultiMap<>();
        for(int threadId: traces.keySet()) {
            List<Instruction> trace = traces.get(threadId);
            for(Instruction ins: trace) {
                if(ins instanceof PostTask) {
                    PostTask postTask = (PostTask) ins;
                    threadIdToPosts.put(postTask.getTargetThread(), postTask);
                }
            }
        }
        //post can also be in tasks
        for(int taskId: tasks.keySet()) {
            List<Instruction> task = tasks.get(taskId);
            for(Instruction ins: task) {
                if(ins instanceof PostTask) {
                    PostTask postTask = (PostTask) ins;
                    threadIdToPosts.put(postTask.getTargetThread(), postTask);
                }
            }
        }
        return threadIdToPosts;
    }

    public ThreadBegin getThreadInitByFork(Fork fork) {
        int targetThread = fork.getChildThread();
        List<Instruction> instructions = getTraceByThreadId(targetThread);
        for(Instruction ins: instructions) {
            if(ins instanceof ThreadBegin)
                return (ThreadBegin) ins;
        }
        return null;
    }

    public ThreadEnd getThreadEndByJoin(Join join) {
        int targetThread = join.getChildThread();
        List<Instruction> instructions = getTraceByThreadId(targetThread);
        for(Instruction ins: instructions) {
            if(ins instanceof ThreadEnd)
                return (ThreadEnd) ins;
        }
        return null;
    }

    public void setPostTaskV(Instruction ins) {
        postTaskV = ins;
    }

    public void setPostTaskG(Instruction ins) {
        postTaskG = ins;
    }

    public Instruction getPostTaskV() {
        return postTaskV;
    }

    public Instruction getPostTaskG() {
        return postTaskG;
    }


    public String toString() {
        StringBuilder res = new StringBuilder();
        for(int threadId: traces.keySet()) {
            res.append("Thread ");
            if(threadId == 0)
                res.append("main");
            else if(threadId == 1)
                res.append("server");
            else
                res.append(threadId);
            res.append(" has trace: \n");
            for(Instruction ins : traces.get(threadId))
                res.append("\t").append(ins).append("\n");
        }

        for(int taskId: tasks.keySet()) {
            res.append("Task ").append(taskId).append(" has body: \n");
            for(Instruction ins : tasks.get(taskId))
                res.append("\t").append(ins).append("\n");
        }
        return res.toString();
    }
}
