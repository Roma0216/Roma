package src.modelConstruct;

import javafx.util.Pair;
import jxl.read.biff.BiffException;
import jxl.write.WriteException;
import soot.*;
import soot.jimple.Stmt;
import soot.jimple.StringConstant;
import soot.jimple.infoflow.android.callbacks.AbstractCallbackAnalyzer;
import soot.jimple.infoflow.android.resources.ARSCFileParser;
import soot.jimple.toolkits.callgraph.Edge;
import src.Solver.CheckExecutionTrace;
import src.callGraphAnalyze.element.WidgetInfo;
import src.callGraphAnalyze.element.myCallgraph;
import src.callGraphAnalyze.element.sourcesink.*;
import src.callGraphAnalyze.flowdroid.MySetupApplication;
import src.modelConstruct.element.*;

import java.io.*;
import java.util.*;

public class TraceConstruction {

    private final myCallgraph callgraph;
    private final Set<VUISource> realVUISources;

    private final WidgetInfo widgetInfo;
    private final AbstractCallbackAnalyzer jimpleClass;
    private final ARSCFileParser resources;

    private String apkFileName = "";
    private String outputDir = "";

    private ExecutionTrace executionTrace;

    private final int mainThread = 0;
    private final int remoteServer = 1;
    private final int VUIThread = 2;
    private int startListeningThread = 4;
    private int VUIsinkTaskThread = 5;
    private final int AsrThread = 6;
    private final int callStartListeningThread = 7;

    private int currentTask = 1;
    private int VUIstartTask = -1;
    private int VUIsinkTask = -1;
    private int GUITask = -1;
    private Set<PostTask> postTasks;

    private final int currentLock = 1;

    private List<Instruction> mainThreadTrace;
    private List<Instruction> remoteServerTrace;
    private List<Instruction> VUIThreadTrace = null;
    private List<Instruction> GUIThreadTrace = null;
    private List<Instruction> startListeningThreadTrace = null;
    private List<Instruction> VUIsinkTaskThreadTrace = null;
    private List<Instruction> AsrThreadTrace = null;
    private List<Instruction> callStartListeningTrace = null;

    private Set<Integer> VUIstartTaskIds = null;
    private Set<Integer> VUIsinkTaskIds = null;

    private Map<Object, Map<Object, Map<Object, Map<Object, Integer>>>> tempRes;
    private boolean addToStartDialog = false;
    private boolean addToHasLock = false;

    private boolean hasLockOnVUIStartTask = false;
    private boolean hasLockOnVUISinkTask = false;
    private boolean hasLockOnGUISinkTask = false;


    public TraceConstruction(MySetupApplication setupApplication, myCallgraph cg, WidgetInfo widInfo, Set<VUISource> realVS, String outDir) {
        callgraph = cg;
        realVUISources = realVS;

        widgetInfo = widInfo;
        jimpleClass = setupApplication.getJimpleClass();
        resources = setupApplication.getResources();

        String jsonFileName = widgetInfo.getJsonFileName();
        apkFileName = jsonFileName.substring(0, jsonFileName.length() - 5);
        outputDir = outDir;
    }

    public void constructAndCheckExecutionTrace() throws IOException, BiffException, WriteException {
        step2();
        System.out.println("Check times: " + CheckExecutionTrace.getTimes());
    }

    private void step2() throws IOException, BiffException, WriteException {
        boolean hasRace = false;

        tempRes = new HashMap<>();

        for(VUISource realVUISource: realVUISources) {
            VUIstartTask = -1;
            if(realVUISource.getGUIHiddenSource().isEmpty() && realVUISource.getGUINormalSource().isEmpty() && realVUISource.getPossibleGUINormalSource().isEmpty() && !realVUISource.method().getName().equals("onActivityResult"))
                continue;
            //given onResults, find: from onClick -> startListening
            System.out.println("The current VUI source is: " + realVUISource.method());
            List<Set<String>> conflictGUISources = constructAndCheck(realVUISource);
            if(conflictGUISources.get(0).isEmpty() && conflictGUISources.get(1).isEmpty())
                System.out.println("success in disabling conflicts");
            else {
                System.out.print("RESULT: \n");
                if(!conflictGUISources.get(0).isEmpty()) {
                    System.out.print("VUI source " + realVUISource.method() + " has input conflicts with GUI sources: ");
                    System.out.println(conflictGUISources.get(0));
                }
                if(!conflictGUISources.get(1).isEmpty()) {
                    System.out.print("VUI source " + realVUISource.method() + " might have input conflicts with GUI sources: ");
                    System.out.println(conflictGUISources.get(1));
                }
                hasRace = true;
            }
        }

        if(hasRace) {
            File file1 = new File(outputDir, "apksWithRace(step2).txt");
            if(!file1.exists())
                file1.createNewFile();
            String apkFileNameAfterStep2 = file1.getPath();
            writeToFiles(apkFileNameAfterStep2, apkFileName);
        } else {
            File file2 = new File(outputDir, "apksWithoutRace(step2).txt");
            if(!file2.exists())
                file2.createNewFile();
            String apkFileNameAfterStep2 = file2.getPath();
            writeToFiles(apkFileNameAfterStep2, apkFileName);
            System.out.println("RESULT: no conflict");
        }
        tempRes = null;
    }

    private List<Set<String>> constructAndCheck(VUISource realVUISource) throws IOException {
        executionTrace = new ExecutionTrace();

        Set<Source> guiNorSources = realVUISource.getGUINormalSource();
        Set<Source> possibleGUINorSources = realVUISource.getPossibleGUINormalSource();
        Set<Stmt> guiHidSources = realVUISource.getGUIHiddenSource();
        List<List<Pair<ISourceSink, Integer>>> vuiSourceTraces = realVUISource.getVUISourceTrace();
        List<Set<String>> conflictGUISources = new LinkedList<>();
        conflictGUISources.add(new HashSet<>());
        conflictGUISources.add(new HashSet<>());
        int preTaskId1 = -1;
        int preTaskId2 = -1;

//        if(realVUISource.getSubSignature().equals("void onActivityResult(int,int,android.content.Intent)") || vuiCallLists.size() == 0)
        if(vuiSourceTraces.size() == 0)
            return conflictGUISources;

        //for huawei, alibaba, the VUIsinkTask may not be executed in mainThread
        //for microsoft, the VUIsinkTask is not a callback
        String subsig = realVUISource.getSubSignature();
        List<Pair<ISourceSink, Integer>> vuiSourceTrace0 = vuiSourceTraces.get(0);
        int sdkId = getSdkAndVUIsinkTaskThread(subsig, vuiSourceTrace0);

        addMainThread();
        addRemoteServer(sdkId);

        for(List<Pair<ISourceSink, Integer>> vuiSourceTrace: vuiSourceTraces) {

            System.out.println("The VUI source is called by clicking " + vuiSourceTrace.get(0).getKey().method());
            if(realVUISource.getLayoutFiles().isEmpty()) {
                System.out.println("WARNING: The layoutFile of that VUI button is not found!");
            }

            // begin add VUI start task---------------------------------------------------------
            preTaskId1 = currentTask;
            VUIstartTaskIds = new HashSet<>();

            //may have Disable
            boolean noDisableOnVUIStartTrace = true;
            boolean startDialog = false;
            if(sdkId < 6) {
                if(sdkId == 0)
                    startDialog = true;
                else
                    startDialog = startDialogOnVUISourceTrace(vuiSourceTrace);
                if(startDialog)
                    noDisableOnVUIStartTrace = false;
            }
            boolean startListeningInSameTask = addVUIStartTask(sdkId, vuiSourceTrace, noDisableOnVUIStartTrace);//, layoutFiles2);

            // begin add VUI sink task----------------------------------------------------------
            preTaskId2 = currentTask;
            VUIsinkTaskIds = new HashSet<>();
            Set<List<Pair<ISourceSink, Integer>>> VUISinkTraces = realVUISource.getSinkTraces();
            for(List<Pair<ISourceSink, Integer>> vuiSinkTrace: VUISinkTraces) {
                ISourceSink sink = vuiSinkTrace.get(vuiSinkTrace.size() - 1).getKey();
                if(!(sink instanceof VUISink))
                    continue;
                boolean VUIsinkInSameTask = addVUISinkTask(sdkId, vuiSinkTrace, noDisableOnVUIStartTrace);

                // begin add GUI task-----------------------------------------------------
                conflictGUISources.get(0).addAll(addGUINormalSourceAndCheck(guiNorSources, noDisableOnVUIStartTrace, startListeningInSameTask, VUIsinkInSameTask, vuiSourceTrace, vuiSinkTrace));
                conflictGUISources.get(0).addAll(addGUIHiddenSourceAndCheck(guiHidSources, noDisableOnVUIStartTrace, startListeningInSameTask, VUIsinkInSameTask, vuiSourceTrace, vuiSinkTrace));
                conflictGUISources.get(1).addAll(addGUINormalSourceAndCheck(possibleGUINorSources, noDisableOnVUIStartTrace, startListeningInSameTask, VUIsinkInSameTask, vuiSourceTrace, vuiSinkTrace));

                if(conflictGUISources.get(0).isEmpty() && conflictGUISources.get(1).isEmpty() && !addToStartDialog) {
                    if(startDialog) {
                        File file = new File(outputDir, "withoutRace_startDialog.txt");
                        if(!file.exists())
                            file.createNewFile();
                        String apkFileNameForStartDialog = file.getPath();
                        writeToFiles(apkFileNameForStartDialog, apkFileName);
                        addToStartDialog = true;
                    }
                }
                // end add GUI task-------------------------------------------------------


                for (int taskId : VUIsinkTaskIds) {
                    if(taskId == VUIsinkTask) {
                        if(sdkId < 6)
                            executionTrace.deleteTask(taskId);
                    } else
                        executionTrace.deleteTask(taskId);
                }
                VUIsinkTaskIds.clear();

                if(VUIsinkTaskThreadTrace != null) {
                    VUIsinkTaskThreadTrace = null;
                    executionTrace.deleteTrace(VUIsinkTaskThread);
                }

                if(VUIThreadTrace != null) {
                    VUIThreadTrace = null;
                    executionTrace.deleteTrace(VUIThread);
                }
                currentTask = preTaskId2;
            }
            VUIsinkTaskIds = null;
            // end add VUI sink task------------------------------------------------------------

            for(int taskId: VUIstartTaskIds)
                executionTrace.deleteTask(taskId);
            VUIstartTaskIds = null;

            if(AsrThreadTrace != null) {
                AsrThreadTrace = null;
                executionTrace.deleteTrace(AsrThread);
            }

            if(startListeningThreadTrace != null) {
                startListeningThreadTrace = null;
                executionTrace.deleteTrace(startListeningThread);
            }

            if(callStartListeningTrace != null) {
                callStartListeningTrace = null;
                executionTrace.deleteTrace(callStartListeningThread);
            }
            currentTask = preTaskId1;
            // end add VUI start task-----------------------------------------------------------
        }

        removeMainThreadAndRemoteServer();

        executionTrace = null;
        return conflictGUISources;
    }

    private void addMainThread() {
        //add main thread
        //add PostTask(main, pv, main)
        mainThreadTrace = new LinkedList<>();
        postTasks = new HashSet<>();
        mainThreadTrace.add(new ExecuteTask(mainThread));

        VUIstartTask = currentTask;
        ++currentTask;
        PostTask postVUIStart = new PostTask(mainThread, VUIstartTask, mainThread);
        mainThreadTrace.add(postVUIStart);
        executionTrace.setPostTaskV(postVUIStart);
        postTasks.add(postVUIStart);

        //add PostTask(main, pg, main)
        GUITask = currentTask;
        ++currentTask;
        PostTask postGUI = new PostTask(mainThread, GUITask, mainThread);
        mainThreadTrace.add(postGUI);
        executionTrace.setPostTaskG(postGUI);
        postTasks.add(postGUI);

        executionTrace.addTrace(mainThreadTrace);
    }

    private void addRemoteServer(int sdkId) {
        //add remote server thread
        remoteServerTrace = new LinkedList<>();
        remoteServerTrace.add(new ThreadBegin(remoteServer));

        //TODO: add SpeechToText()
        if(sdkId < 6) {
            VUIsinkTask = currentTask;
            PostTask postVUIsink = new PostTask(remoteServer, VUIsinkTask, VUIsinkTaskThread);
            remoteServerTrace.add(postVUIsink);
            postTasks.add(postVUIsink);
            ++currentTask;
        }
        remoteServerTrace.add(new ThreadEnd(remoteServer));
        executionTrace.addTrace(remoteServerTrace);
    }

    private void removeMainThreadAndRemoteServer() {
        executionTrace.deleteTrace(mainThread);
        executionTrace.deleteTrace(remoteServer);
        mainThreadTrace = null;
        remoteServerTrace = null;
        postTasks = null;
        currentTask = 1;
    }

    private int getSdkAndVUIsinkTaskThread(String subsig, List<Pair<ISourceSink, Integer>> vuiSourceTrace) {
        //get the thread for onResults
        int sdkId = -1;
        ISourceSink startListening = vuiSourceTrace.get(vuiSourceTrace.size() - 1).getKey();
        boolean inMain = true;
        for(Pair<ISourceSink, Integer> method: vuiSourceTrace) {
            String methodName = method.getKey().method().getName();
            if(methodName.equals("postDelayed") || methodName.equals("post") || methodName.equals("runOnUiThread")) {
                inMain = true;
                break;
            }
            if(methodName.equals("run") || methodName.equals("doInBackground")) {
                inMain = false;
                break;
            }
        }
        startListening.setInMainThread(inMain);
        switch (subsig) {
            case "void onActivityResult(int,int,android.content.Intent)":
                //google sdk1
                sdkId = 0;
                VUIsinkTaskThread = mainThread;
                break;
            case "void onResults(android.os.Bundle)":
            case "void onPartialResults(android.os.Bundle)":
                if(startListening.method().getDeclaringClass().toString().equals("com.huawei.hiai.asr.AsrRecognizer")) {
                    // huawei, onResults in the same thread as startListening
                    sdkId = 1;
                    if(inMain)
                        VUIsinkTaskThread = mainThread;
                } else {
                    //google sdk2
                    sdkId = 2;
                    VUIsinkTaskThread = mainThread;
                }
                break;
            case "void onEvent(java.lang.String,java.lang.String,byte[],int,int)":
            case "void onAsrFinalResult(java.lang.String[],com.baidu.aip.asrwakeup3.core.recog.RecogResult)":
                //baidu, onEvent must be in main
                sdkId = 3;
                VUIsinkTaskThread = mainThread;
                break;
            case "void onNuiEventCallback(com.alibaba.idst.nui.Constants$NuiEvent,int,int,com.alibaba.idst.nui.KwsResult,com.alibaba.idst.nui.AsrResult)":
                //alibaba, onNuiEventCallback in the same thread as startDialog
                sdkId = 4;
                if(inMain)
                    VUIsinkTaskThread = mainThread;
                break;
            case "void onSuccess(com.tencent.aai.model.AudioRecognizeRequest,java.lang.String)":
            case "void onSegmentSuccess(com.tencent.aai.model.AudioRecognizeRequest,com.tencent.aai.model.AudioRecognizeResult,int)":
            case "void onSliceSuccess(com.tencent.aai.model.AudioRecognizeRequest,com.tencent.aai.model.AudioRecognizeResult,int)":
                //tencent
                sdkId = 5;
                //VUIsinkTaskThread runs on the sdk thread initialized by tencent, set as 5
                break;
            case "java.lang.String toString()":
                sdkId = 6;
                break;
        }
        return sdkId;
    }

    private boolean addVUIStartTask(int sdkId, List<Pair<ISourceSink, Integer>> vuiSourceTrace, boolean noDisableOnVUIStartTrace) throws IOException { //}, MultiMap<String, String> layoutFiles2) {
        boolean startListeningInSameTask = true;

        hasLockOnVUIStartTask = hasLock(vuiSourceTrace);

        List<Instruction> task = new LinkedList<>();
        task.add(new TaskBegin(mainThread, VUIstartTask));

        if(sdkId < 6) {
            // not previously tested
            if(!noDisableOnVUIStartTrace) {
                task.add(new Disable(mainThread, GUITask));
                System.out.println("Dialog started on this VUI source trace");
            } else {
                System.out.println("No dialog started on this VUI source trace");
            }
        }

        //get the thread for startListening
        getStartListeningThread(sdkId, vuiSourceTrace);

        int startListeningPlace = 0; //0: this task in main thread, 1: another thread, 2: another task in main thread
        int startListeningTaskId = -1;
        List<Instruction> startListeningTask = null;
        boolean addLock = false;
        boolean addUnlock = false;
        boolean addLock2 = false;
        boolean addUnlock2 = false;
        int addLockPlace = -1;
        int addLockPlace2 = -1;
        Lock addedLock = null;
        Lock addedLock2 = null;
        for(Pair<ISourceSink, Integer> sourceSink: vuiSourceTrace) {
            ISourceSink srcSink = sourceSink.getKey();
            if(!addLock && srcSink.isLocked()) {
                addLock = true;
                if(startListeningPlace == 0) {
                    addedLock = new Lock(mainThread, currentLock);
                    task.add(addedLock);
                    addLockPlace = 0;
                } else if(startListeningTaskId == 1) {
                    addedLock = new Lock(startListeningThread, currentLock);
                    startListeningTask.add(addedLock);
                    addLockPlace = 1;
                } else {
                    addedLock = new Lock(mainThread, currentLock);
                    startListeningTask.add(addedLock);
                    addLockPlace = 2;
                }
            }
            if(addLock && !addUnlock && !srcSink.isLocked()) {
                addUnlock = true;
                if(addLockPlace == -1) {
                    System.out.println("addLockPlace in VUI source trace cannot be negative");
                    System.exit(-1);
                }
                Unlock addedUnlock = null;
                if(addLockPlace == 0) {
                    addedUnlock = new Unlock(mainThread, currentLock);
                    task.add(addedUnlock);
                } else if(addLockPlace == 1) {
                    addedUnlock = new Unlock(startListeningThread, currentLock);
                    startListeningTask.add(addedUnlock);
                } else {
                    addedUnlock = new Unlock(mainThread, currentLock);
                    startListeningTask.add(addedUnlock);
                }
                if(addedLock == null) {
                    System.out.println("addedLock cannot be null");
                    System.exit(-1);
                }
                addedLock.addUnlockPair(addedUnlock);
            }
            String methodName = srcSink.method().getName();
            if(startListeningPlace != 2) {
                if (methodName.equals("post") || methodName.equals("postDelayed") || methodName.equals("runOnUiThread")) {
                    startListeningPlace = 2;
                    startListeningInSameTask = false;

                    startListeningTaskId = currentTask;
                    currentTask++;
                    task.add(new PostTask(mainThread, startListeningTaskId, mainThread));

                    startListeningTask = new LinkedList<>();
                    startListeningTask.add(new TaskBegin(mainThread, startListeningTaskId));
                }
            }
            if(startListeningPlace != 1 && startListeningPlace != 2) {
                if (methodName.equals("run") || methodName.equals("doInBackground")) {
                    startListeningPlace = 1;
                    startListeningInSameTask = false;

                    if(startListeningThread != mainThread) {
                        task.add(new Fork(mainThread, startListeningThread));

                        startListeningTaskId = currentTask;
                        ++currentTask;
                        task.add(new PostTask(mainThread, startListeningTaskId, startListeningThread));
                    } else {
                        task.add(new Fork(mainThread, callStartListeningThread));

                        callStartListeningTrace = new LinkedList<>();
                        callStartListeningTrace.add(new ThreadBegin(callStartListeningThread));
                        startListeningTaskId = currentTask;
                        ++currentTask;
                        callStartListeningTrace.add(new PostTask(callStartListeningThread, startListeningTaskId, startListeningThread));
                        callStartListeningTrace.add(new ThreadEnd(callStartListeningThread));
                        executionTrace.addTrace(callStartListeningTrace);
                    }
                    startListeningTask = new LinkedList<>();
                    startListeningTask.add(new TaskBegin(startListeningThread, startListeningTaskId));
                }
            }
            String subSignature = srcSink.getSubSignature();
            if(subSignature.equals("void startListening(android.content.Intent)")
                    || subSignature.equals("int startDialog(com.alibaba.idst.nui.Constants$VadMode,java.lang.String)")
                    || subSignature.equals("void startAudioRecognize(com.tencent.aai.model.AudioRecognizeRequest,com.tencent.aai.listener.AudioRecognizeResultListener,com.tencent.aai.listener.AudioRecognizeStateListener,com.tencent.aai.listener.AudioRecognizeTimeoutListener,com.tencent.aai.model.AudioRecognizeConfiguration)")
                    || subSignature.equals("void startAudioRecognize(com.tencent.aai.model.AudioRecognizeRequest,com.tencent.aai.listener.AudioRecognizeResultListener,com.tencent.aai.listener.AudioRecognizeStateListener,com.tencent.aai.model.AudioRecognizeConfiguration)")
                    || subSignature.equals("void startAudioRecognize(com.tencent.aai.model.AudioRecognizeRequest,com.tencent.aai.listener.AudioRecognizeResultListener,com.tencent.aai.model.AudioRecognizeConfiguration)")
                    || subSignature.equals("void send(java.lang.String,java.lang.String,byte[],int,int)")
                    || subSignature.equals("void start(java.util.Map)")
                    || subSignature.equals("java.util.concurrent.Future recognizeOnceAsync()")
                    || (subSignature.equals("void <init>(java.lang.String)")
                    && srcSink instanceof Sink
                    && ((Sink) srcSink).stmt().getInvokeExpr().getArg(0) instanceof StringConstant
                    && ((StringConstant) ((Sink) srcSink).stmt().getInvokeExpr().getArg(0)).value.equals("android.speech.action.RECOGNIZE_SPEECH"))) {
                if(startListeningPlace == 0) {
                    if(sdkId == 0 || sdkId >= 2 && sdkId <= 5) { //google + bat
                        task.add(new Fork(mainThread, remoteServer));
                    } else if(sdkId == 1){
                        // huawei: fork(mainThread, asrThread); PostTask(mainThread, id2, asrThread); TaskEnd; + asrThread: ThreadBegin, ExecuteTask, TaskBegin(id2), fork(asrThread, remoteServer), TaskEnd
                        int id2 = currentTask;
                        ++currentTask;
                        task.add(new Fork(mainThread, AsrThread));
                        task.add(new PostTask(mainThread, id2, AsrThread));

                        // asrThread: ThreadBegin, ExecuteTask, TaskBegin(id2), fork(asrThread, remoteServer), TaskEnd
                        AsrThreadTrace = new LinkedList<>();
                        AsrThreadTrace.add(new ThreadBegin(AsrThread));
                        AsrThreadTrace.add(new ExecuteTask(AsrThread));
                        executionTrace.addTrace(AsrThreadTrace);

                        List<Instruction> startTask = new LinkedList<>();
                        startTask.add(new TaskBegin(AsrThread, id2));
                        startTask.add(new Fork(AsrThread, remoteServer));
                        startTask.add(new TaskEnd(AsrThread, id2));
                        executionTrace.addTask(startTask);
                        VUIstartTaskIds.add(id2);
                    } else if(sdkId == 6){
                        //microsoft: fork(mainThread, asrThread); ?Join(remoteServer, mainThread); TaskEnd + asrThread: ThreadBegin, fork(asrThread, remoteServer); ThreadEnd;
                        task.add(new Fork(mainThread, AsrThread));

                        //there might be a join
                        SootMethod src = vuiSourceTrace.get(vuiSourceTrace.size() - 2).getKey().method();
                        boolean hasGetMethod = false; //if get() is used, the current thread waits
                        for(Iterator<Edge> it = callgraph.edgesOutOf(src); it.hasNext();) {
                            SootMethod methodInSrc = it.next().tgt();
                            if(methodInSrc.getDeclaringClass().getName().equals("java.util.concurrent.Future")
                                    && methodInSrc.getName().equals("get")
                                    && methodInSrc.getParameterCount() == 0) {
                                hasGetMethod = true;
                                break;
                            }
                        }
                        if(hasGetMethod) {
                            //add Join
                            task.add(new Join(remoteServer, mainThread));
                        }

                        // asrThread: ThreadBegin, fork(asrThread, remoteServer), ThreadEnd
                        AsrThreadTrace = new LinkedList<>();
                        AsrThreadTrace.add(new ThreadBegin(AsrThread));
                        AsrThreadTrace.add(new Fork(AsrThread, remoteServer));
                        AsrThreadTrace.add(new ThreadEnd(AsrThread));
                        executionTrace.addTrace(AsrThreadTrace);

                        VUIsinkTask = VUIstartTask;
                    }
                }
                else if(startListeningPlace == 1) {
                    if(startListeningTask == null) {
                        System.out.println("startListeningTask should not be null!");
                        System.exit(-1);
                    }

                    if(startListeningThread != mainThread) {
                        //init startListeningThreadTrace: ThreadBegin, ExecuteTask, TaskBegin(id1), xxx, TaskEnd(id1)
                        startListeningThreadTrace = new LinkedList<>();
                        startListeningThreadTrace.add(new ThreadBegin(startListeningThread));
                        startListeningThreadTrace.add(new ExecuteTask(startListeningThread));
                        executionTrace.addTrace(startListeningThreadTrace);
                    }

                    switch (sdkId) {
                        case 1:
                            // huawei: fork(startListeningThread, asrThread); PostTask(startListeningThread, id2, asrThread);
                            int id2 = currentTask;
                            ++currentTask;
                            startListeningTask.add(new Fork(startListeningThread, AsrThread));
                            startListeningTask.add(new PostTask(startListeningThread, id2, AsrThread));

                            // asrThread: ThreadBegin, ExecuteTask, TaskBegin(id2), fork(asrThread, remoteServer), TaskEnd
                            AsrThreadTrace = new LinkedList<>();
                            AsrThreadTrace.add(new ThreadBegin(AsrThread));
                            AsrThreadTrace.add(new ExecuteTask(AsrThread));
                            executionTrace.addTrace(AsrThreadTrace);

                            List<Instruction> startTask = new LinkedList<>();
                            startTask.add(new TaskBegin(AsrThread, id2));
                            startTask.add(new Fork(AsrThread, remoteServer));
                            startTask.add(new TaskEnd(AsrThread, id2));
                            executionTrace.addTask(startTask);
                            VUIstartTaskIds.add(id2);
                            break;
                        case 0: case 2: case 4: case 5:
                            // google, alibaba, tencent: fork(startListeningThread, remoteServer);
                            startListeningTask.add(new Fork(startListeningThread, remoteServer));
                            break;
                        case 3:
                            // baidu: PostTask(startListeningThread, id2, mainThread); + mainThread: TaskBegin(id2), fork(mainThread, remoteServer), TaskEnd
                            id2 = currentTask;
                            ++currentTask;
                            startListeningTask.add(new PostTask(startListeningThread, id2, mainThread));
                            startTask = new LinkedList<>();
                            startTask.add(new TaskBegin(mainThread, id2));
                            startTask.add(new Fork(mainThread, remoteServer));
                            startTask.add(new TaskEnd(mainThread, id2));
                            executionTrace.addTask(startTask);
                            VUIstartTaskIds.add(id2);
                            break;
                        case 6:
                            // microsoft: fork(startListeningThread, asrThread); ?join(remoteServer, startListeningThread)
                            startListeningTask.add(new Fork(startListeningThread, AsrThread));

                            //there might be a join
                            SootMethod src = vuiSourceTrace.get(vuiSourceTrace.size() - 2).getKey().method();
                            boolean hasGetMethod = false; //if get() is used, the current thread waits
                            for(Iterator<Edge> it = callgraph.edgesOutOf(src); it.hasNext();) {
                                SootMethod methodInSrc = it.next().tgt();
                                if(methodInSrc.getDeclaringClass().getName().equals("java.util.concurrent.Future")
                                        && methodInSrc.getName().equals("get")
                                        && methodInSrc.getParameterCount() == 0) {
                                    hasGetMethod = true;
                                    break;
                                }
                            }
                            if(hasGetMethod) {
                                //add Join
                                startListeningTask.add(new Join(remoteServer, startListeningThread));
                            }

                            // asrThread: ThreadBegin, fork(asrThread, remoteServer), ThreadEnd
                            AsrThreadTrace = new LinkedList<>();
                            AsrThreadTrace.add(new ThreadBegin(AsrThread));
                            AsrThreadTrace.add(new Fork(AsrThread, remoteServer));
                            AsrThreadTrace.add(new ThreadEnd(AsrThread));
                            executionTrace.addTrace(AsrThreadTrace);
                            VUIsinkTask = startListeningTaskId;
                            break;
                    }
                }
                else {
                    if(startListeningTask == null) {
                        System.out.println("startListeningTask should not be null!");
                        System.exit(-1);
                    }

                    if(sdkId == 0 || sdkId >= 2 && sdkId <= 5) { //google + bat
                        startListeningTask.add(new Fork(mainThread, remoteServer));
                    } else if(sdkId == 1){
                        // huawei: fork(mainThread, asrThread); PostTask(mainThread, id2, asrThread); TaskEnd; + asrThread: ThreadBegin, ExecuteTask, TaskBegin(id2), fork(asrThread, remoteServer), TaskEnd
                        startListeningTask.add(new Fork(mainThread, AsrThread));
                        int id2 = currentTask;
                        ++currentTask;
                        startListeningTask.add(new PostTask(mainThread, id2, AsrThread));

                        // asrThread: ThreadBegin, ExecuteTask, TaskBegin(id2), fork(asrThread, remoteServer), TaskEnd
                        AsrThreadTrace = new LinkedList<>();
                        AsrThreadTrace.add(new ThreadBegin(AsrThread));
                        AsrThreadTrace.add(new ExecuteTask(AsrThread));
                        executionTrace.addTrace(AsrThreadTrace);

                        List<Instruction> startTask = new LinkedList<>();
                        startTask.add(new TaskBegin(AsrThread, id2));
                        startTask.add(new Fork(AsrThread, remoteServer));
                        startTask.add(new TaskEnd(AsrThread, id2));
                        executionTrace.addTask(startTask);
                        VUIstartTaskIds.add(id2);

                    } else if(sdkId == 6){
                        //microsoft: fork(mainThread, asrThread); ?Join(remoteServer, mainThread); TaskEnd + asrThread: ThreadBegin, fork(asrThread, remoteServer); ThreadEnd;
                        startListeningTask.add(new Fork(mainThread, AsrThread));

                        //there might be a join
                        SootMethod src = vuiSourceTrace.get(vuiSourceTrace.size() - 2).getKey().method();
                        boolean hasGetMethod = false; //if get() is used, the current thread waits
                        for(Iterator<Edge> it = callgraph.edgesOutOf(src); it.hasNext();) {
                            SootMethod methodInSrc = it.next().tgt();
                            if(methodInSrc.getDeclaringClass().getName().equals("java.util.concurrent.Future")
                                    && methodInSrc.getName().equals("get")
                                    && methodInSrc.getParameterCount() == 0) {
                                hasGetMethod = true;
                                break;
                            }
                        }
                        if(hasGetMethod) {
                            //add Join
                            startListeningTask.add(new Join(remoteServer, mainThread));
                        }

                        // asrThread: ThreadBegin, fork(asrThread, remoteServer), ThreadEnd
                        AsrThreadTrace = new LinkedList<>();
                        AsrThreadTrace.add(new ThreadBegin(AsrThread));
                        AsrThreadTrace.add(new Fork(AsrThread, remoteServer));
                        AsrThreadTrace.add(new ThreadEnd(AsrThread));
                        executionTrace.addTrace(AsrThreadTrace);

                        VUIsinkTask = VUIstartTask;
                    }
                }
            }
            if(methodName.equals("lock") && !addLock2) {
                addLock2 = true;
                if(startListeningPlace == 0) {
                    addedLock2 = new Lock(mainThread, currentLock);
                    task.add(addedLock2);
                    addLockPlace2 = 0;
                } else if(startListeningTaskId == 1) {
                    addedLock2 = new Lock(startListeningThread, currentLock);
                    startListeningTask.add(addedLock2);
                    addLockPlace2 = 1;
                } else {
                    addedLock2 = new Lock(mainThread, currentLock);
                    startListeningTask.add(addedLock2);
                    addLockPlace2 = 2;
                }
            }
            if(methodName.equals("unlock") && addLock2 && !addUnlock2) {
                addUnlock2 = true;
                if(addLockPlace2 == -1) {
                    System.out.println("addLockPlace2 in VUI source trace cannot be negative");
                    System.exit(-1);
                }
                Unlock addedUnlock2 = null;
                if(addLockPlace2 == 0) {
                    addedUnlock2 = new Unlock(mainThread, currentLock);
                    task.add(addedUnlock2);
                } else if(addLockPlace2 == 1) {
                    addedUnlock2 = new Unlock(startListeningThread, currentLock);
                    startListeningTask.add(addedUnlock2);
                } else {
                    addedUnlock2 = new Unlock(mainThread, currentLock);
                    startListeningTask.add(addedUnlock2);
                }
                if(addedLock2 == null) {
                    System.out.println("addedLock2 cannot be null");
                    System.exit(-1);
                }
                addedLock2.addUnlockPair(addedUnlock2);
            }
        }

        if(addLock && !addUnlock) {
            addUnlock = true;
            if(addLockPlace == -1) {
                System.out.println("addLockPlace cannot be negative");
                System.exit(-1);
            }
            Unlock addedUnlock = null;
            if(addLockPlace == 0) {
                addedUnlock = new Unlock(mainThread, currentLock);
                task.add(addedUnlock);
            } else if(addLockPlace == 1) {
                addedUnlock = new Unlock(startListeningThread, currentLock);
                startListeningTask.add(addedUnlock);
            } else {
                addedUnlock = new Unlock(mainThread, currentLock);
                startListeningTask.add(addedUnlock);
            }
            if(addedLock == null) {
                System.out.println("addedLock cannot be null");
                System.exit(-1);
            }
            addedLock.addUnlockPair(addedUnlock);
        }

        if(startListeningPlace == 1 || startListeningPlace == 2) {
            startListeningTask.add(new TaskEnd(startListeningThread, startListeningTaskId));
            executionTrace.addTask(startListeningTask);
            VUIstartTaskIds.add(startListeningTaskId);
        }

        task.add(new TaskEnd(mainThread, VUIstartTask));
        executionTrace.addTask(task);
        VUIstartTaskIds.add(VUIstartTask);

//        tempRes.computeIfAbsent(noDisableOnVUIStartTrace, k -> new HashMap<>());
//        if(tempRes.get(noDisableOnVUIStartTrace).get(startListeningInSameTask) == null) {
//            Map<Boolean, Map<Boolean, Map<Boolean, Integer>>> r1 = tempRes.get(noDisableOnVUIStartTrace);
//            r1.put(startListeningInSameTask, new HashMap<>());
//            tempRes.put(noDisableOnVUIStartTrace, r1);
//        }

        return startListeningInSameTask;
    }

    private void getStartListeningThread(int sdkId, List<Pair<ISourceSink, Integer>> vuiSourceTrace) {
        //for baidu & alibaba & huawei & microsoft, startListening may not be in main thread
        switch (sdkId) {
            case 1: //huawei
            case 4: //alibaba
                startListeningThread = VUIsinkTaskThread;
                break;
            case 0:
            case 2: //google
                startListeningThread = mainThread;
                break;
            case 3: //baidu
            case 5: //tencent
            case 6: //microsoft
                ISourceSink send = vuiSourceTrace.get(vuiSourceTrace.size() - 1).getKey();
                if(send.isInMainThread())
                    startListeningThread = mainThread;
                break;
        }
    }

    private boolean startDialogOnVUISourceTrace(List<Pair<ISourceSink, Integer>> vuiSourceTrace) {
        for(Pair<ISourceSink, Integer> pair: vuiSourceTrace) {
            SootMethod sm = pair.getKey().method();
            if(sm.getName().startsWith("show") && callgraph.getImportantFuncs().contains(sm)) {
                return true;
            }
        }
        return false;
    }

    private boolean addVUISinkTask(int sdkId, List<Pair<ISourceSink, Integer>> vuiSinkTrace, boolean noDisableOnVUIStartTrace) throws IOException {
        boolean VUIsinkInSameTask = true;

        hasLockOnVUISinkTask = hasLock(vuiSinkTrace);

        List<Instruction> VUIsinkt = new LinkedList<>();
        if (sdkId < 6) {
            //VUIsinkTask may not in mainThread
            VUIsinkt.add(new TaskBegin(VUIsinkTaskThread, VUIsinkTask));

            // init VUIsinkTaskThread if needed: ThreadBegin, ExecuteTask
            if (VUIsinkTaskThread != mainThread && VUIsinkTaskThread != startListeningThread) {
                VUIsinkTaskThreadTrace = new LinkedList<>();
                VUIsinkTaskThreadTrace.add(new ThreadBegin(VUIsinkTaskThread));
                VUIsinkTaskThreadTrace.add(new ExecuteTask(VUIsinkTaskThread));
                executionTrace.addTrace(VUIsinkTaskThreadTrace);
                List<Instruction> remoteServerTrace = executionTrace.getTraceByThreadId(remoteServer);
                remoteServerTrace.add(1, new Fork(remoteServer, VUIsinkTaskThread));
                executionTrace.addTrace(remoteServerTrace);
            }
        }

        boolean hasEnableOnVUISinkTrace = false;
        if (sdkId < 6) {
            // if Disable, has Enable?
            if (!noDisableOnVUIStartTrace) {
                if(!isNoEnableOnVUISinkTrace(vuiSinkTrace) && sdkId != 0) {
                    VUIsinkt.add(new Enable(VUIsinkTaskThread, GUITask));
                    hasEnableOnVUISinkTrace = true;
                }
            }
        }

        //check the task of VUIsink
        int VUIsinkPlace = 0; //0: this task in VUIsinkTaskThread, 1: another thread, 2: new Task in VUIsinkTaskThread
        List<Instruction> sinkTask = null;
        boolean addLock = false;
        boolean addUnlock = false;
        boolean addLock2 = false;
        boolean addUnlock2 = false;
        int addLockPlace = -1;
        int addLockPlace2 = -1;
        Lock addedLock = null;
        Lock addedLock2 = null;
        for (Pair<ISourceSink, Integer> sourceSink : vuiSinkTrace) {
            if(!addLock && sourceSink.getKey().isLocked()) {
                addLock = true;
                if(VUIsinkPlace == 0) {
                    if(sdkId < 6) {
                        addedLock = new Lock(VUIsinkTaskThread, currentLock);
                        VUIsinkt.add(addedLock);
                    } else {
                        List<Instruction> VUIsinkt2 = executionTrace.getTaskByTaskId(VUIsinkTask);
                        VUIsinkTaskThread = VUIsinkt2.get(0).getCurrentThread();
                        addedLock = new Lock(VUIsinkTaskThread, currentLock);
                        VUIsinkt2.add(VUIsinkt2.size() - 1, addedLock);
                        executionTrace.addTask(VUIsinkt2);
                        VUIsinkTaskIds.add(VUIsinkTask);
                    }
                    addLockPlace = 0;
                } else if(VUIsinkPlace == 1) {
                    addedLock = new Lock(VUIThread, currentLock);
                    VUIThreadTrace.add(addedLock);
                    addLockPlace = 1;
                } else {
                    addedLock = new Lock(sinkTask.get(0).getCurrentThread(), currentLock);
                    sinkTask.add(addedLock);
                    addLockPlace = 2;
                }
            }
            if(addLock && !addUnlock && !sourceSink.getKey().isLocked()) {
                addUnlock = true;
                if(addLockPlace == -1) {
                    System.out.println("addLockPlace cannot be negative");
                    System.exit(-1);
                }
                Unlock addedUnlock = null;
                if(addLockPlace == 0) {
                    if(sdkId < 6) {
                        addedUnlock = new Unlock(VUIsinkTaskThread, currentLock);
                        VUIsinkt.add(addedUnlock);
                    } else {
                        List<Instruction> VUIsinkt2 = executionTrace.getTaskByTaskId(VUIsinkTask);
                        VUIsinkTaskThread = VUIsinkt2.get(0).getCurrentThread();
                        addedUnlock = new Unlock(VUIsinkTaskThread, currentLock);
                        VUIsinkt2.add(VUIsinkt2.size() - 1, addedUnlock);
                        executionTrace.addTask(VUIsinkt2);
                        VUIsinkTaskIds.add(VUIsinkTask);
                    }
                } else if(addLockPlace == 1) {
                    addedUnlock = new Unlock(VUIThread, currentLock);
                    VUIThreadTrace.add(addedUnlock);
                } else {
                    addedUnlock = new Unlock(sinkTask.get(0).getCurrentThread(), currentLock);
                    sinkTask.add(addedUnlock);
                }
                if(addedLock == null) {
                    System.out.println("addedLock cannot be null");
                    System.exit(-1);
                }
                addedLock.addUnlockPair(addedUnlock);
            }
            String name = sourceSink.getKey().method().getName();
            if(VUIsinkPlace != 2) {
                if (name.equals("post") || name.equals("postDelayed")) {
                    VUIsinkPlace = 2;
                    VUIsinkInSameTask = false;
                    if(sdkId < 6) {
                        VUIsinkt.add(new PostTask(VUIsinkTaskThread, currentTask, VUIsinkTaskThread));
                        sinkTask = new LinkedList<>();
                        sinkTask.add(new TaskBegin(VUIsinkTaskThread, currentTask));
                    } else {
                        List<Instruction> VUIsinkt2 = executionTrace.getTaskByTaskId(VUIsinkTask);
                        VUIsinkTaskThread = VUIsinkt2.get(0).getCurrentThread();
                        VUIsinkt2.add(VUIsinkt2.size() - 1, new PostTask(VUIsinkTaskThread, currentTask, VUIsinkTaskThread));
                        executionTrace.addTask(VUIsinkt2);
                        VUIsinkTaskIds.add(VUIsinkTask);
                        sinkTask = new LinkedList<>();
                        sinkTask.add(new TaskBegin(VUIsinkTaskThread, currentTask));
                    }
                }
                else if(name.equals("runOnUiThread")) {
                    VUIsinkPlace = 2;
                    VUIsinkInSameTask = false;
                    if(sdkId < 6) {
                        VUIsinkt.add(new PostTask(VUIsinkTaskThread, currentTask, mainThread));
                        sinkTask = new LinkedList<>();
                        sinkTask.add(new TaskBegin(mainThread, currentTask));
                    } else {
                        List<Instruction> VUIsinkt2 = executionTrace.getTaskByTaskId(VUIsinkTask);
                        VUIsinkTaskThread = VUIsinkt2.get(0).getCurrentThread();
                        VUIsinkt2.add(VUIsinkt2.size() - 1, new PostTask(VUIsinkTaskThread, currentTask, mainThread));
                        executionTrace.addTask(VUIsinkt2);
                        VUIsinkTaskIds.add(VUIsinkTask);
                        sinkTask = new LinkedList<>();
                        sinkTask.add(new TaskBegin(mainThread, currentTask));
                    }
                }
            }
            if(VUIsinkPlace != 1 && VUIsinkPlace != 2) {
                if (name.equals("run") || name.equals("doInBackground")) {
                    VUIsinkPlace = 1;
                    VUIsinkInSameTask = false;
                    if (sdkId < 6)
                        VUIsinkt.add(new Fork(VUIsinkTaskThread, VUIThread));
                    else {
                        List<Instruction> VUIsinkt2 = executionTrace.getTaskByTaskId(VUIsinkTask);
                        VUIsinkTaskThread = VUIsinkt2.get(0).getCurrentThread();
                        VUIsinkt2.add(VUIsinkt2.size() - 1, new Fork(VUIsinkTaskThread, VUIThread));
                        executionTrace.addTask(VUIsinkt2);
                        VUIsinkTaskIds.add(VUIsinkTask);
                    }
                    //add VUI thread
                    VUIThreadTrace = new LinkedList<>();
                    VUIThreadTrace.add(new ThreadBegin(VUIThread));
                }
            }
            if(sourceSink.getKey() instanceof VUISink) {
                if(VUIsinkPlace == 0) {
                    if (sdkId < 6) {
                        VUIsinkt.add(new VUIsink(VUIsinkTaskThread));
                        if (!noDisableOnVUIStartTrace && !hasEnableOnVUISinkTrace) //has Disable but no Enable
                            VUIsinkt.add(new Enable(VUIsinkTaskThread, GUITask));
                    } else {
                        List<Instruction> VUIsinkt2 = executionTrace.getTaskByTaskId(VUIsinkTask);
                        VUIsinkTaskThread = VUIsinkt2.get(0).getCurrentThread();
                        VUIsinkt2.add(VUIsinkt2.size() - 1, new VUIsink(VUIsinkTaskThread));
                        executionTrace.addTask(VUIsinkt2);
                        VUIsinkTaskIds.add(VUIsinkTask);
                    }
                }
                else if(VUIsinkPlace == 1) {
                    VUIThreadTrace.add(new VUIsink(VUIThread));
                    if(sdkId < 6 && !noDisableOnVUIStartTrace && !hasEnableOnVUISinkTrace) //has Disable but no Enable
                        VUIThreadTrace.add(new Enable(VUIThread, GUITask));
                }
                else {
                    sinkTask.add(new VUIsink(sinkTask.get(0).getCurrentThread()));
                    if(sdkId < 6) {
                        if(!noDisableOnVUIStartTrace && !hasEnableOnVUISinkTrace) //has Disable but no Enable
                            sinkTask.add(new Enable(sinkTask.get(0).getCurrentThread(), GUITask));
                    }
                }
            }
            if(name.equals("lock") && !addLock2) {
                addLock2 = true;
                if(VUIsinkPlace == 0) {
                    if(sdkId < 6) {
                        addedLock2 = new Lock(VUIsinkTaskThread, currentLock);
                        VUIsinkt.add(addedLock2);
                    } else {
                        List<Instruction> VUIsinkt2 = executionTrace.getTaskByTaskId(VUIsinkTask);
                        VUIsinkTaskThread = VUIsinkt2.get(0).getCurrentThread();
                        addedLock2 = new Lock(VUIsinkTaskThread, currentLock);
                        VUIsinkt2.add(VUIsinkt2.size() - 1, addedLock2);
                        executionTrace.addTask(VUIsinkt2);
                        VUIsinkTaskIds.add(VUIsinkTask);
                    }
                    addLockPlace2 = 0;
                } else if(VUIsinkPlace == 1) {
                    addedLock2 = new Lock(VUIThread, currentLock);
                    VUIThreadTrace.add(addedLock2);
                    addLockPlace2 = 1;
                } else {
                    addedLock2 = new Lock(sinkTask.get(0).getCurrentThread(), currentLock);
                    sinkTask.add(addedLock2);
                    addLockPlace2 = 2;
                }
            }
            if(name.equals("unlock") && addLock2 && !addUnlock2) {
                addUnlock2 = true;
                if(addLockPlace2 == -1) {
                    System.out.println("addLockPlace2 in VUI source trace cannot be negative");
                    System.exit(-1);
                }
                Unlock addedUnlock2 = null;
                if(addLockPlace2 == 0) {
                    if(sdkId < 6) {
                        addedUnlock2 = new Unlock(VUIsinkTaskThread, currentLock);
                        VUIsinkt.add(addedUnlock2);
                    } else {
                        List<Instruction> VUIsinkt2 = executionTrace.getTaskByTaskId(VUIsinkTask);
                        VUIsinkTaskThread = VUIsinkt2.get(0).getCurrentThread();
                        addedUnlock2 = new Unlock(VUIsinkTaskThread, currentLock);
                        VUIsinkt2.add(VUIsinkt2.size() - 1, addedUnlock2);
                        executionTrace.addTask(VUIsinkt2);
                        VUIsinkTaskIds.add(VUIsinkTask);
                    }
                } else if(addLockPlace2 == 1) {
                    addedUnlock2 = new Unlock(VUIThread, currentLock);
                    VUIThreadTrace.add(addedUnlock2);
                } else {
                    addedUnlock2 = new Unlock(sinkTask.get(0).getCurrentThread(), currentLock);
                    sinkTask.add(addedUnlock2);
                }
                if(addedLock2 == null) {
                    System.out.println("addedLock2 cannot be null");
                    System.exit(-1);
                }
                addedLock2.addUnlockPair(addedUnlock2);
            }
        }

        if(addLock && !addUnlock) {
            addUnlock = true;
            if(addLockPlace == -1) {
                System.out.println("addLockPlace cannot be negative");
                System.exit(-1);
            }
            Unlock addedUnlock = null;
            if(addLockPlace == 0) {
                if(sdkId < 6) {
                    addedUnlock = new Unlock(VUIsinkTaskThread, currentLock);
                    VUIsinkt.add(addedUnlock);
                } else {
                    List<Instruction> VUIsinkt2 = executionTrace.getTaskByTaskId(VUIsinkTask);
                    VUIsinkTaskThread = VUIsinkt2.get(0).getCurrentThread();
                    addedUnlock = new Unlock(VUIsinkTaskThread, currentLock);
                    VUIsinkt2.add(VUIsinkt2.size() - 1, addedUnlock);
                    executionTrace.addTask(VUIsinkt2);
                    VUIsinkTaskIds.add(VUIsinkTask);
                }
            } else if(addLockPlace == 1) {
                addedUnlock = new Unlock(VUIThread, currentLock);
                VUIThreadTrace.add(addedUnlock);
            } else {
                addedUnlock = new Unlock(sinkTask.get(0).getCurrentThread(), currentLock);
                sinkTask.add(addedUnlock);
            }
            if(addedLock == null) {
                System.out.println("addedLock cannot be null");
                System.exit(-1);
            }
            addedLock.addUnlockPair(addedUnlock);
        }

        if(VUIsinkPlace == 1) {
            VUIThreadTrace.add(new ThreadEnd(VUIThread));
            executionTrace.addTrace(VUIThreadTrace);
        }
        else if (VUIsinkPlace == 2) {
            sinkTask.add(new TaskEnd(sinkTask.get(0).getCurrentThread(), currentTask));
            executionTrace.addTask(sinkTask);
            VUIsinkTaskIds.add(currentTask);
            currentTask++;
        }

        if(sdkId < 6) {
            VUIsinkt.add(new TaskEnd(VUIsinkTaskThread, VUIsinkTask));
            executionTrace.addTask(VUIsinkt);
            VUIsinkTaskIds.add(VUIsinkTask);
        }
        return VUIsinkInSameTask;
    }

    private boolean isNoEnableOnVUISinkTrace(List<Pair<ISourceSink, Integer>> vuiSinkTrace) {
        for(Pair<ISourceSink, Integer> pair: vuiSinkTrace) {
            SootMethod sm = pair.getKey().method();
            if(callgraph.getImportantFuncs().contains(sm) &&
                    (sm.getName().startsWith("dismiss") || sm.getName().equals("cancel") || sm.getName().equals("hide"))) {
                return false;
            }
        }
        return true;
    }

    private Set<String> addGUINormalSourceAndCheck(Set<Source> guiNorSources, boolean noDisableOnVUIStartTrace, boolean startListeningInSameTask, boolean vuiSinkInSameTask,
                                                   List<Pair<ISourceSink, Integer>> vuiSourceTrace, List<Pair<ISourceSink, Integer>> vuiSinkTrace) throws IOException {
        //add GUI normal source
        Set<Integer> GUIsinkTaskIds = new HashSet<>();
        Set<String> conflictGUISources = new HashSet<>();
        if(guiNorSources.size() == 0) {
            if((hasLockOnVUIStartTask || hasLockOnVUISinkTask) && !addToHasLock) {
                File file = new File(outputDir, "all_hasLock.txt");
                if(!file.exists())
                    file.createNewFile();
                String apkFileNameAfterStep2 = file.getPath();
                writeToFiles(apkFileNameAfterStep2, apkFileName);
                addToHasLock = true;
            }
            return conflictGUISources;
        }
        for (Source guiNorSource : guiNorSources) {
            boolean newThreadOnGUISink = true;

            Set<List<Pair<ISourceSink, Integer>>> guiSinkTraces = guiNorSource.getSinkTraces();
            int res1 = -1, res2 = -1;
            for (List<Pair<ISourceSink, Integer>> guiSinkTrace : guiSinkTraces) {
                hasLockOnGUISinkTask = hasLock(guiSinkTrace);

                if((hasLockOnVUIStartTask || hasLockOnVUISinkTask || hasLockOnGUISinkTask) && !addToHasLock) {
                    File file = new File(outputDir, "all_hasLock.txt");
                    if(!file.exists())
                        file.createNewFile();
                    String apkFileNameAfterStep2 = file.getPath();
                    writeToFiles(apkFileNameAfterStep2, apkFileName);
                    addToHasLock = true;
                }

                List<Instruction> guiSinkT = new LinkedList<>();
                guiSinkT.add(new TaskBegin(mainThread, GUITask));

                //check GUI sink place
                int GUIsinkPlace = 0; //0: this task in main, 1: another thread, 2: another task in main
                int GUIThread = 3;
                List<Instruction> guiSinkTask = null;
                boolean addLock = false;
                boolean addUnlock = false;
                boolean addLock2 = false;
                boolean addUnlock2 = false;
                int addLockPlace = -1;
                int addLockPlace2 = -1;
                Lock addedLock = null;
                Lock addedLock2 = null;
                for (Pair<ISourceSink, Integer> sourceSink : guiSinkTrace) {
                    if(!addLock && sourceSink.getKey().isLocked()) {
                        addLock = true;
                        if(GUIsinkPlace == 0) {
                            addedLock = new Lock(mainThread, currentLock);
                            guiSinkT.add(addedLock);
                            addLockPlace = 0;
                        } else if(GUIsinkPlace == 1) {
                            addedLock = new Lock(GUIThread, currentLock);
                            GUIThreadTrace.add(addedLock);
                            addLockPlace = 1;
                        } else {
                            addedLock = new Lock(mainThread, currentLock);
                            guiSinkTask.add(addedLock);
                            addLockPlace = 2;
                        }
                    }
                    if(addLock && !addUnlock && !sourceSink.getKey().isLocked()) {
                        addUnlock = true;
                        if(addLockPlace == -1) {
                            System.out.println("addLockPlace cannot be negative");
                            System.exit(-1);
                        }
                        Unlock addedUnlock = null;
                        if(addLockPlace == 0) {
                            addedUnlock = new Unlock(mainThread, currentLock);
                            guiSinkT.add(addedUnlock);
                        } else if(addLockPlace == 1) {
                            addedUnlock = new Unlock(GUIThread, currentLock);
                            GUIThreadTrace.add(addedUnlock);
                        } else {
                            addedUnlock = new Unlock(mainThread, currentLock);
                            guiSinkTask.add(addedUnlock);
                        }
                        if(addedLock == null) {
                            System.out.println("addedLock cannot be null");
                            System.exit(-1);
                        }
                        addedLock.addUnlockPair(addedUnlock);
                    }
                    String name = sourceSink.getKey().method().getName();
                    if(GUIsinkPlace != 2) {
                        if (name.equals("post") || name.equals("postDelayed") || name.equals("runOnUiThread")) {
                            GUIsinkPlace = 2;
                            newThreadOnGUISink = false;
                            guiSinkT.add(new PostTask(mainThread, currentTask, mainThread));
                            guiSinkTask = new LinkedList<>();
                            guiSinkTask.add(new TaskBegin(mainThread, currentTask));
                        }
                    }
                    if(GUIsinkPlace != 1 && GUIsinkPlace != 2) {
                        if (name.equals("run") || name.equals("doInBackground")) {
                            GUIsinkPlace = 1;
                            newThreadOnGUISink = false;
                            guiSinkT.add(new Fork(mainThread, GUIThread));
                            //add GUI thread
                            GUIThreadTrace = new LinkedList<>();
                            GUIThreadTrace.add(new ThreadBegin(GUIThread));
                        }
                    }
                    if (sourceSink.getKey() instanceof Sink) {
                        if(GUIsinkPlace == 0) {
                            guiSinkT.add(new GUIsink(mainThread));
                        } else if(GUIsinkPlace == 1) {
                            if(GUIThreadTrace == null) {
                                System.out.println("GUIThreadTrace should not be null!");
                                System.exit(-1);
                            }
                            GUIThreadTrace.add(new GUIsink(GUIThread));
                        } else {
                            guiSinkTask.add(new GUIsink(mainThread));
                        }
                    }
                    if(name.equals("lock") && !addLock2) {
                        addLock2 = true;
                        if(GUIsinkPlace == 0) {
                            addedLock2 = new Lock(mainThread, currentLock);
                            guiSinkT.add(addedLock2);
                            addLockPlace2 = 0;
                        } else if(GUIsinkPlace == 1) {
                            addedLock2 = new Lock(GUIThread, currentLock);
                            GUIThreadTrace.add(addedLock2);
                            addLockPlace2 = 1;
                        } else {
                            addedLock2 = new Lock(mainThread, currentLock);
                            guiSinkTask.add(addedLock2);
                            addLockPlace2 = 2;
                        }
                    }
                    if(name.equals("unlock") && addLock2 && !addUnlock2) {
                        addUnlock2 = true;
                        if(addLockPlace2 == -1) {
                            System.out.println("addLockPlace2 in VUI source trace cannot be negative");
                            System.exit(-1);
                        }
                        Unlock addedUnlock2 = null;
                        if(addLockPlace2 == 0) {
                            addedUnlock2 = new Unlock(mainThread, currentLock);
                            guiSinkT.add(addedUnlock2);
                        } else if(addLockPlace2 == 1) {
                            addedUnlock2 = new Unlock(GUIThread, currentLock);
                            GUIThreadTrace.add(addedUnlock2);
                        } else {
                            addedUnlock2 = new Unlock(mainThread, currentLock);
                            guiSinkTask.add(addedUnlock2);
                        }
                        if(addedLock2 == null) {
                            System.out.println("addedLock2 cannot be null");
                            System.exit(-1);
                        }
                        addedLock2.addUnlockPair(addedUnlock2);
                    }
                }

                if(addLock && !addUnlock) {
                    addUnlock = true;
                    if(addLockPlace == -1) {
                        System.out.println("addLockPlace cannot be negative");
                        System.exit(-1);
                    }
                    Unlock addedUnlock = null;
                    if(addLockPlace == 0) {
                        addedUnlock = new Unlock(mainThread, currentLock);
                        guiSinkT.add(addedUnlock);
                    } else if(addLockPlace == 1) {
                        addedUnlock = new Unlock(GUIThread, currentLock);
                        GUIThreadTrace.add(addedUnlock);
                    } else {
                        addedUnlock = new Unlock(mainThread, currentLock);
                        guiSinkTask.add(addedUnlock);
                    }
                    if(addedLock == null) {
                        System.out.println("addedLock cannot be null");
                        System.exit(-1);
                    }
                    addedLock.addUnlockPair(addedUnlock);
                }

                if(GUIsinkPlace == 1) {
                    GUIThreadTrace.add(new ThreadEnd(GUIThread));
                    executionTrace.addTrace(GUIThreadTrace);
                } else if(GUIsinkPlace == 2) {
                    guiSinkTask.add(new TaskEnd(mainThread, currentTask));
                    executionTrace.addTask(guiSinkTask);
                    GUIsinkTaskIds.add(currentTask);
                    currentTask++;
                }

                guiSinkT.add(new TaskEnd(mainThread, GUITask));
                executionTrace.addTask(guiSinkT);
                GUIsinkTaskIds.add(GUITask);

                res1 = checkExecutionTrace(noDisableOnVUIStartTrace, startListeningInSameTask, vuiSinkInSameTask, newThreadOnGUISink,
                        vuiSourceTrace, vuiSinkTrace, guiSinkTrace);

                for(int taskId: GUIsinkTaskIds)
                    executionTrace.deleteTask(taskId);
                if(GUIThreadTrace != null) {
                    GUIThreadTrace = null;
                    executionTrace.deleteTrace(GUIThread);
                }

                break;
            }
            if(res1 == -1) {
                throw new RuntimeException("Checking error for GUI normal source!");
            }
            if(res1 == 1) {
                conflictGUISources.add(guiNorSource.getSignature());
            }
        }
        return conflictGUISources;
    }

    private Set<String> addGUIHiddenSourceAndCheck(Set<Stmt> guiHidSources, boolean noDisableOnVUIStartTrace, boolean startListeningInSameTask, boolean vuiSinkInSameTask,
                                                   List<Pair<ISourceSink, Integer>> vuiSourceTrace, List<Pair<ISourceSink, Integer>> vuiSinkTrace) throws IOException {
        //add gui hidden source
        Set<String> conflictGUISources = new HashSet<>();
        for (Stmt guiHidSource : guiHidSources) {
            int res1, res2;
            List<Instruction> guiSinkT = new LinkedList<>();
            guiSinkT.add(new TaskBegin(mainThread, GUITask));
            guiSinkT.add(new GUIsink(mainThread));
            guiSinkT.add(new TaskEnd(mainThread, GUITask));
            executionTrace.addTask(guiSinkT);

            hasLockOnGUISinkTask = false;

            //check executionTrace
            res1 = checkExecutionTrace(noDisableOnVUIStartTrace, startListeningInSameTask, vuiSinkInSameTask, true,
                    vuiSourceTrace, vuiSinkTrace, null);

            executionTrace.deleteTask(GUITask);
            if(res1 == -1) {
                throw new RuntimeException("Checking error for GUI hidden source!");
            }
            if(res1 == 1) {
                conflictGUISources.add(guiHidSource.toString());
            }
        }
        return conflictGUISources;
    }

    private int checkExecutionTrace(boolean noDisableOnVUIStartTrace, boolean startListeningInSameTask, boolean vuiSinkInSameTask, boolean guiSinkInSameTask,
                                    List<Pair<ISourceSink, Integer>> vuiSourceTrace, List<Pair<ISourceSink, Integer>> vuiSinkTrace, List<Pair<ISourceSink, Integer>> guiSinkTrace) throws IOException {
        //check executionTrace
        int res1 = -1, res2 = -1;
        Map<Object, Map<Object, Map<Object, Integer>>> r1 = null;
        Map<Object, Map<Object, Integer>> r2 = null;
        Map<Object, Integer> r3 = null;
        if(!hasLockOnVUIStartTask)
            r1 = tempRes.get(noDisableOnVUIStartTrace);
        else {
            r1 = tempRes.get(vuiSourceTrace);
            if(r1 == null) {
                for(Object key: tempRes.keySet()) {
                    if(isEqualTrace(key, vuiSourceTrace)) {
                        r1 = tempRes.get(key);
                        break;
                    }
                }
            }
        }
        if(r1 != null){
            if(!hasLockOnVUIStartTask)
                r2 = r1.get(startListeningInSameTask);
            else {
                r2 = r1.get(vuiSourceTrace);
                if(r2 == null) {
                    for(Object key: r1.keySet()) {
                        if(isEqualTrace(key, vuiSourceTrace)) {
                            r2 = r1.get(key);
                            break;
                        }
                    }
                }
            }
        }
        if(r2 != null) {
            if(!hasLockOnVUISinkTask)
                r3 = r2.get(vuiSinkInSameTask);
            else {
                r3 = r2.get(vuiSinkTrace);
                if(r3 == null) {
                    for(Object key: r2.keySet()) {
                        if(isEqualTrace(key, vuiSinkTrace)) {
                            r3 = r2.get(key);
                            break;
                        }
                    }
                }
            }
        }
        if(r3 != null) {
            if(!hasLockOnGUISinkTask) {
                if(r3.get(guiSinkInSameTask) != null)
                    res1 = r3.get(guiSinkInSameTask);
            } else {
                if(guiSinkTrace == null)
                    throw new RuntimeException("guiSinkTrace should not be null");
                if(r3.get(guiSinkTrace) != null)
                    res1 = r3.get(guiSinkTrace);
                else {
                    for(Object key: r3.keySet()) {
                        if(isEqualTrace(key, guiSinkTrace)) {
                            res1 = r3.get(key);
                            break;
                        }
                    }
                }
            }
        }
        if(res1 != -1)
            return res1;
        if(r1 == null)
            r1 = new HashMap<>();
        if(r2 == null)
            r2 = new HashMap<>();
        if(r3 == null)
            r3 = new HashMap<>();
//        BuildGraph bg1 = new BuildGraph(executionTrace, true);//new BuildGraph(executionTrace, true);
//        res1 = bg1.addEdges();
        getTraceType(startListeningInSameTask, vuiSinkInSameTask);
        CheckExecutionTrace cet = new CheckExecutionTrace(executionTrace, true);//bg1.getGraph(), bg1.getNodeToIns(), bg1.getVUISinkNode(), bg1.getGUISinkNode());
        res1 = cet.check();
        if(res1 == 1) { //has race, record reasons for race
            File file1 = new File(outputDir, "withRace_features.txt");
            if(!file1.exists())
                file1.createNewFile();
            String apkFileNameAfterStep2 = file1.getPath();
            String res = apkFileName + ": ";
            if(hasLockOnGUISinkTask || hasLockOnVUISinkTask || hasLockOnVUIStartTask)
                res = res + "has lock";
            else
                res = res + "no lock";
            if(noDisableOnVUIStartTrace)
                res = res + ", no Dialog on vuiSourceTrace";
            if(!startListeningInSameTask)
                res = res + ", startListening in another task";
            if(!vuiSinkInSameTask)
                res = res + ", vuiSink in another task";
            if(!guiSinkInSameTask)
                res = res + ", guiSink in another task";

            writeToFiles(apkFileNameAfterStep2, res);
        }
        if(!hasLockOnGUISinkTask)
            r3.put(guiSinkInSameTask, res1);
        else {
            if(guiSinkTrace == null)
                throw new RuntimeException("guiSinkTrace should not be null");
            r3.put(guiSinkTrace, res1);
        }
        if(!hasLockOnVUISinkTask)
            r2.put(vuiSinkInSameTask, r3);
        else
            r2.put(vuiSinkTrace, r3);
        if(!hasLockOnVUIStartTask) {
            r1.put(startListeningInSameTask, r2);
            tempRes.put(noDisableOnVUIStartTrace, r1);
        } else {
            r1.put(vuiSourceTrace, r2);
            tempRes.put(vuiSourceTrace, r1);
        }

//        BuildGraph ct2 = new BuildGraph(executionTrace, false);
//        res2 = ct2.check();
        return res1;
    }

    private boolean isEqualTrace(Object key, List<Pair<ISourceSink, Integer>> trace) {
        boolean notSameTrace = false;
        if(!(key instanceof List))
            return false;
        List<Pair<ISourceSink, Integer>> pair = (List<Pair<ISourceSink, Integer>>) key;
        if(pair.size() != trace.size())
            return false;
        for(int ind = 0; ind < trace.size(); ++ind) {
            if(!trace.get(ind).getKey().method().equals(pair.get(ind).getKey().method()))
                return false;
        }
        return true;
    }

    private int getTraceType(boolean startListeningInSameTask, boolean VUIsinkInSameTask) {
        int type;
        if(VUIsinkInSameTask) {
            if(startListeningInSameTask)
                type = 1;
            else
                type = 2;
        } else {
            if(startListeningInSameTask)
                type = 3;
            else
                type = 4;
        }
        System.out.println("\033[31m" + "TRACE TYPE: " + type + "\033[0m");
        return type;
    }

    private boolean hasLock(List<Pair<ISourceSink, Integer>> vuiSourceTrace) {
        for(Pair<ISourceSink, Integer> pair: vuiSourceTrace) {
            ISourceSink sourceSink = pair.getKey();
            if(sourceSink.isLocked())
                return true;
            String name = sourceSink.method().getName();
            if(name.equals("lock") || name.equals("unlock")) {
                return true;
            }
        }
        return false;
    }

    private void writeToFiles(String fileName, String line) throws IOException {
        File file = new File(fileName);
        if(!file.exists())
            file.createNewFile();
        FileWriter fw = new FileWriter(fileName, true);
        PrintWriter pw = new PrintWriter(fw);
        pw.println(line);
        pw.flush();
        pw.close();
        fw.close();
    }
}
