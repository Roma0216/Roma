package src.modelConstruct.element;

public class Disable extends Instruction{
    private int taskId;

    public Disable(int currentT, int taskId) {
        type = Type.DISABLE;
        thread = currentT;
        this.taskId = taskId;
    }

    public int getTaskId() { return taskId;}

    public String toString() {
        String res = "disable(";
        if(isMainThread())
            res += "main,";
        else if(isServer())
            res += "server,";
        else
            res += thread + ",";
        res += taskId + ")";
        return res;
    }
}
