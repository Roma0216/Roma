package src.modelConstruct.element;

public class TaskEnd extends Instruction{
    private int taskId;

    public TaskEnd(int currentT, int task) {
        type = Type.TASKEND;
        thread = currentT;
        taskId = task;
    }

    public int getTask() {
        return taskId;
    }

    public String toString() {
        String res = "taskEnd(";
        if(isMainThread())
            res += "main,";
        else if(isServer())
            res += "server,";
        else
            res += thread + ",";
        res += taskId + ")";
        return res;
    }
}
