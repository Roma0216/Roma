package src.modelConstruct.element;

public class Instruction {
    public enum Type
    {
        THREADBEGIN,
        THREADEND,
        FORK,
        JOIN,
        EXECUTETASK,
        POST,
        TASKBEGIN,
        TASKEND,
        DISABLE,
        ENABLE,
        LOCK,
        UNLOCK,
        VUISINK,
        GUISINK,
        ALL;
    }

    protected Type type;
    protected int thread;

    public Type getType() {
        return type;
    }

    public boolean isMainThread() {
        return thread == 0;
    }

    public boolean isServer() { return thread == 1; }

    public int getCurrentThread() {
        return thread;
    }

    public String toString() {return "";}
}
