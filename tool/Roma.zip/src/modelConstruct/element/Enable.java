package src.modelConstruct.element;

public class Enable extends Instruction{
    private int taskId;

    public Enable(int currentT, int taskId) {
        type = Type.ENABLE;
        thread = currentT;
        this.taskId = taskId;
    }

    public int getTaskId() { return taskId;}

    public String toString() {
        String res = "enable(";
        if(isMainThread())
            res += "main,";
        else if(isServer())
            res += "server,";
        else
            res += thread + ",";
        res += taskId + ")";
        return res;
    }
}
