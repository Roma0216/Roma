package src.modelConstruct.element;

public class GUIsink extends Instruction{
    public GUIsink(int t) {
        type = Type.GUISINK;
        thread = t;
    }

    public String toString() {
        String res = "GUIsink(";
        if(isMainThread())
            res += "main)";
        else if(isServer())
            res += "server)";
        else
            res += thread + ")";
        return res;
    }
}
