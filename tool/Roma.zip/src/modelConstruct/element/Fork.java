package src.modelConstruct.element;

public class Fork extends Instruction{
    private int childT;

    public Fork(int fatherT, int childT) {
        type = Type.FORK;
        thread = fatherT;
        this.childT = childT;
    }

    public int getChildThread() {
        return childT;
    }

    public String toString() {
        String res = "fork(";
        if(isMainThread())
            res += "main,";
        else if(isServer())
            res += "server,";
        else
            res += thread + ",";
        if(childT == 0)
            res += "main)";
        else if(childT == 1)
            res += "server)";
        else
            res += childT + ")";
        return res;
    }
}
