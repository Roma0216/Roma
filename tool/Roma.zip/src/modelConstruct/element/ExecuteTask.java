package src.modelConstruct.element;

public class ExecuteTask extends Instruction{
    public ExecuteTask(int t) {
        type = Type.EXECUTETASK;
        thread = t;
    }

    public String toString() {
        String res = "executeTask(";
        if(isMainThread())
            res += "main)";
        else if(isServer())
            res += "server)";
        else
            res += thread + ")";
        return res;
    }
}
