package src.modelConstruct.element;

public class TaskBegin extends Instruction{
    private int taskId;

    public TaskBegin(int currentT, int task) {
        type = Type.TASKBEGIN;
        thread = currentT;
        taskId = task;
    }

    public int getTask() {
        return taskId;
    }

    public String toString() {
        String res = "taskBegin(";
        if(isMainThread())
            res += "main,";
        else if(isServer())
            res += "server,";
        else
            res += thread + ",";
        res += taskId + ")";
        return res;
    }
}
