package src.modelConstruct.element;

public class ThreadEnd extends Instruction{
    public ThreadEnd(int t) {
        type = Type.THREADEND;
        thread = t;
    }

    public String toString() {
        String res = "threadEnd(";
        if(isMainThread())
            res += "main)";
        else if(isServer())
            res += "server)";
        else
            res += thread + ")";
        return res;
    }
}
