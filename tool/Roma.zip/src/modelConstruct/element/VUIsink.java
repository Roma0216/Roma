package src.modelConstruct.element;

public class VUIsink extends Instruction{
    public VUIsink(int t) {
        type = Type.VUISINK;
        thread = t;
    }

    public String toString() {
        String res = "VUIsink(";
        if(isMainThread())
            res += "main)";
        else if(isServer())
            res += "server)";
        else
            res += thread + ")";
        return res;
    }
}
