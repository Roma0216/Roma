package src.modelConstruct.element;

public class ThreadBegin extends Instruction{

    public ThreadBegin(int t) {
        type = Type.THREADBEGIN;
        thread = t;
    }

    public String toString() {
        String res = "threadBegin(";
        if(isMainThread())
            res += "main)";
        else if(isServer())
            res += "server)";
        else
            res += thread + ")";
        return res;
    }
}
