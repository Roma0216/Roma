package src.modelConstruct.element;

public class Join extends Instruction{
    private int childT;

    public Join(int childT, int fatherT) {
        type = Type.JOIN;
        thread = fatherT;
        this.childT = childT;
    }

    public int getChildThread() {
        return childT;
    }

    public String toString() {
        String res = "join(";
        if(childT == 0)
            res += "main,";
        else if(childT == 1)
            res += "server,";
        else
            res += childT + ",";

        if(isMainThread())
            res += "main)";
        else if(isServer())
            res += "server)";
        else
            res += thread + ")";
        return res;
    }
}