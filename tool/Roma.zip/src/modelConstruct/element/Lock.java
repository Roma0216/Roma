package src.modelConstruct.element;

public class Lock extends Instruction{
    private int lockId;
    private Unlock unlock = null;

    public Lock(int currentT, int lockId) {
        type = Type.LOCK;
        thread = currentT;
        this.lockId = lockId;
    }

    public int getLockId() {
        return lockId;
    }

    public void addUnlockPair(Unlock unlock) {
        this.unlock = unlock;
    }

    public Unlock getUnlockPair() {
        if(unlock == null)
            throw new RuntimeException("the corresponding unlock of " + this + "is null");
        return unlock;
    }

    public String toString() {
        String res = "lock(";
        if(isMainThread())
            res += "main,";
        else if(isServer())
            res += "server,";
        else
            res += thread + ",";
        res += lockId + ")";
        return res;
    }
}
