package src.modelConstruct.element;

public class PostTask extends Instruction{
    private int taskId;
    private int targetThread;

    public PostTask(int currentT, int task, int targetT) {
        type = Type.POST;
        thread = currentT;
        taskId = task;
        targetThread = targetT;
    }

    public int getTask() {
        return taskId;
    }

    public int getTargetThread() {
        return targetThread;
    }

    public String toString() {
        String res = "postTask(";
        if(isMainThread())
            res += "main,";
        else if(isServer())
            res += "server,";
        else
            res += thread + ",";
        res += taskId + ",";
        if(targetThread == 0)
            res += "main)";
        else if(targetThread == 1)
            res += "server)";
        else
            res += targetThread + ")";
        return res;
    }
}
