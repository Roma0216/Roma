package src.modelConstruct.element;

public class Unlock extends Instruction {
    private int lockId;

    public Unlock(int currentT, int lockId) {
        type = Type.UNLOCK;
        thread = currentT;
        this.lockId = lockId;
    }

    public int getLockId() {
        return lockId;
    }

    public String toString() {
        String res = "unlock(";
        if(isMainThread())
            res += "main,";
        else if(isServer())
            res += "server,";
        else
            res += thread + ",";
        res += lockId + ")";
        return res;
    }
}
