package src.callGraphAnalyze.element;

import org.apache.commons.collections.IteratorUtils;
import soot.grimp.internal.GIfStmt;
import soot.grimp.internal.GLookupSwitchStmt;
import soot.jimple.*;
import soot.tagkit.IntegerConstantValueTag;
import soot.tagkit.Tag;
import src.callGraphAnalyze.element.sourcesink.ISourceSink;
import src.callGraphAnalyze.element.sourcesink.Sink;
import src.callGraphAnalyze.element.sourcesink.Source;
import src.callGraphAnalyze.element.sourcesink.VUISink;
import javafx.util.Pair;
import soot.*;
import soot.jimple.infoflow.util.SystemClassHandler;
import soot.jimple.internal.*;
import soot.jimple.spark.pag.LocalVarNode;
import soot.jimple.spark.pag.PAG;
import soot.jimple.spark.sets.EmptyPointsToSet;
import soot.jimple.toolkits.callgraph.CallGraph;
import soot.jimple.toolkits.callgraph.Edge;
import soot.util.HashMultiMap;
import soot.util.MultiMap;
import soot.util.queue.QueueReader;

import java.io.IOException;
import java.util.*;

public class myCallgraph{
    private Set<SootClass> components;
    private SootMethod dummyMainMethod;
    private CallGraph callgraph;
    private myReachableMethods reachableMethods;
    private String apkIdPredix;
    private Set<SootClass> reachableClasses = new HashSet<>();
    private Set<SootMethod> processedReachableMethods = new HashSet<>();
    private Map<SootMethod, Set<Edge>> edgesIntoMethod = new HashMap<>();
    private Map<SootMethod, Set<Edge>> edgesOutOfMethod = new HashMap<>();
    private MultiMap<String, String> activityCallRelation = new HashMultiMap<>();
    private Set<SootMethod> importantFuncOnTrace = new HashSet<>();
    private Map<SootMethod, List<List<Pair<ISourceSink, Integer>>>> processedCallLists = new HashMap<>();
    private Set<SootMethod> methodOfResults = new HashSet<>();
    private Set<SootMethod> processedMethods = null;
    private Set<SootMethod> visitedMethods = null;
    private final int MAXDEPTH = 6;

    public myCallgraph(CallGraph initialCallGraph, myReachableMethods initialReachableMethods, Set<SootClass> entrypointClasses, SootMethod dummyMainMethod, String apkIdPredix) throws IOException {
        this.callgraph = initialCallGraph;
        this.reachableMethods = initialReachableMethods;
        this.components = entrypointClasses;
        this.dummyMainMethod = dummyMainMethod;
        this.apkIdPredix = apkIdPredix;
        addReachableClasses();
        addIccEdges();
//        addIccRetEdges();
        initImportantFuncs();
    }

    public myReachableMethods getReachableMethods() {return reachableMethods;}

    private void addReachableClasses() {
        if(reachableClasses == null)
            reachableClasses = new HashSet<>();
        for (Iterator<MethodOrMethodContext> iter = reachableMethods.listener(); iter.hasNext(); ) {
            SootMethod method = iter.next().method();
            SootClass sc = method.getDeclaringClass();
            reachableClasses.add(sc);
        }
        reachableClasses.addAll(components);
        Set<SootClass> temp = new HashSet<>();
        for(SootClass sc: reachableClasses) {
            for(SootClass sc0: Scene.v().getClasses()) {
                if (sc0.getName().contains(sc.getName() + "$")) {
                    temp.add(sc0);
                }
            }
        }
        reachableClasses.addAll(temp);
    }

    public Iterator<Edge> edgesInto(MethodOrMethodContext m) {
        Set<Edge> results = edgesInto(m.method());
        return results.iterator();
    }

    private Set<Edge> edgesInto(SootMethod m) {
        if(edgesIntoMethod.get(m) != null)
            return edgesIntoMethod.get(m);
        Set<Edge> results = new HashSet<>();
        Set<Edge> possibleResults = new HashSet<>();
        String name = m.getName();
        String declaringClassName = m.getDeclaringClass().getName();
        for(Iterator<Edge> it = callgraph.edgesInto(m); it.hasNext();) {
            Edge edge = it.next();
            SootMethod src = edge.src();
            Stmt stmt = edge.srcStmt();
            if((edge.isInstance() && !name.equals("onPreExecute") && !name.equals("doInBackground") && !name.equals("onPostExecute")|| edge.kind().isExecutor())
                    && !src.getDeclaringClass().getName().equals("dummyMainClass")) {
                boolean addedge = false;
                if(name.equals("run")){
                    if(stmt.getInvokeExpr().getArgCount() >= 1) {//post
                        Set<SootMethod> methods = findRunMethodForPost(src, stmt);
                        if (methods.contains(m)) {
                            results.add(edge);
                            addedge = true;
                        } else if (results.isEmpty()
                                && methods.isEmpty()
                                && declaringClassName.contains("$")
                                && declaringClassName.substring(0, declaringClassName.indexOf("$")).equals(src.getDeclaringClass().getName())) {
                            possibleResults.add(edge);
                        }
                    } else if(stmt.getInvokeExpr().getArgCount() == 0) {//start
                        Set<SootMethod> methods = findRunMethodForThreadStart(src, stmt);
                        if (methods.contains(m)) {
                            results.add(edge);
                            addedge = true;
                        } else if (results.isEmpty()
                                && methods.isEmpty()
                                && declaringClassName.contains("$")
                                && declaringClassName.substring(0, declaringClassName.indexOf("$")).equals(src.getDeclaringClass().getName())) {
                            possibleResults.add(edge);
                        }
                    }
                } else {
                    for (Unit u : src.getActiveBody().getUnits()) {
                        Stmt s = (Stmt) u;
                        SootMethod tgt = getMethodFromStmt(s);
                        if (tgt != null) {
                            String className = tgt.getDeclaringClass().getName();
                            if ((tgt.isAbstract()
                                    && !className.startsWith("android.")
                                    && !className.startsWith("java.")
                                    && !className.startsWith("javax.")
                                    && tgt.getSubSignature().equals(m.getSubSignature()) || tgt.getSignature().equals(m.getSignature()))) {
                                results.add(edge);
                                addedge = true;
                                break;
                            }
                        }
                    }
                }
                if(!addedge) {
                    // System.out.println("delete edge " + edge);
                }
            } else {
                results.add(edge);
            }
        }
        if(name.equals("run") && results.isEmpty()) {
            results.addAll(possibleResults);
        }
        edgesIntoMethod.put(m, results);
        return results;
    }

    public Iterator<Edge> edgesOutOf(MethodOrMethodContext m) {
        if(m == null)
            return Collections.emptyIterator();
        return edgesOutOf(m.method()).iterator();
    }

    private Set<Edge> edgesOutOf(SootMethod method) {
        if(method == null || !method.isConcrete() || !isValidSeedMethod(method))
            return Collections.emptySet();//empty iterator
        if(edgesOutOfMethod.get(method) != null)
            return edgesOutOfMethod.get(method);
        Set<Edge> results = new HashSet<>();
        Set<Edge> runResults = new HashSet<>();
        Set<Edge> possibleResults = new HashSet<>();
        Set<SootMethod> addedTgts = new HashSet<>();
        Iterator<Edge> edges = callgraph.edgesOutOf(method);
        if(!edges.hasNext() && method.isConcrete() && isValidSeedMethod(method)) {
            if(!method.hasActiveBody()){
                method.retrieveActiveBody();
            }
            PatchingChain<Unit> units = method.getActiveBody().getUnits();
            for(Unit u: units) {
                Stmt srcStmt = (Stmt) u;
                SootMethod tgt = getMethodFromStmt(srcStmt);
                if(tgt != null) {
                    callgraph.addEdge(new Edge(method, srcStmt, tgt));
                }
            }
            edges = callgraph.edgesOutOf(method);
        }
        for(Iterator<Edge> it = edges; it.hasNext();) {
            Edge edge = it.next();
            SootMethod tgt = edge.tgt();
            String name = tgt.getName();
            Stmt stmt = edge.srcStmt();
            String declaringClassName = tgt.getDeclaringClass().getName();
            if(edge.isInstance() && !name.equals("onPreExecute") && !name.equals("doInBackground") && !name.equals("onPostExecute") || edge.kind().isExecutor()) {
//                boolean addedge = false;
                if(name.equals("run") && stmt.getInvokeExpr().getArgCount() >= 1) {
                    Set<SootMethod> methods = findRunMethodForPost(method, stmt);
                    if(methods.contains(tgt)) {
                        runResults.add(edge);
//                        addedge = true;
                    } else if(methods.isEmpty()
                            && declaringClassName.contains("$")
                            && declaringClassName.substring(0, declaringClassName.indexOf("$")).equals(method.getDeclaringClass().getName())) {
                        possibleResults.add(edge);
                    }
                }
                else {
                    SootMethod sm = getMethodFromStmt(stmt);
                    if(sm != null) {
                        String declaringClassNameOfStmt = sm.getDeclaringClass().getName();
                        if(addedTgts.contains(sm))
                            continue;
                        if(tgt.equals(sm)) {
                            results.add(edge);
                            addedTgts.add(sm);
                        }
                        else if(!declaringClassNameOfStmt.startsWith("android.")
                                && !declaringClassNameOfStmt.startsWith("androidx.")
                                && (!declaringClassNameOfStmt.startsWith("java.") || declaringClassNameOfStmt.equals("java.util.concurrent.Future"))
                                && !declaringClassNameOfStmt.startsWith("javax.")
                                && tgt.getSubSignature().equals(sm.getSubSignature())) {
                            Edge edge1 = new Edge(method, stmt, sm);
                            results.add(edge1);
                            addedTgts.add(sm);
                        }
                    }
                }
            } else {
                results.add(edge);
            }
        }
        if(runResults.isEmpty()) {
            results.addAll(possibleResults);
        } else
            results.addAll(runResults);
        edgesOutOfMethod.put(method, results);
        return results;
    }

    public Set<SootMethod> addGUICallbacks() {
        Set<SootMethod> guiSourcesExpected = new HashSet<>();
        Queue<SootMethod> workList = new LinkedList<>();
        //add important callbacks, like onClick to guiExpectedCallbacks
        List<String> onClickMethods = Arrays.asList(
                "void onClick(android.view.View)",
                "boolean onLongClick(android.view.View)",
                "boolean onTouchEvent(android.view.MotionEvent)"
        );
        SootClass onClickClass = Scene.v().getSootClass("android.view.View$OnClickListener");
        Set<SootClass> guiCallbackClasses = new HashSet<>(Scene.v().getActiveHierarchy().getDirectImplementersOf(onClickClass));
        onClickClass = Scene.v().getSootClass("android.view.View$OnLongClickListener");
        guiCallbackClasses.addAll(Scene.v().getActiveHierarchy().getDirectImplementersOf(onClickClass));
        onClickClass = Scene.v().getSootClass("android.view.View");
        guiCallbackClasses.addAll(Scene.v().getActiveHierarchy().getDirectSubclassesOf(onClickClass));
        for(SootClass onClickClassImplement: guiCallbackClasses) {
            if(onClickClassImplement.isInterface())
                continue;
            for(SootMethod sm: onClickClassImplement.getMethods()) {
                if(onClickMethods.contains(sm.getSubSignature())) {
                    guiSourcesExpected.add(sm);
                    if(!reachableMethods.contains(sm) || !callgraph.edgesOutOf(sm).hasNext()) {
                        reachableMethods.addMethod(sm);
                        workList.offer(sm);
                    }
                }
            }
        }

        while(!workList.isEmpty()) {
            SootMethod sm = workList.poll();
            if (isValidSeedMethod(sm) && sm.isConcrete()) {
                if(!sm.hasActiveBody()){
                    sm.retrieveActiveBody();
                }
                workList.addAll(addMethodBodyAndRetNewMethods(sm));
            }
        }
        return guiSourcesExpected;
    }

    public void addVUISourcesToCallgraph(Set<String> vuiSourcesExpected) throws IOException {
        Queue<SootMethod> workList = new LinkedList<>();

        Set<String> imptMethods = new HashSet<>(vuiSourcesExpected);
        addReachableClasses();

        for(String vuiSubSig: imptMethods) {
            for(SootClass sc: reachableClasses) {
                if(sc.getName().startsWith("android.") || sc.getName().startsWith("java."))
                    continue;
                boolean hasVUICallback = false;
                for (SootMethod sm : sc.getMethods()) {
                    boolean isAndroid = false;
                    SootClass androidVUIClass = Scene.v().getSootClassUnsafe("android.speech.RecognitionListener");
                    if(androidVUIClass != null && androidVUIClass.isInterface()) {
                        for (SootClass VUIClass: Scene.v().getActiveHierarchy().getDirectImplementersOf(androidVUIClass)) {
                            if(VUIClass.getName().equals(sc.getName())) {
                                isAndroid = true;
                                break;
                            }
                        }
                    }
                    if(isAndroid)
                        break;
                    if ((vuiSubSig.startsWith("<") && sm.getSignature().equals(vuiSubSig)
                            || !vuiSubSig.startsWith("<") && sm.getSubSignature().equals(vuiSubSig))
                            && !reachableMethods.contains(sm)) {
                        reachableMethods.addMethod(sm);
                        hasVUICallback = true;
                        workList.add(sm);
                    }
                }
                if(hasVUICallback) {
                    // if the VUI callback is found and not in reachable methods,
                    // add the other methods defined in the same class/outer class to the call graph & reachable methods
                    for (SootMethod sm: sc.getMethods()) {
                        if (!reachableMethods.contains(sm)) {
                            reachableMethods.addMethod(sm);
                            workList.add(sm);
                        }
                    }
                    if(sc.getName().contains("$")) {
                        SootClass outerClass = Scene.v().getSootClassUnsafe(sc.getName().split("\\$")[0]);
                        if(outerClass != null) {
                            for (SootMethod sm: outerClass.getMethods()) {
                                if (!reachableMethods.contains(sm)) {
                                    reachableMethods.addMethod(sm);
                                    workList.add(sm);
                                }
                            }
                        }
                    }
                }
            }
        }

        while(!workList.isEmpty()) {
            SootMethod sm = workList.poll();
            if (isValidSeedMethod(sm) && sm.isConcrete()) {
                if(!sm.hasActiveBody()){
                    sm.retrieveActiveBody();
                }
                workList.addAll(addMethodBodyAndRetNewMethods(sm));
            }
        }
    }

    public void addVUISinksToCallgraph(Set<SootMethod> vuiSinks) throws IOException {
        //reachableMethods.update();
        Set<SootMethod> imptMethods = new HashSet<>(vuiSinks);

        for (Iterator<MethodOrMethodContext> iter = reachableMethods.listener(); iter.hasNext();) {
            SootMethod src = iter.next().method();
            //writeToFiles(outputBasePath + "reachableMethods.txt", src.getSignature());

            if (isValidSeedMethod(src) && src.hasActiveBody()) {
                PatchingChain<Unit> units = src.getActiveBody().getUnits();
                for (Unit u : units) {
                    Stmt stmt = (Stmt) u;
                    if(stmt instanceof JInvokeStmt
                            && stmt.getInvokeExprBox() instanceof InvokeExprBox
                            && stmt.getInvokeExprBox().getValue() instanceof JVirtualInvokeExpr) {
                        InvokeExprBox expr = (InvokeExprBox) stmt.getInvokeExprBox();
                        SootMethod tgt = ((JVirtualInvokeExpr) expr.getValue()).getMethod();
                        for (SootMethod imptMethod: imptMethods) {
                            if (tgt.getSubSignature().equals(imptMethod.getSubSignature())) {
                                callgraph.addEdge(new Edge(src, stmt, tgt));
                            }
                        }
                        if(tgt.getSubSignature().equals("java.util.ArrayList getStringArrayListExtra(java.lang.String)")){
                            callgraph.addEdge(new Edge(src, stmt, tgt));
                        }
                    }
                    if(stmt instanceof JAssignStmt
                            && ((JAssignStmt) stmt).getRightOp() instanceof JVirtualInvokeExpr) {
                        JVirtualInvokeExpr expr = (JVirtualInvokeExpr) ((JAssignStmt) stmt).getRightOp();
                        SootMethod tgt = expr.getMethod();
                        if(tgt.getSubSignature().equals("java.util.ArrayList getStringArrayListExtra(java.lang.String)")){
                            callgraph.addEdge(new Edge(src, stmt, tgt));
                        }
                    }
                }
            }
        }
    }

    private void addIccEdges() {
        Queue<SootMethod> workList = new LinkedList<>();

        for (Iterator<MethodOrMethodContext> iter = reachableMethods.listener(); iter.hasNext(); ) {
            SootMethod src = iter.next().method();
            if (isValidSeedMethod(src) && src.isConcrete()){
                if(!src.hasActiveBody()) {
                    src.retrieveActiveBody();
                }
                workList.addAll(addMethodBodyAndRetNewMethods(src));
            }
        }

//        while(!workList.isEmpty()){
//            SootMethod sootMethod = workList.poll();
//            workList.addAll(addMethodBodyAndRetNewMethods(sootMethod));
//
//            SootClass sc = sootMethod.getDeclaringClass();
//
//            // We model this as follows: Whenever the user overwrites a method in an
//            // Android OS class, we treat it as a potential callback.
//            Map<String, SootMethod> systemMethods = new HashMap<>(10000);
//            if(sc.isInterface())
//                continue;
//            for (SootClass parentClass : Scene.v().getActiveHierarchy().getSuperclassesOf(sc)) {
//                if (parentClass.getName().startsWith("android."))
//                    for (SootMethod sm : parentClass.getMethods())
//                        if (!sm.isConstructor())
//                            systemMethods.put(sm.getSubSignature(), sm);
//            }
//            for(SootMethod sm: sc.getMethods()){
//                // Scan for methods that overwrite parent class methods
//                if (!sm.isConstructor()) {
//                    SootMethod parentMethod = systemMethods.get(sm.getSubSignature());
//                    if (parentMethod != null) {
//                        // sm: This is a real callback method
//                        if(!reachableMethods.contains(sm)) {
//                            reachableMethods.addMethod(sm);
//                            if (isValidSeedMethod(sm) && sm.isConcrete()) {
//                                if(!sm.hasActiveBody()) {
//                                    sm.retrieveActiveBody();
//                                }
//                                workList.addAll(addMethodBodyAndRetNewMethods(sm));
//                            }
//                        }
//                    }
//                }
//            }
//        }

        return;
    }

    private void addIccRetEdges() {
        //class1 starts class2
        //class2: setResult(xx, xxx) -> class1: onActivityResult()
        for(String class2: activityCallRelation.keySet()) {
            SootClass class2Body = Scene.v().getSootClass(class2);
            boolean findSetResult = false;
            for(SootMethod src: class2Body.getMethods()) {
                if (isValidSeedMethod(src) && src.isConcrete()){
                    if(!src.hasActiveBody()) {
                        src.retrieveActiveBody();
                    }
                    PatchingChain<Unit> units = src.getActiveBody().getUnits();
                    for (Unit u : units) {
                        Stmt stmt = (Stmt) u;
                        SootMethod method = getMethodFromStmt(stmt);
                        if(method != null && (method.getSubSignature().equals("void setResult(int,android.content.Intent)") || method.getSubSignature().equals("void setResult(int)"))) {
                            findSetResult = true;
                            for(String class1: activityCallRelation.get(class2)) {
                                String signature = "<" + class1 + ": void onActivityResult(int,int,android.content.Intent)>";
                                SootMethod tgt = Scene.v().grabMethod(signature);
                                if(tgt != null) {
                                    callgraph.addEdge(new Edge(src, stmt, tgt));
                                    //System.out.println("add edge: " + src + " to " + tgt);
                                }
                            }
                            break;
                        }
                    }
                }
                if(findSetResult)
                    break;
            }
            if(!findSetResult) {
                Set<SootClass> innerClasses = new HashSet<>();
                for(SootClass sc: Scene.v().getClasses()) {
                    if(sc.getName().contains(class2 + "$"))
                        innerClasses.add(sc);
                }
                for(SootClass sc: innerClasses) {
                    for(SootMethod src: sc.getMethods()) {
                        if (isValidSeedMethod(src) && src.isConcrete()){
                            if(!src.hasActiveBody()) {
                                src.retrieveActiveBody();
                            }
                            PatchingChain<Unit> units = src.getActiveBody().getUnits();
                            for (Unit u : units) {
                                Stmt stmt = (Stmt) u;
                                SootMethod method = getMethodFromStmt(stmt);
                                if(method != null && (method.getSubSignature().equals("void setResult(int,android.content.Intent)") || method.getSubSignature().equals("void setResult(int)"))) {
                                    findSetResult = true;
                                    for(String class1: activityCallRelation.get(class2)) {
                                        String signature = "<" + class1 + ": void onActivityResult(int,int,android.content.Intent)>";
                                        SootMethod tgt = Scene.v().grabMethod(signature);
                                        if(tgt != null) {
                                            callgraph.addEdge(new Edge(src, stmt, tgt));
                                            //System.out.println("add edge: " + src + " to " + tgt);
                                        }
                                    }
                                    break;
                                }
                            }
                        }
                        if(findSetResult)
                            break;
                    }
                }
            }
        }
    }

    public Set<SootClass> addMethodsInReachableClasses(SootMethod initMethod) {
        Set<SootClass> results = new HashSet<>();
        for (SootClass sc : reachableClasses) {
            for (SootMethod sm : sc.getMethods()) {
                if (!reachableMethods.contains(sm) && sm.isConcrete() && isValidSeedMethod(sm)) {
                    for (Iterator<Edge> it = edgesOutOf((MethodOrMethodContext) sm); it.hasNext();) {
                        Edge edge = it.next();
                        SootMethod tgt = edge.tgt();
                        if (tgt != null && tgt.getSignature().equals(initMethod.getSignature())) {
                            reachableMethods.addMethod(sm);
                            Queue<SootMethod> workList = new LinkedList<>(addMethodBodyAndRetNewMethods(sm));
                            while (!workList.isEmpty()) {
                                SootMethod current = workList.poll();
                                if (isValidSeedMethod(current) && current.isConcrete()) {
                                    if (!current.hasActiveBody()) {
                                        current.retrieveActiveBody();
                                    }
                                    workList.addAll(addMethodBodyAndRetNewMethods(current));
                                }
                            }
                            results.add(sc);
                        }
                    }
                }
            }
        }
        return results;
    }

    private List<SootMethod> addMethodBodyAndRetNewMethods(SootMethod src) {
        //find new Intent(context, class2) in reachable methods defined in <class 1: method 1>
        //add icc edges: <class 1: method 1> => <class 2: void onCreate/onStart(...)>
        //add <class 2: void onCreate(...)> to reachable methods, workList
//        String class1 = src.getDeclaringClass().getName();
        List<SootMethod> workList = new LinkedList<>();
//        SootMethod methd = Scene.v().grabMethod("<android.content.Intent: void <init>(android.content.Context,java.lang.Class)>");
//        if(!isValidSeedMethod(src) || !src.isConcrete() || processedReachableMethods.contains(src))
//            return workList;
//        if(!src.hasActiveBody())
//            src.retrieveActiveBody();
//        processedReachableMethods.add(src);
//        //add <class 1: void onCreate()> to workList
//        String signature = "<" + class1 + ": void onCreate(android.os.Bundle)>";
//        SootMethod onCreateForClass1 = Scene.v().grabMethod(signature);
//        if(onCreateForClass1 != null
//                && !src.equals(onCreateForClass1)
//                && (!reachableMethods.contains(onCreateForClass1) || !callgraph.edgesOutOf(onCreateForClass1).hasNext())) {
//            workList.add(onCreateForClass1);
//            reachableMethods.addMethod(onCreateForClass1);
//        }
        PatchingChain<Unit> units = src.getActiveBody().getUnits();
        for (Unit u : units) {
            Stmt stmt = (Stmt) u;
            SootMethod method = getMethodFromStmt(stmt);
            if(method == null)
                continue;
            Set<SootMethod> tgts = new HashSet<>();
//            if (stmt instanceof JInvokeStmt
//                    && stmt.getInvokeExprBox() instanceof InvokeExprBox
//                    && stmt.getInvokeExprBox().getValue() instanceof JSpecialInvokeExpr
//                    && method.getSubSignature().equals(methd.getSubSignature())
//                    && ((JSpecialInvokeExpr)stmt.getInvokeExprBox().getValue()).getArg(1) instanceof ClassConstant){
//                tgts = findOnCreateMethodForStartActivity(stmt, class1);
//                if (tgts.isEmpty()) {
//                    System.out.println("The onCreate method for " + method + " does not exist!");
//                    //System.exit(-1);
//                }
//            }
            if ((method.getName().equals("postDelayed") && stmt.getInvokeExpr().getArgCount() == 1)
                    || (method.getName().equals("post") && stmt.getInvokeExpr().getArgCount() >= 2)
                    || (method.getName().equals("runOnUiThread") && stmt.getInvokeExpr().getArgCount() == 1)) {
                // add handler.post/runOnUiThread/postDelayed(class 1, 1500) -> class 1.run()
                tgts = findRunMethodForPost(src, stmt);
//                System.out.println(method.getName() + " :" + stmt.getInvokeExpr().getClass());
            }
            else if(method.getName().equals("start") && method.getDeclaringClass().getName().toLowerCase().contains("thread") && stmt.getInvokeExpr().getArgCount() == 0) {
                tgts = findRunMethodForThreadStart(src, stmt);
//                System.out.println(method.getName() + " :" + stmt.getInvokeExpr().getClass());
            }
            else if(method.getName().equals("execute")) {
                // add class1.execute(xxx) -> class 1: onPreExecute, doInBackground, onPostExecute
                tgts = findTgtsForExecute(stmt);
//                System.out.println(method.getName() + " :" + stmt.getInvokeExpr().getClass());
            }
            else {
                tgts.add(method);
            }
            if(!tgts.isEmpty()) {
                for(SootMethod tgt: tgts) {
                    boolean hasEdge = false;
                    for (Iterator<Edge> iter = callgraph.edgesOutOf(src); iter.hasNext(); ) {
                        Edge edge = iter.next();
                        if (edge.srcStmt() != null && edge.getTgt() != null && edge.srcStmt().toString().equals(stmt.toString()) && edge.getTgt().equals(tgt)) {
                            hasEdge = true;
                            break;
                        }
                    }
                    if (!hasEdge) {
                        callgraph.addEdge(new Edge(src, stmt, tgt));
                    }
                    if(!reachableMethods.contains(tgt) || !callgraph.edgesOutOf(tgt).hasNext()) {
                        workList.add(tgt);
                        reachableMethods.addMethod(tgt);
                    }
                }
            }
        }
        return workList;
    }

    private Set<SootMethod> findOnCreateMethodForStartActivity(Stmt stmt, String class1) {
        Set<SootMethod> tgts = new HashSet<>();
        JSpecialInvokeExpr expr = ((JSpecialInvokeExpr) stmt.getInvokeExprBox().getValue());
        //Icc Target
        String className0 = ((ClassConstant) expr.getArg(1)).getValue();
        String class2 = className0.substring(1, className0.length() - 1).replace("/", ".");//the class to start
        if(SystemClassHandler.v().isClassInSystemPackage(class2))
            return tgts;
        activityCallRelation.put(class2, class1);//class 2 is called by class 1
        String signature = "<" + class2 + ": void onCreate(android.os.Bundle)>";
        SootMethod newOnCreateMethod = Scene.v().grabMethod(signature);
        if (newOnCreateMethod == null) {
            signature = "<" + class2 + ": void onStart()>";
            newOnCreateMethod = Scene.v().grabMethod(signature);
        }
        if (newOnCreateMethod == null) {
            SootClass sootClass = Scene.v().getSootClass(class2);
            for (SootMethod sm : sootClass.getMethods()) {
                if (sm.getName().startsWith("on")) {
                    boolean relateToIntent = false;
                    for (Type type : sm.getParameterTypes()) {
                        if (type.toString().equals("android.content.Intent")) {
                            relateToIntent = true;
                            break;
                        }
                    }
                    if (relateToIntent) {
                        newOnCreateMethod = sm;
                        break;
                    }
                }
            }
        }
        if(newOnCreateMethod != null)
            tgts.add(newOnCreateMethod);
        return tgts;
    }

    private Set<SootMethod> findRunMethodForPost(SootMethod src, Stmt stmt) {
        Set<SootMethod> tgts = new HashSet<>();
        Value arg = stmt.getInvokeExpr().getArg(0);
        String runnableClassName = arg.getType().toString();
        SootMethod runMethod = null;
        if(runnableClassName.equals("java.lang.Runnable")) {
            if(arg instanceof JimpleLocal) {
                PatchingChain<Unit> units = src.getActiveBody().getUnits();
                Unit u = units.getPredOf(stmt);
                while (u != null) {
                    Stmt st = (Stmt) u;
                    if(st instanceof JAssignStmt && ((JAssignStmt) st).getLeftOp().equivTo(arg)) {
                        Value rightArg = ((JAssignStmt) st).getRightOp();
                        runnableClassName = rightArg.getType().toString();
                        SootClass runnableClass = Scene.v().getSootClassUnsafe(runnableClassName);
                        if (runnableClass != null && runnableClass.isConcrete()) {
                            String runMethodName = "<" + runnableClassName + ": void run()>";
                            runMethod = Scene.v().grabMethod(runMethodName);
                        }
                        if(runMethod != null)
                            break;
                    }
                    u = units.getPredOf(st);
                }
            }
        } else {
            SootClass runnableClass = Scene.v().getSootClassUnsafe(runnableClassName);
            if (runnableClass != null && runnableClass.isConcrete()) {
                String runMethodName = "<" + runnableClassName + ": void run()>";
                runMethod = Scene.v().grabMethod(runMethodName);
            }
        }
        if(runMethod != null)
            tgts.add(runMethod);
        return tgts;
    }

    private Set<SootMethod> findRunMethodForThreadStart(SootMethod src, Stmt stmt) {
        Set<SootMethod> tgts = new HashSet<>();
        Value base = getBase(stmt);//base.start()
        SootMethod runMethod = null;
        if(base != null && Scene.v().getSootClassUnsafe(base.getType().toString()) != null) {//base: new Thread(p) or new xxxThread()
            SootClass tgtClass = Scene.v().getSootClassUnsafe(base.getType().toString());
            if(tgtClass.getName().equals("java.lang.Thread")) {
                PatchingChain<Unit> units = src.getActiveBody().getUnits();
                Unit u = units.getPredOf(stmt);
                while (u != null) {
                    Stmt s = (Stmt) u;
                    SootMethod sm = getMethodFromStmt(s);
                    if(sm != null && sm.getName().equals("<init>") && sm.getDeclaringClass().toString().equals("java.lang.Thread")) {//new Thread(p)
                        for(int i = 0; i < sm.getParameterTypes().size(); ++i) {
                            Type t = sm.getParameterType(i);
                            if(t.toString().equals("java.lang.Runnable")) {//find p
                                Value runnableArg = s.getInvokeExpr().getArg(i);
                                String runnableClassName = runnableArg.getType().toString();
                                String runMethodName = "<" + runnableClassName + ": void run()>";
                                runMethod = Scene.v().grabMethod(runMethodName);
                                break;
                            }
                        }
                        if(runMethod != null)
                            break;
                    }
                    u = units.getPredOf(u);
                }
            } else {
                String threadClassName = tgtClass.getName(); //new xxxThread()
                String runMethodName = "<" + threadClassName + ": void run()>";
                runMethod = Scene.v().grabMethod(runMethodName);
            }
        }
        if(runMethod != null)
            tgts.add(runMethod);
        return tgts;
    }

    private Set<SootMethod> findTgtsForExecute(Stmt stmt) {
        Set<SootMethod> tgts = new HashSet<>();
        Value base = getBase(stmt);
        if(base != null && Scene.v().getSootClassUnsafe(base.getType().toString()) != null) {
            SootClass tgtClass = Scene.v().getSootClassUnsafe(base.getType().toString());
            if(tgtClass.isConcrete()) {
                for(SootMethod sm: tgtClass.getMethods()) {
                    if(sm.getName().equals("onPreExecute"))
                        tgts.add(sm);
                    if(sm.getName().equals("doInBackground"))
                        tgts.add(sm);
                    if(sm.getName().equals("onPostExecute"))
                        tgts.add(sm);
                }
            }
        }
        return tgts;
    }

    private void initImportantFuncs() {
        String[] signatures = {
                "<androidx.fragment.app.DialogFragment: void show(androidx.fragment.app.FragmentManager,java.lang.String)>",
                "<androidx.fragment.app.DialogFragment: int show(androidx.fragment.app.FragmentTransaction,java.lang.String)>",
                "<androidx.fragment.app.DialogFragment: void showNow(androidx.fragment.app.FragmentManager,java.lang.String)>",
                "<androidx.fragment.app.DialogFragment: void dismiss()>",
                "<androidx.fragment.app.DialogFragment: void dismissAllowingStateLoss()>",
                "<androidx.fragment.app.DialogFragment: void dismissNow()>",
                "<android.app.Dialog: void show()>",
                "<android.app.Dialog: void cancel()>",
                "<android.app.Dialog: void dismiss()>",
                "<android.app.Dialog: void hide()>",
                "<java.util.concurrent.locks.ReentrantLock: void lock()>",
                "<java.util.concurrent.locks.ReentrantLock: void unlock()>",
                "<java.util.concurrent.locks.ReentrantReadWriteLock.ReadLock: void lock()>",
                "<java.util.concurrent.locks.ReentrantReadWriteLock.ReadLock: void unlock()>",
                "<java.util.concurrent.locks.ReentrantReadWriteLock.WriteLock: void lock()>",
                "<java.util.concurrent.locks.ReentrantReadWriteLock.WriteLock: void unlock()>",
                "<android.speech.SpeechRecognizer: void stopListening()>",
                "<android.speech.SpeechRecognizer: void startListening(android.content.Intent)>",
                "<android.speech.SpeechRecognizer: void cancel()>",
                "<com.huawei.hiai.asr.AsrRecognizer: void stopListening()>",
                "<com.huawei.hiai.asr.AsrRecognizer: void startListening(android.content.Intent)>",
                "<com.huawei.hiai.asr.AsrRecognizer: void cancel()>",
                "<com.baidu.speech.EventManager: void send(java.lang.String,java.lang.String,byte[],int,int)>",
                "<com.baidu.aip.asrwakeup3.core.recog.MyRecognizer: void start(java.util.Map)>",
                "<com.alibaba.idst.nui.NativeNui: int stopDialog()>",
                "<com.alibaba.idst.nui.NativeNui: int startDialog(com.alibaba.idst.nui.Constants$VadMode,java.lang.String)>",
                "<com.tencent.aai.AAIClient: void stopAudioRecognize()>",
                "<com.tencent.aai.AAIClient: boolean stopAudioRecognize(int)>",
                "<com.tencent.aai.AAIClient: void startAudioRecognize(com.tencent.aai.model.AudioRecognizeRequest,com.tencent.aai.listener.AudioRecognizeResultListener,com.tencent.aai.listener.AudioRecognizeStateListener,com.tencent.aai.listener.AudioRecognizeTimeoutListener,com.tencent.aai.model.AudioRecognizeConfiguration)>",
                "<com.tencent.aai.AAIClient: void startAudioRecognize(com.tencent.aai.model.AudioRecognizeRequest,com.tencent.aai.listener.AudioRecognizeResultListener,com.tencent.aai.listener.AudioRecognizeStateListener,com.tencent.aai.model.AudioRecognizeConfiguration)>",
                "<com.tencent.aai.AAIClient: void startAudioRecognize(com.tencent.aai.model.AudioRecognizeRequest,com.tencent.aai.listener.AudioRecognizeResultListener,com.tencent.aai.model.AudioRecognizeConfiguration)>",
                "<com.tencent.aai.AAIClient: void cancelAudioRecognize()>",
                "<com.tencent.aai.AAIClient: boolean cancelAudioRecognize(int)>",
                "<com.microsoft.cognitiveservices.speech.SpeechRecognizer: java.util.concurrent.Future recognizeOnceAsync()>"
//                "<android.view.View: void setVisibility(int)>"
        };
        for(String sig: signatures){
            SootMethod sm = Scene.v().grabMethod(sig);
            if(sm != null)
                importantFuncOnTrace.add(sm);
        }
    }

    public Set<SootMethod> getImportantFuncs() { return importantFuncOnTrace; }
//    public List<List<ISourceSink>> analyzeCallGraphForSourceSinks(boolean isTopDown, Set<SootMethod> sources, Set<SootMethod> sinks) throws IOException {
//        List<List<ISourceSink>> results = new LinkedList<>();
//        Set<SootMethod> methodOfResults = new HashSet<>();
//        Set<SootMethod> expectedEnd;
//        Set<SootMethod> realEnd = new HashSet<>();
//
//        Set<SootMethod> methods = new HashSet<>();
//        Queue<Pair<SootMethod, Boolean>> workList = new LinkedList<>();
//        if (isTopDown) {
//            for(SootMethod sootMethod: sources) {
//                workList.offer(new Pair<>(sootMethod, true));
//            }
//            expectedEnd = sinks;
//        } else {
//            for(SootMethod sootMethod: sinks) {
//                //suppose that sink is not in main thread
//                workList.offer(new Pair<>(sootMethod, false));
//            }
//            expectedEnd = sources;
//        }
//
//        while (!workList.isEmpty()) {
//            Pair<SootMethod, Boolean> pair = workList.poll();
//            SootMethod method = pair.getKey();
//            boolean isInMainThread = pair.getValue();
//            if (methods.contains(method))
//                continue;
//            methods.add(method);
//            Iterator<Edge> edges;
//            if (isTopDown)
//                edges = edgesOutOf(method);
//            else
//                edges = edgesInto(method);
//
//            for (Iterator<Edge> it = edges; it.hasNext(); ) {
//                Edge edge = it.next();
//                SootMethod srcOrTgt;
//                if (isTopDown)
//                    srcOrTgt = edge.tgt();
//                else
//                    srcOrTgt = edge.src();
//                if(srcOrTgt != null) {
//                    boolean isResult = false;
//                    for (Iterator<SootMethod> iter = expectedEnd.iterator(); iter.hasNext(); ) {
//                        if (srcOrTgt.getSubSignature().equals(iter.next().getSubSignature())) {
//                            isResult = true;
//                            break;
//                        }
//                    }
//                    if (isResult) {
//                        if (isTopDown) {
//                            if(methodOfResults.contains(srcOrTgt))
//                                continue;
//                            methodOfResults.add(srcOrTgt);
//                            VUISink sink = new VUISink(srcOrTgt, edge.srcStmt(), edge.src());
//                            sink.setInMainThread(isInMainThread);
//                            results.add(Collections.singletonList(sink));
//                            realEnd.add(srcOrTgt);
//                        } else {
//                            if(methodOfResults.contains(srcOrTgt))
//                                continue;
//                            methodOfResults.add(srcOrTgt);
//                            Source source = new Source(srcOrTgt);
//                            source.setInMainThread(isInMainThread);
//                            results.add(Collections.singletonList(source));
//                            realEnd.add(srcOrTgt);
//                        }
//                    }
//                    else {
//                        String declaringClassName = srcOrTgt.getDeclaringClass().getName();
//                        String declaringClassOfTgt = method.getDeclaringClass().getName();
//                        if (isTopDown) {
//                            if (!declaringClassName.startsWith("java.")
//                                    && !declaringClassName.startsWith("android.")
//                                    && !declaringClassName.startsWith("javax.")
//                                    && (!declaringClassName.startsWith("androidx") || isStartFragment(srcOrTgt) || isCloseFragment(srcOrTgt)  || declaringClassOfTgt.startsWith("androidx"))) {
//                                if (srcOrTgt.isAbstract()) {
//                                    SootClass declaringClass = srcOrTgt.getDeclaringClass();
//                                    List<SootClass> implementClasses;
//                                    if (declaringClass.isInterface())
//                                        implementClasses = Scene.v().getActiveHierarchy().getDirectImplementersOf(declaringClass);
//                                    else
//                                        implementClasses = Scene.v().getActiveHierarchy().getDirectSubclassesOf(declaringClass);
//                                    for (SootClass implementClass : implementClasses) {
//                                        for (SootMethod sm : implementClass.getMethods()) {
//                                            if (sm.getSubSignature().equals(srcOrTgt.getSubSignature())) {
//                                                workList.offer(new Pair<>(sm, isInMainThread));
//                                                break;
//                                            }
//                                        }
//                                    }
//                                } else {
//                                    SootMethod methodOfStmt = getMethodFromStmt(edge.srcStmt());
//                                    if(methodOfStmt != null
//                                            && methodOfStmt.getName().equals("start")
//                                            && srcOrTgt.getName().equals("run"))
//                                        // if methodOfStmt is start && srcOrTgt is run, set the inMainThread to false
//                                        workList.offer(new Pair<>(srcOrTgt, false));
//                                    else if(methodOfStmt != null
//                                            && methodOfStmt.getName().equals("execute")
//                                            && srcOrTgt.getName().equals("doInBackground")) {
//                                        // if srcOrTgt is doInBackground, set the inMainThread to false
//                                        workList.offer(new Pair<>(srcOrTgt, false));
//                                    }
//                                    else
//                                        workList.offer(new Pair<>(srcOrTgt, isInMainThread));
//                                }
//                            }
//                        } else {
//                            if (!declaringClassName.startsWith("java.")
//                                    && !declaringClassName.startsWith("android.")
//                                    && !declaringClassName.startsWith("javax.")
//                                    && (!declaringClassName.startsWith("androidx") || declaringClassOfTgt.startsWith("androidx"))) {
//                                SootMethod methodOfStmt = getMethodFromStmt(edge.srcStmt());
//                                if (methodOfStmt != null
//                                        && methodOfStmt.getName().equals("start")
//                                        && method.getName().equals("run"))
//                                    // if methodOfStmt is start && method is run, set the inMainThread to true
//                                    workList.offer(new Pair<>(srcOrTgt, true));
//                                else if (methodOfStmt != null
//                                        && methodOfStmt.getName().equals("execute")
//                                        && method.getName().equals("doInBackground")) {
//                                    // if method is doInBackground, set the inMainThread to true
//                                    workList.offer(new Pair<>(srcOrTgt, true));
//                                } else
//                                    workList.offer(new Pair<>(srcOrTgt, isInMainThread));
//                            }
//                        }
//                    }
//                }
//            }
//        }
//        return results;
//    }

    public boolean hasBrunch(SootMethod method) {
        return false;
//        if(method.isConcrete() && isValidSeedMethod(method)) {
//            if(!method.hasActiveBody()){
//                method.retrieveActiveBody();
//            }
//            PatchingChain<Unit> units = method.getActiveBody().getUnits();
//            for(Unit u: units) {
//                Stmt srcStmt = (Stmt) u;
//                if(srcStmt instanceof JIfStmt || srcStmt instanceof JLookupSwitchStmt || srcStmt instanceof JGotoStmt || srcStmt instanceof JTableSwitchStmt)
//                    return true;
//            }
//            return false;
//        } else
//            return false;
    }

    public boolean hasSynchronized(SootMethod method) {
        if(method.isConcrete() && isValidSeedMethod(method)) {
            if(!method.hasActiveBody()){
                method.retrieveActiveBody();
            }
            PatchingChain<Unit> units = method.getActiveBody().getUnits();
            for(Unit u: units) {
                Stmt srcStmt = (Stmt) u;
                if(srcStmt instanceof JEnterMonitorStmt)
                    return true;
            }
            return false;
        } else
            return false;
    }

    public List<List<Pair<ISourceSink, Integer>>> analyzeCallGraphForSourceSinks(boolean isTopDown, Set<SootMethod> sources, Set<SootMethod> sinks) throws IOException {
        processedCallLists = new HashMap<>();
        methodOfResults = new HashSet<>();
        List<List<Pair<ISourceSink, Integer>>> results = new LinkedList<>();
        processedMethods = new HashSet<>();
        visitedMethods = new HashSet<>();

        if (isTopDown) {
            for(SootMethod sootMethod: sources) {
                Source src = new Source(sootMethod);
                src.setInMainThread(true);
                List<List<Pair<ISourceSink, Integer>>> childResult = traverseCallGraphForward(src, sinks, 0);
                if(childResult != null) {
                    for (List<Pair<ISourceSink, Integer>> trace : childResult) {
                        List<Pair<ISourceSink, Integer>> newTrace = new LinkedList<>();
                        newTrace.add(new Pair<>(src, 0));
                        newTrace.addAll(trace);
                        results.add(newTrace);
                    }
                }
//                workList.offer(new Pair<>(sootMethod, true));
            }
        } else {
            for(SootMethod sootMethod: sinks) {
                //suppose that sink is not in main thread
                Source sinkMethod = new Source(sootMethod);
                sinkMethod.setInMainThread(false);
                List<List<Pair<ISourceSink, Integer>>> parentResult = traverseCallGraphBackward(sinkMethod, sources, 0);
                if(parentResult != null) {
                    for (List<Pair<ISourceSink, Integer>> trace :parentResult) {
                        List<Pair<ISourceSink, Integer>> newTrace = new LinkedList<>(trace);
                        Pair<ISourceSink, Integer> pair = newTrace.get(newTrace.size() - 1);
                        String name = pair.getKey().method().getName();
                        if(name.equals("post") || name.equals("postDelayed") || name.equals("runOnUiThread") || name.equals("execute") || name.equals("start"))
                            pair = newTrace.get(newTrace.size() - 2);
                        boolean hasSynchronized = hasSynchronized(pair.getKey().method());
                        if(!hasBrunch(pair.getKey().method())) {
                            for (ISourceSink sourceSink : getImportantFuncsInMethod(pair.getKey())) {
                                if (pair.getKey().isLocked() || hasSynchronized)
                                    sourceSink.setLocked(true);
                                else
                                    sourceSink.setLocked(false);
                                newTrace.add(new Pair<>(sourceSink, 0));
                            }
                        }
                        if((pair.getKey().isLocked() || hasSynchronized)
                                && !sinkMethod.isLocked())
                            sinkMethod.setLocked(true);
                        else if(!pair.getKey().isLocked() && !hasSynchronized && sinkMethod.isLocked()) {
                            sinkMethod.setLocked(false);
                        }
                        newTrace.add(new Pair<>(sinkMethod, 0));
                        results.add(newTrace);
                    }
                }
//                workList.offer(new Pair<>(sootMethod, false));
            }
        }

        processedCallLists = null;
        methodOfResults = null;
        processedMethods = null;
        visitedMethods = null;
        return results;
    }

    private List<List<Pair<ISourceSink, Integer>>> traverseCallGraphForward(Source source, Set<SootMethod> sinks, int depth) {
        List<List<Pair<ISourceSink, Integer>>> callLists = new LinkedList<>();
        SootMethod method = source.method();
        boolean isInMainThread = source.isInMainThread();
        boolean isLocked = source.isLocked();
        if(visitedMethods.contains(method))
            return callLists;
        if (processedMethods.contains(method)) {
            List<List<Pair<ISourceSink, Integer>>> callList = processedCallLists.get(method);
            return (callList != null) ? callList : new LinkedList<>();
        }
        Runtime.getRuntime().gc();
        if(depth >= MAXDEPTH || Runtime.getRuntime().freeMemory() < Runtime.getRuntime().totalMemory() / 5) {
            return null;
        }
        visitedMethods.add(method);

        List<Pair<ISourceSink, Integer>> imprtFuncs = new LinkedList<>();
        Set<Edge> edges = edgesOutOf(method);
        boolean hasSynchronized = hasSynchronized(method);
        if(!hasBrunch(method)) {
            for (Edge edge : edges) {
                SootMethod tgt = edge.tgt();
                if (importantFuncOnTrace.contains(tgt)) {
                    Source imptFunc = new Source(tgt);
                    if(hasSynchronized || isLocked)
                        imptFunc.setLocked(true);
                    imprtFuncs.add(new Pair<>(imptFunc, depth + 1));
                }
            }
        }

        boolean incompleteResult = false;
        for (Edge edge: edges) {
            SootMethod tgt = edge.tgt();
            SootMethod methodOfStmt = getMethodFromStmt(edge.srcStmt());
            if(tgt == null || importantFuncOnTrace.contains(tgt))
                continue;
            boolean isResult = false;
            for (Iterator<SootMethod> iter = sinks.iterator(); iter.hasNext(); ) {
                SootMethod sink = iter.next();
                if (tgt.getSubSignature().equals(sink.getSubSignature())) {
                    isResult = true;
                    break;
                }
            }
            if (isResult) {
                if(methodOfResults.contains(method))
                    continue;
                methodOfResults.add(method);
                VUISink sink = new VUISink(tgt, edge.srcStmt(), method);
                sink.setInMainThread(isInMainThread);
                if(hasSynchronized || isLocked)
                    sink.setLocked(true);
                List<Pair<ISourceSink, Integer>> callList = new LinkedList<>(imprtFuncs);
                callList.add(new Pair<>(sink, depth + 1));
                callLists.add(callList);
//                        realEnd.add(srcOrTgt);
            }
            else {
                SootClass declaringClass = tgt.getDeclaringClass();
                String declaringClassName = declaringClass.getName();
                String declaringClassOfSrc = method.getDeclaringClass().getName();
                if (!declaringClassName.startsWith("java.")
                        && !declaringClassName.startsWith("android.")
                        && !declaringClassName.startsWith("javax.")
                        && (!declaringClassName.startsWith("androidx") || isStartFragment(tgt) || isCloseFragment(tgt) || declaringClassOfSrc.startsWith("androidx"))) {
                    if (tgt.isAbstract()) {
                        List<SootClass> implementClasses;
                        if (declaringClass.isInterface())
                            implementClasses = Scene.v().getActiveHierarchy().getDirectImplementersOf(declaringClass);
                        else
                            implementClasses = Scene.v().getActiveHierarchy().getDirectSubclassesOf(declaringClass);
                        Set<SootMethod> overrideMethods = new HashSet<>();
                        boolean containVisitedMethods = false;
                        for (SootClass implementClass : implementClasses) {
                            for (SootMethod sm : implementClass.getMethods()) {
                                if (sm.getSubSignature().equals(tgt.getSubSignature())) {
                                    overrideMethods.add(sm);
                                    if(visitedMethods.contains(sm))
                                        containVisitedMethods = true;
                                    break;
                                }
                            }
                            if(containVisitedMethods)
                                break;
                        }
                        if(overrideMethods.size() > 5 || containVisitedMethods)
                            continue;
                        for(SootMethod sm: overrideMethods) {
                            Source src = new Source(sm);
                            src.setInMainThread(isInMainThread);
                            if(hasSynchronized || isLocked)
                                src.setLocked(true);
                            List<List<Pair<ISourceSink, Integer>>> childResult = traverseCallGraphForward(src, sinks, depth + 1);
                            if(childResult != null) {
                                List<Pair<ISourceSink, Integer>> preparedCallers = new LinkedList<>(imprtFuncs);
                                preparedCallers.add(new Pair<>(src, depth + 1));
                                for (List<Pair<ISourceSink, Integer>> trace : childResult) {
                                    List<Pair<ISourceSink, Integer>> newTrace = new LinkedList<>();
                                    newTrace.addAll(preparedCallers);
                                    newTrace.addAll(trace);
                                    callLists.add(newTrace);
                                }
                            } else {
                                incompleteResult = true;
                            }
                        }
                    } else {
                        Source src = new Source(tgt);
                        if(methodOfStmt != null
                                && methodOfStmt.getName().equals("start")
                                && tgt.getName().equals("run")) {
                            // if methodOfStmt is start && tgt is run, set the inMainThread to false
                            src.setInMainThread(false);
                            if(hasSynchronized || isLocked)
                                src.setLocked(true);
                            List<List<Pair<ISourceSink, Integer>>> childResult = traverseCallGraphForward(src, sinks, depth + 1);
                            if(childResult != null) {
                                List<Pair<ISourceSink, Integer>> preparedCallers = new LinkedList<>(imprtFuncs);
                                Source start = new Source(methodOfStmt);
                                start.setInMainThread(isInMainThread);
                                if(hasSynchronized || isLocked)
                                    start.setLocked(true);
                                preparedCallers.add(new Pair<>(start, depth + 1));
                                preparedCallers.add(new Pair<>(src, depth + 1));
                                for (List<Pair<ISourceSink, Integer>> trace : childResult) {
                                    List<Pair<ISourceSink, Integer>> newTrace = new LinkedList<>();
                                    newTrace.addAll(preparedCallers);
                                    newTrace.addAll(trace);
                                    callLists.add(newTrace);
                                }
                            } else
                                incompleteResult = true;
//                                    workList.offer(new Pair<>(srcOrTgt, false));
                        }
                        else if(methodOfStmt != null
                                && methodOfStmt.getName().equals("execute")
                                && tgt.getName().equals("doInBackground")) {
                            // if srcOrTgt is doInBackground, set the inMainThread to false
                            src.setInMainThread(false);
                            if(hasSynchronized || isLocked)
                                src.setLocked(true);
                            List<List<Pair<ISourceSink, Integer>>> childResult = traverseCallGraphForward(src, sinks, depth + 1);
                            if(childResult != null) {
                                List<Pair<ISourceSink, Integer>> preparedCallers = new LinkedList<>(imprtFuncs);
                                Source execute = new Source(methodOfStmt);
                                execute.setInMainThread(isInMainThread);
                                if(hasSynchronized || isLocked)
                                    execute.setLocked(true);
                                preparedCallers.add(new Pair<>(execute, depth + 1));
                                preparedCallers.add(new Pair<>(src, depth + 1));
                                for (List<Pair<ISourceSink, Integer>> trace : childResult) {
                                    List<Pair<ISourceSink, Integer>> newTrace = new LinkedList<>();
                                    newTrace.addAll(preparedCallers);
                                    newTrace.addAll(trace);
                                    callLists.add(newTrace);
                                }
                            } else
                                incompleteResult = true;
//                                    workList.offer(new Pair<>(srcOrTgt, false));
                        }
                        else {
                            src.setInMainThread(isInMainThread);
                            if(hasSynchronized || isLocked)
                                src.setLocked(true);
                            List<List<Pair<ISourceSink, Integer>>> childResult = traverseCallGraphForward(src, sinks, depth + 1);
                            if(childResult != null) {
                                Source post = null;
                                if(methodOfStmt != null) {
                                    String nameOfMethodOfStmt = methodOfStmt.getName();
                                    if (nameOfMethodOfStmt.equals("post") || nameOfMethodOfStmt.equals("postDelayed") || nameOfMethodOfStmt.equals("runOnUiThread")) {
                                        post = new Source(methodOfStmt);
                                        post.setInMainThread(isInMainThread);
                                        if(hasSynchronized || isLocked)
                                            post.setLocked(true);
                                    }
                                }
                                List<Pair<ISourceSink, Integer>> preparedCallers = new LinkedList<>(imprtFuncs);
                                if(post != null)
                                    preparedCallers.add(new Pair<>(post, depth + 1));
                                preparedCallers.add(new Pair<>(src, depth + 1));
                                for (List<Pair<ISourceSink, Integer>> trace : childResult) {
                                    List<Pair<ISourceSink, Integer>> newTrace = new LinkedList<>();
                                    newTrace.addAll(preparedCallers);
                                    newTrace.addAll(trace);
                                    callLists.add(newTrace);
                                }
                            } else
                                incompleteResult = true;
//                                    workList.offer(new Pair<>(srcOrTgt, isInMainThread));
                        }
                    }
                }
            }
        }
        visitedMethods.remove(method);
        if(!callLists.isEmpty() || !incompleteResult || !method.getDeclaringClass().getName().startsWith(apkIdPredix)) {
            processedMethods.add(method);
            if(!callLists.isEmpty())
                processedCallLists.put(method, callLists);
            return callLists;
        }
        return null;
    }

    private List<List<Pair<ISourceSink, Integer>>> traverseCallGraphBackward(Source sink, Set<SootMethod> sources, int depth) {
        List<List<Pair<ISourceSink, Integer>>> callLists = new LinkedList<>();
        SootMethod method = sink.method();
        boolean isInMainThread = sink.isInMainThread();
        if(visitedMethods.contains(method))
            return callLists;
        if (processedMethods.contains(method)) {
            List<List<Pair<ISourceSink, Integer>>> callList = processedCallLists.get(method);
            return (callList != null) ? callList : new LinkedList<>();
        }
        Runtime.getRuntime().gc();
        if(depth >= MAXDEPTH || Runtime.getRuntime().freeMemory() < Runtime.getRuntime().totalMemory() / 5) {
            return null;
        }
        visitedMethods.add(method);

        boolean incompleteResult = false;
        Set<Edge> edges = edgesInto(method);
        Set<SootMethod> overrideMethods = new HashSet<>();
        boolean containVisitedMethods = false;
        for(Edge edge: edges) {
            SootMethod methodOfStmt = getMethodFromStmt(edge.srcStmt());
            if(methodOfStmt != null && methodOfStmt.getSubSignature().equals(method.getSubSignature()) && !methodOfStmt.getDeclaringClass().equals(method.getDeclaringClass())) {
                overrideMethods.add(methodOfStmt);
                if(visitedMethods.contains(methodOfStmt)) {
                    containVisitedMethods = true;
                    break;
                }
            }
        }
        if(containVisitedMethods)
            return callLists;
        for (Edge edge: edges) {
            SootMethod src = edge.src();
            SootMethod methodOfStmt = getMethodFromStmt(edge.srcStmt());
            if(src == null)
                continue;
            if(methodOfStmt == null || (overrideMethods.size() > 5 && overrideMethods.contains(methodOfStmt)))
                continue;
            boolean isResult = false;
            for (Iterator<SootMethod> iter = sources.iterator(); iter.hasNext(); ) {
                if (src.getSubSignature().equals(iter.next().getSubSignature())) {
                    isResult = true;
                    break;
                }
            }
            if (isResult) {
                if(methodOfResults.contains(src))
                    continue;
                methodOfResults.add(src);
                Source source = new Source(src);
                source.setInMainThread(isInMainThread);
                List<Pair<ISourceSink, Integer>> callList = new LinkedList<>();
                callList.add(new Pair<>(source, depth + 1));
                if (((methodOfStmt.getName().equals("post") || methodOfStmt.getName().equals("postDelayed") || methodOfStmt.getName().equals("runOnUiThread") || methodOfStmt.getName().equals("start"))
                        && method.getName().equals("run"))
                        || (methodOfStmt.getName().equals("execute")
                        && method.getName().equals("doInBackground"))) {
                    Source post_start_execute = new Source(methodOfStmt);
                    callList.add(new Pair<>(post_start_execute, depth));
                }
                callLists.add(callList);
            }
            else {
                Source newSink = new Source(src);
                String declaringClassName = src.getDeclaringClass().getName();
                String declaringClassOfTgt = method.getDeclaringClass().getName();
                if (declaringClassName.startsWith("java.")
                        || declaringClassName.startsWith("android.")
                        || declaringClassName.startsWith("javax.")
                        || (declaringClassName.startsWith("androidx") && !declaringClassOfTgt.startsWith("androidx")))
                    continue;
                List<Pair<ISourceSink, Integer>> prepareCallee = new LinkedList<>();
                if (((methodOfStmt.getName().equals("post") || methodOfStmt.getName().equals("postDelayed") || methodOfStmt.getName().equals("runOnUiThread") || methodOfStmt.getName().equals("start"))
                        && method.getName().equals("run"))
                        || (methodOfStmt.getName().equals("execute")
                        && method.getName().equals("doInBackground"))) {
                    // if methodOfStmt is start && method is run, set the inMainThread to true
                    newSink.setInMainThread(true);
                    Source post_start_execute = new Source(methodOfStmt);
                    post_start_execute.setInMainThread(isInMainThread);
                    prepareCallee.add(new Pair<>(newSink, depth + 1));
                    prepareCallee.add(new Pair<>(post_start_execute, depth));
                }
                else {
                    newSink.setInMainThread(isInMainThread);
                    prepareCallee.add(new Pair<>(newSink, depth + 1));
                }

                List<List<Pair<ISourceSink, Integer>>> parentResult = traverseCallGraphBackward(newSink, sources, depth + 1);
                if (parentResult != null) {
                    for (List<Pair<ISourceSink, Integer>> trace : parentResult) {
                        List<Pair<ISourceSink, Integer>> newTrace = new LinkedList<>(trace);
                        Pair<ISourceSink, Integer> pair = newTrace.get(newTrace.size() - 1);
                        String name = pair.getKey().method().getName();
                        if (name.equals("post") || name.equals("postDelayed") || name.equals("runOnUiThread") || name.equals("execute") || name.equals("start"))
                            pair = newTrace.get(newTrace.size() - 2);
                        boolean hasSynchronized = hasSynchronized(pair.getKey().method());
                        if (!hasBrunch(pair.getKey().method())) {
                            for (ISourceSink sourceSink : getImportantFuncsInMethod(pair.getKey())) {
                                if (pair.getKey().isLocked() || hasSynchronized)
                                    sourceSink.setLocked(true);
                                else
                                    sourceSink.setLocked(false);
                                newTrace.add(new Pair<>(sourceSink, depth + 1));
                            }
                        }
                        if ((pair.getKey().isLocked() || hasSynchronized)
                                && !prepareCallee.get(0).getKey().isLocked()) {
                            List<Pair<ISourceSink, Integer>> prepareCallee2 = new LinkedList<>();
                            for(int i = 0; i < prepareCallee.size(); ++i) {
                                Source source = (Source) prepareCallee.get(i).getKey();
                                source.setLocked(true);
                                if(i == 0)
                                    prepareCallee2.add(new Pair<>(source, depth + 1));
                                else
                                    prepareCallee2.add(new Pair<>(source, depth));
                            }
                            prepareCallee = prepareCallee2;
                        } else if (!pair.getKey().isLocked() && !hasSynchronized && prepareCallee.get(0).getKey().isLocked()) {
                            List<Pair<ISourceSink, Integer>> prepareCallee2 = new LinkedList<>();
                            for(int i = 0; i < prepareCallee.size(); ++i) {
                                Source source = (Source) prepareCallee.get(i).getKey();
                                source.setLocked(false);
                                if(i == 0)
                                    prepareCallee2.add(new Pair<>(source, depth + 1));
                                else
                                    prepareCallee2.add(new Pair<>(source, depth));
                            }
                            prepareCallee = prepareCallee2;
                        }
                        newTrace.addAll(prepareCallee);
                        callLists.add(newTrace);
                    }
                } else {
                    incompleteResult = true;
                }
            }

        }
        visitedMethods.remove(method);
        if(!callLists.isEmpty() || !incompleteResult || !method.getDeclaringClass().getName().startsWith(apkIdPredix)) {
            processedMethods.add(method);
            if(!callLists.isEmpty())
                processedCallLists.put(method, callLists);
            return callLists;
        }
        return null;
    }

    public Set<ISourceSink> getImportantFuncsInMethod(ISourceSink source) {
        SootMethod src = source.method();
        Set<ISourceSink> importantFuncsInMethod = new HashSet<>();
        for(Edge edge: edgesOutOf(src)) {
            SootMethod tgt = edge.tgt();
            if(importantFuncOnTrace.contains(tgt))
                importantFuncsInMethod.add(new Source(tgt));
        }
        return importantFuncsInMethod;
    }

    public List<Set<Sink>> aliasAnalysis(Set<Sink> sinks, Set<SootMethod> expectedSinkMethods) {
        List<Set<Sink>> guisinks = new LinkedList<>();
        guisinks.add(new HashSet<>());
        guisinks.add(new HashSet<>());
//        Map<String, List<Set<Sink>>> temp = new HashMap<>();
//        PointsToAnalysis pointsToAnalysis = Scene.v().getPointsToAnalysis();
        //get alias for VUI sinks as GUI sinks
        for(Sink sink: sinks) {
            Stmt stmt = sink.stmt();
            Value v1 = getBase(stmt);

            SootMethod method = getMethodFromStmt(stmt);
            if (method != null && v1 != null) {
//                LocalVarNode n1 = null;
//                if(pointsToAnalysis instanceof PAG)
//                    n1 = ((PAG) pointsToAnalysis).findLocalVarNode(v1);
                String declaringClassName = sink.getDeclaringMethod().getDeclaringClass().getName();
//                PointsToSet p1;
//                if (n1 == null) {
//                    p1 = EmptyPointsToSet.v();
//                } else {
//                    p1 = n1.getP2Set();
//                    declaringClassName = n1.getMethod().getDeclaringClass().getName();
//                }

                Set<Edge> edgeSet = new HashSet<>();
                for(SootMethod sm: expectedSinkMethods) {
                    if(sm.getDeclaringClass().equals(method.getDeclaringClass()))
                        edgeSet.addAll(edgesInto(sm));
                }

                for(Edge edge1: edgeSet){
                    Stmt guiStmt = edge1.srcStmt();
                    String guiStmtDeclaringClass = edge1.src().getDeclaringClass().getName();
                    Value v2 = getBase(guiStmt);
                    if(guiStmtDeclaringClass.equals(declaringClassName)
                            || (declaringClassName.contains("$") && declaringClassName.startsWith(guiStmtDeclaringClass + "$"))
                            || (guiStmtDeclaringClass.contains("$") && guiStmtDeclaringClass.startsWith(declaringClassName + "$"))) {
                        if (v1.equivTo(v2) || isEqualVar(v1, v2, stmt, guiStmt, sink.getDeclaringMethod(), edge1.src())) {
                            guisinks.get(0).add(new Sink(edge1.tgt(), guiStmt, edge1.src()));
                        } else {
                            // delete possible aliases
//                            guisinks.get(1).add(new Sink(edge1.tgt(), guiStmt, edge1.src()));
                            // delete possible aliases
                        }
                    }
                }
            }
        }
        return guisinks;
    }

    private static boolean isEqualVar(Value v1, Value v2, Stmt stmt1, Stmt stmt2, SootMethod sm1, SootMethod sm2) {
        if(v1 == null || v2 == null)
            return false;
        SootFieldRef ref1 = getFielfRefOfStmt(v1, stmt1, sm1);
        SootFieldRef ref2 = getFielfRefOfStmt(v2, stmt2, sm2);
        return ref1 != null && ref1.equals(ref2);
    }

    private static SootFieldRef getFielfRefOfStmt(Value v, Stmt stmt, SootMethod sm) {
        SootFieldRef ref = null;
        if(v == null)
            return ref;
        PatchingChain<Unit> units = sm.getActiveBody().getUnits();
        if(units.contains(stmt)) {
            Unit u = units.getPredOf(stmt);
            while (u != null && ref == null){
                Stmt st = (Stmt) u;
                if(st instanceof JAssignStmt && ((JAssignStmt) st).getLeftOp().equivTo(v)) {
                    if(((JAssignStmt) st).getRightOp() instanceof JInstanceFieldRef) {
                        JInstanceFieldRef rightOp = (JInstanceFieldRef)((JAssignStmt) st).getRightOp();
                        ref = rightOp.getFieldRef();
                        break;
                    }
                    else if(((JAssignStmt) st).getRightOp() instanceof JStaticInvokeExpr){
                        JStaticInvokeExpr staticInvokeExpr = (JStaticInvokeExpr) ((JAssignStmt) st).getRightOp();
                        SootMethod staticInvokeMethod = staticInvokeExpr.getMethod();
                        if(staticInvokeMethod.hasActiveBody()) {
                            PatchingChain<Unit> staticInvokeUnits = staticInvokeMethod.getActiveBody().getUnits();
                            Stmt returnStmt = (Stmt) staticInvokeUnits.getLast();
                            if (returnStmt instanceof JReturnStmt) {
                                Unit u1 = staticInvokeUnits.getLast();
                                while (u1 != null) {
                                    Stmt st1 = (Stmt) u1;
                                    if (st1 instanceof JAssignStmt
                                            && ((JAssignStmt) st1).getLeftOp().equivTo(((JReturnStmt) returnStmt).getOp())
                                            && ((JAssignStmt) st1).getRightOp() instanceof JInstanceFieldRef) {
                                        JInstanceFieldRef rightOp = (JInstanceFieldRef) ((JAssignStmt) st1).getRightOp();
                                        ref = rightOp.getFieldRef();
                                        break;
                                    }
                                    u1 = staticInvokeUnits.getPredOf(u1);
                                }
                            }
                        }
                    }
                    else if(((JAssignStmt) st).getRightOp() instanceof StaticFieldRef) {
                        StaticFieldRef rightOp = (StaticFieldRef) ((JAssignStmt) st).getRightOp();
                        ref = rightOp.getFieldRef();
                        break;
                    }
                }
                u = units.getPredOf(u);
            }
        }
        return ref;
    }

    public static int getDefOfIntValue(SootMethod sm, Stmt stmt, Value arg) {
        int def = -1;
        PatchingChain<Unit> units = sm.getActiveBody().getUnits();
        if(units.contains(stmt)) {
            Unit u = units.getPredOf(stmt);
            while (u != null){
                Stmt st = (Stmt) u;
                if(st instanceof JAssignStmt && ((JAssignStmt) st).getLeftOp().equivTo(arg)) {
                    if(((JAssignStmt) st).getRightOp() instanceof IntConstant) {
                        IntConstant rightOp = (IntConstant) ((JAssignStmt) st).getRightOp();
                        def = rightOp.value;
                        break;
                    } else if(((JAssignStmt) st).getRightOp() instanceof StaticFieldRef) {
                        StaticFieldRef ref = (StaticFieldRef) ((JAssignStmt) st).getRightOp();
                        SootFieldRef fieldRef = ref.getFieldRef();
                        SootClass declaringClass = fieldRef.declaringClass();
                        String fieldName = fieldRef.name();
                        SootField field = declaringClass.getFieldByName(fieldName);
                        for(Tag tag: field.getTags()) {
                            if(tag instanceof IntegerConstantValueTag) {
                                def = ((IntegerConstantValueTag) tag).getIntValue();
                                break;
                            }
                        }
                        if(def != -1)
                            break;
                    }
                }
                u = units.getPredOf(u);
            }
        }
        return def;
    }

    public Set<SootMethod> findValidMethodWithSig(String signature) {
        Set<SootMethod> results = new HashSet<>();
        for (QueueReader<MethodOrMethodContext> it = reachableMethods.listener(); it.hasNext(); ) {
            MethodOrMethodContext methodOrMethodContext = it.next();
            SootMethod sm = methodOrMethodContext.method();
            if(sm != null
                    && sm.isConcrete()
                    && isValidSeedMethod(sm)
                    && (!signature.startsWith("<") && sm.getSubSignature().equals(signature)
                    || signature.startsWith("<") && sm.getSignature().equals(signature))) {
                results.add(sm);
            }
        }
        return results;
    }

    public boolean isValidSeedMethod(SootMethod sm) {
        if (sm == dummyMainMethod)
            return false;
        if (dummyMainMethod != null && sm.getDeclaringClass() == dummyMainMethod.getDeclaringClass())
            return false;

        // Exclude system classes
        final String className = sm.getDeclaringClass().getName();
        if (SystemClassHandler.v().isClassInSystemPackage(className)) {
            return false;
        }

        // Exclude library classes
        if (sm.getDeclaringClass().isLibraryClass()){
            return false;
        }

        return true;
    }

    public static SootMethod getMethodFromStmt(Stmt stmt) {
        try {
            InvokeExpr invokeExpr = stmt.getInvokeExpr();
            SootMethod sootMethod = invokeExpr.getMethod();
            return sootMethod;
        } catch (RuntimeException e){
            return null;
        }
    }

    public static Value getBase(Stmt stmt) {
        if (stmt instanceof JInvokeStmt) {
            JInvokeStmt jInvokeStmt = (JInvokeStmt) stmt;
            if (jInvokeStmt.getInvokeExpr() instanceof JVirtualInvokeExpr) {
                JVirtualInvokeExpr jExpr = ((JVirtualInvokeExpr) jInvokeStmt.getInvokeExpr());
                return jExpr.getBase();
            }
        }
        return null;
    }

    public static boolean isStartFragment(SootMethod sootMethod) {
        String methodName = sootMethod.getName();
        String declaringClassName = sootMethod.getDeclaringClass().getName();
        if((methodName.equals("add") || methodName.equals("replace") || methodName.equals("show"))
                && declaringClassName.equals("androidx.fragment.app.FragmentTransaction"))
            return true;
        if((methodName.equals("showNow") || methodName.equals("show"))
                && declaringClassName.equals("androidx.fragment.app.DialogFragment"))
            return true;
        return false;
    }

    public static boolean isCloseFragment(SootMethod sootMethod) {
        String methodName = sootMethod.getName();
        String declaringClassName = sootMethod.getDeclaringClass().getName();
        if((methodName.equals("remove") || methodName.equals("hide") || methodName.equals("replace"))
                && declaringClassName.equals("androidx.fragment.app.FragmentTransaction"))
            return true;
        if((methodName.equals("dismiss") || methodName.equals("dismissInternal") || methodName.equals("dismissAllowingStateLoss"))
                && declaringClassName.equals("androidx.fragment.app.DialogFragment"))
            return true;
        return false;
    }
}
