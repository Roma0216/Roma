package src.callGraphAnalyze.element;

import soot.MethodOrMethodContext;
import soot.jimple.toolkits.callgraph.CallGraph;
import soot.jimple.toolkits.callgraph.Filter;
import soot.jimple.toolkits.callgraph.ReachableMethods;

import java.util.Collection;
import java.util.Iterator;

public class myReachableMethods extends ReachableMethods {

    public myReachableMethods(CallGraph graph, Iterator<? extends MethodOrMethodContext> entryPoints, ReachableMethods reachableMethods){
        super(graph, entryPoints);
        addMethods(reachableMethods.listener());
    }

    public myReachableMethods(CallGraph graph, Iterator<? extends MethodOrMethodContext> entryPoints, Filter filter) {
        super(graph, entryPoints, filter);
    }

    public myReachableMethods(CallGraph graph, Iterator<? extends MethodOrMethodContext> entryPoints){
        super(graph, entryPoints);
    }

    public myReachableMethods(CallGraph graph, Collection<? extends MethodOrMethodContext> entryPoints){
        super(graph, entryPoints);
    }

    public void addMethods(Iterator<? extends MethodOrMethodContext> methods){
        super.addMethods(methods);
    }

    public void addMethod(MethodOrMethodContext m) {
        super.addMethod(m);
    }
}
