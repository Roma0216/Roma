package src.callGraphAnalyze.element;

import net.sf.json.JSONObject;
import soot.*;
import net.sf.json.JSONArray;
import soot.jimple.Stmt;
import soot.jimple.StringConstant;
import soot.jimple.infoflow.android.callbacks.AndroidCallbackDefinition;
import soot.jimple.toolkits.callgraph.Edge;
import soot.util.HashMultiMap;
import soot.util.MultiMap;

import java.io.*;
import java.util.HashMap;
import java.util.Map;
import java.util.Set;

import static src.callGraphAnalyze.element.myCallgraph.getMethodFromStmt;

public class WidgetInfo {
    static String outputPath = "../gator-IconIntent/AndroidBench/output/";
    String jsonFileName = "";

    MultiMap<SootMethod, String> handlerToWidget = new HashMultiMap<>();
    Map<SootMethod, String> handlerToFile = new HashMap<>();

    public WidgetInfo(MultiMap<AndroidCallbackDefinition, String> xmlCallbackToWidget, Map<AndroidCallbackDefinition, String> xmlCallbackToFile, String apkLocation) throws IOException {
        String[] paths = apkLocation.split("/");
        String apkFileName = paths[paths.length - 1];
        jsonFileName = apkFileName + ".json";
        String resultPath = outputPath + jsonFileName;
        File jsonFile = new File(resultPath);
        for(AndroidCallbackDefinition callbackDefinition: xmlCallbackToWidget.keySet()) {
            handlerToWidget.putAll(callbackDefinition.getTargetMethod(), xmlCallbackToWidget.get(callbackDefinition));
            handlerToFile.put(callbackDefinition.getTargetMethod(), xmlCallbackToFile.get(callbackDefinition));
        }
        if (!jsonFile.exists()) {
            //throw new RuntimeException("result file '" + jsonFile + "' does not exist!");
        } else {
            parseJsonFile(jsonFile);
        }
    }

    public Set<String> findWidget(SootMethod method) {
        return handlerToWidget.get(method);
    }

    public String findFile(SootMethod method) { return handlerToFile.get(method) == null ? "": handlerToFile.get(method); }

    public String getJsonFileName() {
        return jsonFileName;
    }

    private void parseJsonFile(File jsonFile) throws IOException {
        InputStreamReader input = new InputStreamReader(new FileInputStream(jsonFile), "UTF-8");
        int size = 1000000;
        char cbuf[] = new char[1000000];
        int len = input.read(cbuf);
        char res[] = cbuf.clone();
        while (len >= size) {
            char last[] = cbuf;
            cbuf = new char[1000000];
            len += input.read(cbuf);
            size += 1000000;
            res = new char[size];
            System.arraycopy(last, 0, res, 0, last.length);
            System.arraycopy(cbuf, 0, res, size - 1000000, cbuf.length);
        }
        String text = new String(res, 0, len);
        JSONArray wins = JSONArray.fromObject(text);
        for (int index = 0; index < wins.size(); ++index) {
            JSONObject win = wins.getJSONObject(index);
            //String name0 = win.getString("name");
            JSONArray jsonViews = win.getJSONArray("views");
            for (int i = 0; i < jsonViews.size(); ++i) {
                JSONObject viewjson = jsonViews.getJSONObject(i);
                String name = viewjson.getString("name");
                JSONArray jsonhandlers = viewjson.getJSONArray("handlers");
                for (int j = 0; j < jsonhandlers.size(); ++j) {
                    JSONObject handlerjson = jsonhandlers.getJSONObject(j);
                    handlerjson.getString("event");
                    JSONArray eventhandlers = handlerjson.getJSONArray("handlers");
                    for (int k = 0; k < eventhandlers.size(); ++k) {
                        String methodSig = eventhandlers.getString(k);
                        SootMethod method = Scene.v().grabMethod(methodSig);
                        if (method != null)
                            handlerToWidget.put(method, name);
                    }
                }
            }
        }
    }


}
