package src.callGraphAnalyze.element.sourcesink;

import soot.SootMethod;
import soot.jimple.Stmt;

public interface ISourceSink {
    SootMethod method();

    String getSignature();

    String getSubSignature();

    boolean isInMainThread();

    void setInMainThread(boolean inMainThread);

    boolean isLocked();

    void setLocked(boolean locked);
}

