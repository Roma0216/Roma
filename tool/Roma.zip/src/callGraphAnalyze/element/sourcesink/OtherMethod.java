package src.callGraphAnalyze.element.sourcesink;

import soot.SootMethod;

import javax.print.attribute.standard.MediaSize;

public class OtherMethod implements ISourceSink{
    SootMethod sootMethod;
    private boolean isInMainThread = true;
    private boolean isLocked = false;

    public OtherMethod(SootMethod sm) {
        sootMethod = sm;
        isInMainThread = true;
    }

    public OtherMethod(SootMethod sm, boolean inMain) {
        sootMethod = sm;
        isInMainThread = inMain;
    }

    @Override
    public boolean isInMainThread() {
        return isInMainThread;
    }

    @Override
    public void setInMainThread(boolean inMainThread) {
        isInMainThread = inMainThread;
    }

    @Override
    public boolean isLocked() {
        return isLocked;
    }

    @Override
    public void setLocked(boolean locked) {
        isLocked = locked;
    }

    @Override
    public SootMethod method() {
        return sootMethod;
    }

    @Override
    public String getSignature() {
        return sootMethod.getSignature();
    }

    @Override
    public String getSubSignature() {
        return sootMethod.getSubSignature();
    }

    public String toString() {
        return sootMethod.getSignature();
    }
}
