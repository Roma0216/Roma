package src.callGraphAnalyze.element.sourcesink;

import javafx.util.Pair;
import src.callGraphAnalyze.element.sourcesink.ISourceSink;
import src.callGraphAnalyze.element.sourcesink.Sink;
import soot.SootClass;
import soot.SootMethod;
import soot.jimple.Stmt;

import java.util.*;

public class Source implements ISourceSink {

    private SootMethod sourceMethod;
    boolean isInMainThread = true;
    private Set<String> layoutFiles = new HashSet<>();

    private Set<List<Pair<ISourceSink, Integer>>> sinkTraces = new HashSet<>();

    private boolean isLocked = false;

    public Source(SootMethod src) {
        sourceMethod = src;
    }

    @Override
    public SootMethod method() {
        return sourceMethod;
    }

    @Override
    public String getSignature() {
        return sourceMethod.getSignature();
    }

    @Override
    public String getSubSignature() {
        return sourceMethod.getSubSignature();
    }

    public SootClass getDeclaringClass() {
        return sourceMethod.getDeclaringClass();
    }

    @Override
    public void setInMainThread(boolean inMainThread) {
        isInMainThread = inMainThread;
    }

    @Override
    public boolean isLocked() {
        return isLocked;
    }

    @Override
    public void setLocked(boolean locked) {
        isLocked = locked;
    }

    @Override
    public boolean isInMainThread() {
        return isInMainThread;
    }

    public void addLayoutFiles(Set<String> files) {
        layoutFiles = files;
    }

    public Set<String> getLayoutFiles() {
        return layoutFiles;
    }

    public void addSinkTrace(List<Pair<ISourceSink, Integer>> sinkTrace) {
        sinkTraces.add(sinkTrace);
    }

    public Set<List<Pair<ISourceSink, Integer>>> getSinkTraces() {
        return sinkTraces;
    }

    public void keepSinks(Set<Stmt> imptSinks) {
        Set<List<Pair<ISourceSink, Integer>>> temp = new HashSet<>();
        for(List<Pair<ISourceSink, Integer>> sink: sinkTraces) {
            ISourceSink last = sink.get(sink.size() - 1).getKey();
            if(last instanceof VUISink) {
                Stmt sinkStmt = ((VUISink) last).stmt();
                for (Stmt stmt : imptSinks) {
                    if (sinkStmt != null && sinkStmt.equals(stmt)) {
                        temp.add(sink);
                        break;
                    }
                }
            }
        }
        sinkTraces = temp;
    }

    public String toString() {
        return sourceMethod.getSignature();
    }
}
