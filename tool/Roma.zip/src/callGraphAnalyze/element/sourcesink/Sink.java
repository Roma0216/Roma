package src.callGraphAnalyze.element.sourcesink;

import src.callGraphAnalyze.element.sourcesink.ISourceSink;
import soot.SootMethod;
import soot.jimple.Stmt;

public class Sink implements ISourceSink {
    SootMethod sinkMethod;
    Stmt sinkStmt;
    SootMethod srcMethod;

    private boolean isInMainThread = true;
    private boolean isLocked = false;

    public Sink(SootMethod sink, Stmt stmt, SootMethod src) {
        sinkMethod = sink;
        sinkStmt = stmt;
        srcMethod = src;
    }

    @Override
    public SootMethod method() {
        return sinkMethod;
    }

    public Stmt stmt() {
        return sinkStmt;
    }

    @Override
    public String getSignature() {
        return sinkMethod.getSignature();
    }

    @Override
    public String getSubSignature() {
        return sinkMethod.getSubSignature();
    }

    public SootMethod getDeclaringMethod() {
        return srcMethod;
    }

    @Override
    public boolean isInMainThread() {
        return isInMainThread;
    }

    @Override
    public void setInMainThread(boolean inMainThread) {
        isInMainThread = inMainThread;
    }

    @Override
    public boolean isLocked() {
        return isLocked;
    }

    @Override
    public void setLocked(boolean locked) {
        isLocked = locked;
    }

    public String toString() {
        return sinkMethod.getSignature();
    }
}