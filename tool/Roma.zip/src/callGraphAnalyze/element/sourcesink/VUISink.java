package src.callGraphAnalyze.element.sourcesink;

import src.callGraphAnalyze.element.sourcesink.Sink;
import src.callGraphAnalyze.element.sourcesink.Source;
import soot.SootMethod;
import soot.jimple.Stmt;

import java.util.HashSet;
import java.util.Set;

public class VUISink extends Sink {

    private Set<Source> guiSources = new HashSet<>();
    private Set<Source> possibleGuiSources = new HashSet<>();
    private Set<Source> allGUISources = new HashSet<>();
    private Set<Source> allPossibleGuiSources = new HashSet<>();
    private Set<Stmt> guiSourcesHidden = new HashSet<>();

    public VUISink(SootMethod sink, Stmt stmt, SootMethod src) {
        super(sink, stmt, src);
    }

    public void addGUINormalSource(Source source) {
        guiSources.add(source);
    }

    public void addPossibleGUINormalSource(Source source) {
        possibleGuiSources.add(source);
    }

    public void addAllGUINormalSources(Set<Source> sources) {
        allGUISources = sources;
    }

    public void addAllPossibleGUINormalSources(Set<Source> sources) {
        allPossibleGuiSources = sources;
    }

    public void addGUIHiddenSource(Stmt stmt) {
        guiSourcesHidden.add(stmt);
    }

    public Set<Source> getGUINormalSource() { return guiSources; }

    public Set<Source> getPossibleGUINormalSource() { return possibleGuiSources;}

    public Set<Source> getAllGUINormalSource() { return allGUISources;}

    public Set<Source> getAllPossibleGUINormalSource() { return allPossibleGuiSources;}

    public Set<Stmt> getGUIHiddenSource() { return guiSourcesHidden; }
}
