package src.callGraphAnalyze.element.sourcesink;

import javafx.util.Pair;
import src.callGraphAnalyze.element.sourcesink.Source;
import soot.SootMethod;
import soot.jimple.Stmt;

import java.util.HashSet;
import java.util.LinkedList;
import java.util.List;
import java.util.Set;

public class VUISource extends Source {

    private List<List<Pair<ISourceSink, Integer>>> vuiSourceTraces = new LinkedList<>();
    private Set<Source> guiSources = new HashSet<>();
    private Set<Source> possibleGuiSources = new HashSet<>();
    private Set<Stmt> guiSourcesHidden = new HashSet<>();
    private SootMethod srcOfsrcMethod = null;


    public VUISource(SootMethod src) {
        super(src);
    }

    public VUISource(SootMethod src, SootMethod srcOfsrc) {
        super(src);
        srcOfsrcMethod = srcOfsrc;
    }

    public SootMethod getSrcOfsrcMethod() {
        return srcOfsrcMethod;
    }

    public void addVUISourceTrace(List<List<Pair<ISourceSink, Integer>>> vuiSourceTrace) {
        vuiSourceTraces = vuiSourceTrace;
    }

    public List<List<Pair<ISourceSink, Integer>>> getVUISourceTrace() {
        return vuiSourceTraces;
    }

    public void addGUINormalSource(Source source) {
        guiSources.add(source);
    }

    public void addPossibleGUINormalSource(Source source) {
        possibleGuiSources.add(source);
    }

    public void addGUIHiddenSource(Stmt stmt) {
        guiSourcesHidden.add(stmt);
    }

    public Set<Source> getGUINormalSource() {
        return guiSources;
    }

    public Set<Source> getPossibleGUINormalSource() { return possibleGuiSources;}

    public Set<Stmt> getGUIHiddenSource() {
        return guiSourcesHidden;
    }

}
