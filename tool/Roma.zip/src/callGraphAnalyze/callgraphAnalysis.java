package src.callGraphAnalyze;

import afu.org.checkerframework.checker.oigj.qual.O;
import jxl.Sheet;
import jxl.Workbook;
import jxl.read.biff.BiffException;
import jxl.write.Label;
import jxl.write.WritableSheet;
import jxl.write.WritableWorkbook;
import jxl.write.WriteException;
import soot.jimple.toolkits.callgraph.CallGraph;
import soot.jimple.toolkits.typing.fast.QueuedSet;
import src.callGraphAnalyze.element.*;
import src.callGraphAnalyze.element.sourcesink.*;
import src.callGraphAnalyze.flowdroid.MySetupApplication;
import javafx.util.Pair;
import org.xmlpull.v1.XmlPullParserException;
import soot.*;
import soot.jimple.*;
import soot.jimple.infoflow.android.InfoflowAndroidConfiguration;
import soot.jimple.infoflow.android.callbacks.AbstractCallbackAnalyzer;
import soot.jimple.infoflow.android.callbacks.AndroidCallbackDefinition;
import soot.jimple.infoflow.android.resources.ARSCFileParser;
import soot.jimple.infoflow.sourcesSinks.definitions.ISourceSinkDefinition;
import soot.jimple.infoflow.sourcesSinks.definitions.MethodSourceSinkDefinition;
import soot.jimple.infoflow.util.SystemClassHandler;
import soot.jimple.internal.*;
import soot.jimple.toolkits.callgraph.Edge;
import soot.util.HashMultiMap;
import soot.util.MultiMap;

import java.io.*;
import java.util.*;
import java.util.List;
import net.sf.json.JSONObject;
import net.sf.json.JSONArray;

import javax.print.attribute.standard.MediaSize;

public class callgraphAnalysis {
    private final Set<String> vuiSourcesExpected = new HashSet<>();
    private Set<VUISource> realVUISources;
    private final Set<SootMethod> vuiSinksExpected = new HashSet<>();

    private final Set<SootMethod> guiSourcesExpected = new HashSet<>();

    private final myCallgraph callgraph;
    private Set<SootClass> entryPointClasses;
    private String apkFileName = "";
    private String apkIdPredix = "";

    private final WidgetInfo widgetInfo;
    private final AbstractCallbackAnalyzer jimpleClass;
    private final ARSCFileParser resources;

    private String outputDir = "";
    private boolean printResult = false;

    public callgraphAnalysis(MySetupApplication setupApplication, String outputdir, boolean hasinterresult) throws XmlPullParserException, IOException {
        InfoflowAndroidConfiguration config = setupApplication.getConfig();
        String apkLocation = config.getAnalysisFileConfig().getTargetAPKFile();
        widgetInfo = new WidgetInfo(setupApplication.getXmlCallbackToWidget(), setupApplication.getXmlCallbackToFile(), apkLocation);
        String jsonFileName = widgetInfo.getJsonFileName();
        apkFileName = jsonFileName.substring(0, jsonFileName.length() - 5);
        entryPointClasses = setupApplication.getEntrypointClasses();
        String apkId = setupApplication.getApkId();
        if(!apkId.contains("."))
            apkIdPredix = apkId;
        else {
            String[] splits = apkId.split("\\.");
            apkIdPredix = splits[0] + "." + splits[1];
        }
        System.out.println(apkIdPredix);

        myReachableMethods reachableMethods = new myReachableMethods(setupApplication.getCallGraph(), Scene.v().getEntryPoints().iterator(), Scene.v().getReachableMethods());
        reachableMethods.update();
        callgraph = new myCallgraph(setupApplication.getCallGraph(), reachableMethods, entryPointClasses, setupApplication.getDummyMainMethod(), apkIdPredix);

        getGUISourcesExpectedAndUpdateCallgraph(setupApplication.getCallbackMethods(), setupApplication.getXmlBasedCallbackMethods());
        getVUISourcesExpectedAndUpdateCallgraph();
        getVUISinksAndUpdateCallgraph(setupApplication.getSinks());


        realVUISources = null;

        jimpleClass = setupApplication.getJimpleClass();
        resources = setupApplication.getResources();

        outputDir = outputdir;
        printResult = hasinterresult;
    }

    private void getGUISourcesExpectedAndUpdateCallgraph(MultiMap<SootClass, AndroidCallbackDefinition> callbacks, MultiMap<SootClass, AndroidCallbackDefinition> xmlCallbacks) {
        for(SootClass sootClass: callbacks.keySet()) {
            Set<AndroidCallbackDefinition> androidCallbackDefinitions = callbacks.get(sootClass);
            for(AndroidCallbackDefinition androidCallbackDefinition: androidCallbackDefinitions) {
                SootMethod method = androidCallbackDefinition.getTargetMethod();
                String name = method.getName().toLowerCase(Locale.ROOT);
                if (name.startsWith("on")) {
                    String[] clickCallbacks = {"click", "select", "touch", "scroll", "press"};
                    for(String clickCallback: clickCallbacks) {
                        if(name.contains(clickCallback)) {
                            boolean isCallback = true;
                            for(Iterator<Edge> it = callgraph.edgesInto(method); it.hasNext();) {
                                Edge edge = it.next();
                                SootClass callBackMethodUsedClass = edge.getSrc().method().getDeclaringClass();
                                if(!callBackMethodUsedClass.getName().equals("dummyMainClass")) {
                                    isCallback = false;
                                    break;
                                }
                            }
                            if(isCallback)
                                guiSourcesExpected.add(method);
                        }
                    }
                }
            }
        }

        for(SootClass sootClass: xmlCallbacks.keySet()) {
            Set<AndroidCallbackDefinition> androidCallbackDefinitions = xmlCallbacks.get(sootClass);
            for(AndroidCallbackDefinition androidCallbackDefinition: androidCallbackDefinitions) {
                SootMethod method = androidCallbackDefinition.getTargetMethod();
                guiSourcesExpected.add(method);
            }
        }

        // remove added edges
//        guiSourcesExpected.addAll(callgraph.addGUICallbacks());
        // remove added edges
    }

    private void getVUISourcesExpectedAndUpdateCallgraph() throws IOException {
        vuiSourcesExpected.add("void onActivityResult(int,int,android.content.Intent)");
        vuiSourcesExpected.add("void onResults(android.os.Bundle)");
        vuiSourcesExpected.add("void onPartialResults(android.os.Bundle)");
        String asrFinalResult = "<com.baidu.aip.asrwakeup3.core.recog.listener.IRecogListener: void onAsrFinalResult(java.lang.String[],com.baidu.aip.asrwakeup3.core.recog.RecogResult)>";
        if(Scene.v().grabMethod(asrFinalResult) != null)
            vuiSourcesExpected.add("void onAsrFinalResult(java.lang.String[],com.baidu.aip.asrwakeup3.core.recog.RecogResult)");
        else
            vuiSourcesExpected.add("void onEvent(java.lang.String,java.lang.String,byte[],int,int)");
        vuiSourcesExpected.add("void onSuccess(com.tencent.aai.model.AudioRecognizeRequest,java.lang.String)");
        vuiSourcesExpected.add("void onSegmentSuccess(com.tencent.aai.model.AudioRecognizeRequest,com.tencent.aai.model.AudioRecognizeResult,int)");
        vuiSourcesExpected.add("void onSliceSuccess(com.tencent.aai.model.AudioRecognizeRequest,com.tencent.aai.model.AudioRecognizeResult,int)");
        vuiSourcesExpected.add("void onNuiEventCallback(com.alibaba.idst.nui.Constants$NuiEvent,int,int,com.alibaba.idst.nui.KwsResult,com.alibaba.idst.nui.AsrResult)");
        vuiSourcesExpected.add("<com.microsoft.cognitiveservices.speech.SpeechRecognitionResult: java.lang.String toString()>");
        // remove added edges
         callgraph.addVUISourcesToCallgraph(vuiSourcesExpected);
        // remove added edges
    }

    private void getVUISinksAndUpdateCallgraph(Set<? extends ISourceSinkDefinition> sinks) throws IOException {
        for(ISourceSinkDefinition sink: sinks) {
            if (sink instanceof MethodSourceSinkDefinition) {
                SootMethod method = Scene.v().grabMethod(sink.toString());
                if(method != null)
                    vuiSinksExpected.add(method);
            }
        }
        // remove added edges
//        callgraph.addVUISinksToCallgraph(vuiSinksExpected);
        // remove added edges
    }

    public myCallgraph getCallGraph() {
        return callgraph;
    }

    public WidgetInfo getWidgetInfo() {
        return widgetInfo;
    }

    public Set<VUISource> getRealVUISources() {
        return realVUISources;
    }

    public void analyzeCallGraph() throws IOException, BiffException, WriteException {
        step1();
    }

    private void step1() throws IOException, BiffException, WriteException {
        //Set<Stmt> vuiSinkStmts = getVUISinks();
        boolean addToStopVUI = false;
        boolean addToDiffPage = false;
        if(realVUISources == null)
            realVUISources = findRealVUISources(vuiSourcesExpected);

        getVUISourceInfo();
        // get vuiSinkTraces
        getVUISinkTraces();

        JSONArray array = new JSONArray();
        boolean hasRace1 = false;
        Map<VUISink, List<Set<Sink>>> vuiSinkToGuiSink = new HashMap();

        for(VUISource source: realVUISources) {
            Set<Stmt> imptVUISinkStmts = new HashSet<>();
            if(source.getVUISourceTrace().isEmpty())
                continue;
            SootMethod vuiSourceMethod = source.method();
            if(vuiSourceMethod == null)
                continue;
            System.out.println("Find GUI source trace for VUI source : " + vuiSourceMethod);
            //remove onClick(VUI)
            Set<SootMethod> onClickVUIs = new HashSet<>();
            for(List<Pair<ISourceSink, Integer>> vuiSourceTrace: source.getVUISourceTrace()) {
                SootMethod onClick_VUI = vuiSourceTrace.get(0).getKey().method();
                onClickVUIs.add(onClick_VUI);
            }
            //remove onClick(VUI)
            for(List<Pair<ISourceSink, Integer>> sinkTrace: source.getSinkTraces()) {
                ISourceSink sink = sinkTrace.get(sinkTrace.size() - 1).getKey();
                if(!(sink instanceof VUISink))
                    continue;
                VUISink vuiSink = (VUISink) sink;
                Stmt vuiSinkStmt = vuiSink.stmt();
                if (vuiSinkStmt == null)
                    continue;

                Set<Stmt> guiHiddenSources;
                List<Set<Sink>> correspondGUISink;
                Set<Source> guiNormalSources;
                Set<Source> allGUINormalSources;
                Set<Source> possibleGUINormalSources;
                Set<Source> allPossibleGUINormalSources;

                VUISink equalSink = findEqualSink(vuiSink, vuiSinkToGuiSink);
                if (equalSink != null) {
                    guiNormalSources = equalSink.getGUINormalSource();
                    for (Source guiNormalSource : guiNormalSources)
                        source.addGUINormalSource(guiNormalSource);

                    allGUINormalSources = equalSink.getAllGUINormalSource();
                    allPossibleGUINormalSources = equalSink.getAllPossibleGUINormalSource();

                    possibleGUINormalSources = equalSink.getPossibleGUINormalSource();
                    for (Source possibleGUINormalSource: possibleGUINormalSources)
                        source.addPossibleGUINormalSource(possibleGUINormalSource);

                    guiHiddenSources = equalSink.getGUIHiddenSource();
                    if (!guiHiddenSources.isEmpty())
                        source.addGUIHiddenSource(vuiSinkStmt);

                    if (imptVUISinkStmts.contains(equalSink.stmt()))
                        imptVUISinkStmts.add(vuiSinkStmt);
                }
                else {
                    System.out.println("The VUI sink is : " + vuiSinkStmt);

                    Set<Sink> sinVUISinkSet = new HashSet<>(Collections.singletonList(vuiSink));

                    correspondGUISink = callgraph.aliasAnalysis(sinVUISinkSet, vuiSinksExpected);//0: highly-likely GUI sink, 1: possible
                    vuiSinkToGuiSink.put(vuiSink, correspondGUISink);
                    System.out.println("The correspond GUI sinks are : ");
                    for(Sink sink0: correspondGUISink.get(0))
                        System.out.println("\t" + sink0.stmt() + " defined in " + sink0.getDeclaringMethod());
                    for(Sink sink1: correspondGUISink.get(1))
                        System.out.println("\t possible: " + sink1.stmt() + " defined in " + sink1.getDeclaringMethod());

                    List<Set<Source>> pair1 = getNormalGUISources(correspondGUISink.get(0), vuiSourceMethod.getName(), onClickVUIs);
                    List<Set<Source>> pair2 = getNormalGUISources(correspondGUISink.get(1), vuiSourceMethod.getName(), onClickVUIs);
                    allGUINormalSources = pair1.get(0);
                    guiNormalSources = pair1.get(1);
                    allPossibleGUINormalSources = pair2.get(0);
                    possibleGUINormalSources = pair2.get(1);
                    // check if GUI normal sources are defined in the same xml file as VUI onClick method
                    Set<String> vuiLayoutFiles = source.getLayoutFiles();

                    if (vuiLayoutFiles.isEmpty()) {
                        System.out.println("WARNING: The layoutFile of that VUI source method " + vuiSourceMethod + " is not found!");
                        System.exit(-1);
                    }

                    vuiSink.addAllGUINormalSources(allGUINormalSources);
                    vuiSink.addAllPossibleGUINormalSources(allPossibleGUINormalSources);

                    for (Source guiNormalSource : guiNormalSources) {
                        Set<String> layoutFiles = guiNormalSource.getLayoutFiles();
                        if(layoutFiles.isEmpty()) {
                            Set<SootClass> sootClasses = findUsageOfOnClickMethod(guiNormalSource.method());

                            for (SootClass usageClass : sootClasses) {
                                Set<String> layoutFile = findLayoutFileOfClass(usageClass, guiNormalSource.method());
                                layoutFiles.addAll(layoutFile);
                            }
                            if(layoutFiles.isEmpty()) {
                                for (SootClass usageClass: sootClasses)
                                    layoutFiles.add(usageClass.getName());
                            }

                            guiNormalSource.addLayoutFiles(layoutFiles);
                        }

                        System.out.println("The layoutFile of GUI source method " + guiNormalSource + " is defined in " + layoutFiles);

                        Set<String> temp = new HashSet<>(layoutFiles);
                        temp.retainAll(vuiLayoutFiles);
                        if (!temp.isEmpty() || layoutFiles.isEmpty()) {
                            if(!layoutFiles.isEmpty()) {
                                source.addGUINormalSource(guiNormalSource);
                                vuiSink.addGUINormalSource(guiNormalSource);
                            }
                            else{
                                source.addPossibleGUINormalSource(guiNormalSource);
                                vuiSink.addPossibleGUINormalSource(guiNormalSource);
                            }
                        } else {
                            if(!addToDiffPage) {
                                File file = new File(outputDir, "withoutRace_GUIAndVUINotOnSamePage.txt");
                                if(!file.exists())
                                    file.createNewFile();
                                String fileNameForDiffPage = file.getPath();
                                writeToFiles(fileNameForDiffPage, apkFileName);
                                addToDiffPage = true;
                            }
                        }
                    }

                    for (Source possibleGUINormalSource : possibleGUINormalSources) {
                        Set<String> layoutFiles = possibleGUINormalSource.getLayoutFiles();
                        if(layoutFiles.isEmpty()) {
                            Set<SootClass> sootClasses = findUsageOfOnClickMethod(possibleGUINormalSource.method());

                            for (SootClass usageClass : sootClasses) {
                                Set<String> layoutFile = findLayoutFileOfClass(usageClass, possibleGUINormalSource.method());
                                layoutFiles.addAll(layoutFile);
                            }
                            if(layoutFiles.isEmpty()) {
                                for (SootClass usageClass: sootClasses)
                                    layoutFiles.add(usageClass.getName());
                            }

                            possibleGUINormalSource.addLayoutFiles(layoutFiles);
                        }

                        System.out.println("The layoutFile of possible GUI source method " + possibleGUINormalSource + " is defined in " + layoutFiles);

                        Set<String> temp = new HashSet<>(layoutFiles);
                        temp.retainAll(vuiLayoutFiles);
                        if (!temp.isEmpty() || layoutFiles.isEmpty()) {
                            source.addPossibleGUINormalSource(possibleGUINormalSource);
                            vuiSink.addPossibleGUINormalSource(possibleGUINormalSource);
                        } else {
                            if(!addToDiffPage) {
                                File file = new File(outputDir, "withoutRace_GUIAndVUINotOnSamePage.txt");
                                if(!file.exists())
                                    file.createNewFile();
                                String fileNameForDiffPage = file.getPath();
                                writeToFiles(fileNameForDiffPage, apkFileName);
                                addToDiffPage = true;
                            }
                        }
                    }

                    guiHiddenSources = getHiddenGUISources(sinVUISinkSet);
                    for (Stmt guiHiddenSource : guiHiddenSources) {
                        source.addGUIHiddenSource(guiHiddenSource);
                        vuiSink.addGUIHiddenSource(guiHiddenSource);
                    }

                    if(!addToStopVUI &&
                            (allGUINormalSources.size() != guiNormalSources.size()
                                    || allPossibleGUINormalSources.size() != possibleGUINormalSources.size())) {
                        File file = new File(outputDir, "withoutRace_stopVUIOnGUISinkTrace.txt");
                        if(!file.exists())
                            file.createNewFile();
                        String fileNameForStopVUI = file.getPath();
                        writeToFiles(fileNameForStopVUI, apkFileName);
                        addToStopVUI = true;
                    }
                }
                if (!guiHiddenSources.isEmpty()
                        || allGUINormalSources != null && !allGUINormalSources.isEmpty()
                        || allPossibleGUINormalSources != null && !allPossibleGUINormalSources.isEmpty()) {
                    if(printResult) {
                        JSONObject jsonId = new JSONObject();
                        jsonId.put("VUISinkStmt", vuiSinkStmt.toString());
                        jsonId.put("hiddenSources", guiHiddenSources.toString());
                        jsonId.put("normalSources", allGUINormalSources.toString());
                        jsonId.put("possibleNormalSources", allPossibleGUINormalSources.toString());
                        array.add(jsonId);
                    }
                    hasRace1 = true;
                }
                if(!guiHiddenSources.isEmpty() || !guiNormalSources.isEmpty() || !possibleGUINormalSources.isEmpty())
                    imptVUISinkStmts.add(vuiSinkStmt);
            }

            System.out.println("The important VUI sink stmts are " + imptVUISinkStmts);

            //remove unnecessary VUI sink trace according important VUI sink stmts
            source.keepSinks(imptVUISinkStmts);
        }
        recordStep1Results(hasRace1, array);
    }

    private Set<VUISource> findRealVUISources(Set<String> subSignatures) {
        Set<VUISource> realVUISources = new HashSet<>();
        Set<SootMethod> sources = new HashSet<>();
        for (Iterator<String> iter = subSignatures.iterator(); iter.hasNext(); ) {
            String signature = iter.next();
            Set<VUISource> realSources = new HashSet<>();

            // find corresponding real VUI sources for vui Sources
            for(SootMethod sm: callgraph.findValidMethodWithSig(signature)) {
                if(sm.getSignature().equals("<com.microsoft.cognitiveservices.speech.SpeechRecognitionResult: java.lang.String toString()>")) {
                    for(Iterator<Edge> it = callgraph.edgesInto(sm); it.hasNext();) {
                        SootMethod srcOfSrc = it.next().src();
                        if(sources.contains(srcOfSrc))
                            continue;
                        sources.add(srcOfSrc);
                        realSources.add(new VUISource(sm, srcOfSrc));
                    }
                } else {
                    if(sources.contains(sm))
                        continue;
                    sources.add(sm);
                    realSources.add(new VUISource(sm));
                }
            }

            if (!realSources.isEmpty()) {
                for(VUISource source: realSources) {
                    if (source.getSubSignature().equals("void onActivityResult(int,int,android.content.Intent)")) {
                        boolean relateToVoice = false;
                        Queue<Pair<SootMethod, Integer>> workList = new LinkedList<>();
                        workList.offer(new Pair<>(source.method(), 0));
                        while(!workList.isEmpty() && !relateToVoice) {
                            Pair<SootMethod, Integer> pair = workList.poll();
                            SootMethod method = pair.getKey();
                            int depth = pair.getValue();
                            for (Iterator<Edge> e = callgraph.edgesOutOf(method); e.hasNext(); ) {
                                Edge edge = e.next();
                                SootMethod tgt = edge.tgt();
                                Stmt stmt = edge.srcStmt();
                                if (stmt != null
                                        && tgt != null
                                        && tgt.getSubSignature().equals("java.util.ArrayList getStringArrayListExtra(java.lang.String)")
                                        && stmt.getInvokeExpr().getArg(0) instanceof StringConstant
                                        && ((StringConstant) stmt.getInvokeExpr().getArg(0)).value.equals("android.speech.extra.RESULTS")) {
                                    relateToVoice = true;
                                    break;
                                }
                                if(tgt != null) {
                                    if(depth + 1 <= 2)
                                        workList.offer(new Pair<>(tgt, depth + 1));
                                }
                            }
                        }
                        if (relateToVoice)
                            realVUISources.add(source);
                    }
                    else
                        realVUISources.add(source);
                }
            }
        }
        return realVUISources;
    }

    private void getVUISinkTraces() throws IOException {
        for (VUISource realSource : realVUISources) {
            Set<SootMethod> singRealSourceSet = null;
            if(realSource.getVUISourceTrace().isEmpty())
                continue;
            System.out.println("Find VUI sinks for " + realSource.method());
            if(realSource.getSignature().equals("<com.microsoft.cognitiveservices.speech.SpeechRecognitionResult: java.lang.String toString()>")) {
                singRealSourceSet = new HashSet<>(Collections.singletonList(realSource.getSrcOfsrcMethod()));
            } else {
                singRealSourceSet = new HashSet<>(Collections.singletonList(realSource.method()));
            }
            Map<Stmt, List<Pair<ISourceSink, Integer>>> VUISinkToVUISinkTrace = new HashMap<>();
            for (List<Pair<ISourceSink, Integer>> trace : callgraph.analyzeCallGraphForSourceSinks(true, singRealSourceSet, vuiSinksExpected)) {
                ISourceSink sink = trace.get(trace.size() - 1).getKey();
                if (sink instanceof VUISink) {
                    Stmt sinkStmt = ((VUISink) sink).stmt();
                    List<Pair<ISourceSink, Integer>> VUISinkTrace = VUISinkToVUISinkTrace.get(sinkStmt);
                    if(VUISinkTrace != null) {
                        if(trace.size() < VUISinkTrace.size())
                            VUISinkToVUISinkTrace.put(sinkStmt, trace);
                    } else
                        VUISinkToVUISinkTrace.put(sinkStmt, trace);
                }
            }
            for(List<Pair<ISourceSink, Integer>> VUISinkTrace: VUISinkToVUISinkTrace.values()) {
                realSource.addSinkTrace(VUISinkTrace);
                System.out.println("VUI sink trace: " + VUISinkTrace);
            }
            if(realSource.getSinkTraces().isEmpty())
                System.out.println("VUI sink trace is empty");
        }
    }

    private void getVUISourceInfo() throws IOException {
        MultiMap<SootMethod, String> onClickMethodToLayoutFiles = new HashMultiMap<>();
        boolean addToUnReachableVUI = false;
        for (VUISource realVUISource: realVUISources) {
            //given onResults, find: from onClick -> startListening
//            if(realVUISource.method().getName().equals("onActivityResult"))
//                continue;
            Set<String> layoutFiles = new HashSet<>();
            System.out.println("Find onClick method for VUI source : " + realVUISource.getSignature());
            List<List<Pair<ISourceSink, Integer>>> vuiCallLists = getVUISourceTrace(realVUISource);
            Iterator<List<Pair<ISourceSink, Integer>>> iterator = vuiCallLists.iterator();
            while(iterator.hasNext()) {
                List<Pair<ISourceSink, Integer>> vuiCallList = iterator.next();
                SootMethod onClickMethod = vuiCallList.get(0).getKey().method();;
                System.out.println("VUI source trace: " + vuiCallList);
                Set<String> temp = onClickMethodToLayoutFiles.get(onClickMethod);
                if(temp.isEmpty()) {
                    Set<SootClass> sootClasses = findUsageOfOnClickMethod(onClickMethod);
                    System.out.println("VUI onClick method " + onClickMethod + " is used in class " + sootClasses);
                    if(!isReachableClasses(sootClasses)) {
                        System.out.println("VUI onClick method " + onClickMethod + " is not reachable!");
                        iterator.remove();
                        if(!addToUnReachableVUI) {
                            File file = new File(outputDir, "withoutRace_unReachableVUISource.txt");
                            if (!file.exists())
                                file.createNewFile();
                            String fileNameForUnReachableVUI = file.getPath();
                            writeToFiles(fileNameForUnReachableVUI, apkFileName);
                            addToUnReachableVUI = true;
                        }
                        continue;
                    }
                    for (SootClass usageClass : sootClasses) {
                        Set<String> layoutFile = findLayoutFileOfClass(usageClass, onClickMethod);
                        layoutFiles.addAll(layoutFile);
                    }
                    if(layoutFiles.isEmpty()) {
                        for (SootClass usageClass: sootClasses)
                            layoutFiles.add(usageClass.getName());
                    }
                    onClickMethodToLayoutFiles.putAll(onClickMethod, layoutFiles);
                } else
                    layoutFiles.addAll(temp);
            }
            if(vuiCallLists.isEmpty()) {
                System.out.println("WARNING: VUI source for " + realVUISource.method() + " is empty.");
                if(!addToUnReachableVUI) {
                    File file = new File(outputDir, "withoutRace_unReachableVUISource.txt");
                    if (!file.exists())
                        file.createNewFile();
                    String fileNameForUnReachableVUI = file.getPath();
                    writeToFiles(fileNameForUnReachableVUI, apkFileName);
                    addToUnReachableVUI = true;
                }
            } else {
                realVUISource.addVUISourceTrace(vuiCallLists);
                realVUISource.addLayoutFiles(layoutFiles);
                System.out.println("The layoutFile of VUI source " + realVUISource.method() + " is defined in " + layoutFiles);
            }
        }
    }

    private List<List<Pair<ISourceSink, Integer>>> getVUISourceTrace(VUISource vuiSource) throws IOException {
        //Set<SootMethod> vuiClickMethods = new HashSet<>();
        List<SootMethod> callersOfStartListening = new LinkedList<>();
        List<List<ISourceSink>> shortVUISourceTraces = new LinkedList<>();
        List<List<Pair<ISourceSink, Integer>>> vuiSourceTraces = new LinkedList<>();

        if(vuiSource.getSignature().equals("<com.microsoft.cognitiveservices.speech.SpeechRecognitionResult: java.lang.String toString()>")) { //microsoft
            SootMethod startListening = Scene.v().grabMethod("<com.microsoft.cognitiveservices.speech.SpeechRecognizer: java.util.concurrent.Future recognizeOnceAsync()>");
            SootMethod src = vuiSource.getSrcOfsrcMethod();
            OtherMethod otherMethod = new OtherMethod(src);
            System.out.println("caller of method " + startListening.getSignature());
            for(Iterator<Edge> it = callgraph.edgesInto(startListening); it.hasNext();) {
                System.out.println(it.next().src());
            }
            for(Iterator<Edge> it = callgraph.edgesOutOf(src); it.hasNext();) { //recognizeOnceAysnc, toString used in src
                Edge edge = it.next();
                SootMethod tgt = edge.tgt();
                if(tgt.getSignature().equals(startListening.getSignature())) {
                    List<ISourceSink> callList = new LinkedList<>();
                    callList.add(otherMethod);
                    callList.add(new OtherMethod(tgt));
                    shortVUISourceTraces.add(callList);
                    callersOfStartListening.add(src);
                    break;
                }
            }
        }
        else if(vuiSource.getSubSignature().equals("void onActivityResult(int,int,android.content.Intent)")) {
            SootClass declaringClassOfVUISource = vuiSource.getDeclaringClass();
            Queue<SootClass> workList = new LinkedList<>();
            Set<SootClass> processedClasses = new HashSet<>();
            Set<SootMethod> processedMethods = new HashSet<>();
            workList.offer(declaringClassOfVUISource);
            for (SootClass parentClass : Scene.v().getActiveHierarchy().getSuperclassesOf(declaringClassOfVUISource)) {
                if (!SystemClassHandler.v().isClassInSystemPackage(parentClass.getName()) && !parentClass.isLibraryClass())
                    workList.offer(parentClass);
            }
            for(SootClass innerClass: Scene.v().getClasses()) {
                if (innerClass.getName().startsWith(declaringClassOfVUISource.getName() + "$"))
                    workList.offer(innerClass);
            }
            while(!workList.isEmpty()) {
                SootClass sc = workList.poll();
                if(processedClasses.contains(sc))
                    continue;
                processedClasses.add(sc);
                for (SootMethod method : sc.getMethods()) {
                    if(processedMethods.contains(method))
                        continue;
                    processedMethods.add(method);
                    Source source = new Source(method);
                    for(Iterator<Edge> it = callgraph.edgesOutOf(method); it.hasNext(); ) {
                        Edge edge = it.next();
                        SootMethod tgt = edge.tgt();
                        Stmt srcStmt = edge.srcStmt();
                        if(tgt == null)
                            continue;
                        if(tgt.getSignature().equals("<android.view.View: void setOnClickListener(android.view.View$OnClickListener)>")
                                || (tgt.getParameterCount() >= 1 && tgt.getParameterType(0).toString().equals("android.view.View$OnClickListener"))) {
                            Value value = srcStmt.getInvokeExpr().getArg(0);//setOnClickListener(class1)
                            String setCallbackClass = value.getType().toString();
                            SootClass callBackClass = Scene.v().getSootClassUnsafe(setCallbackClass);
                            if(callBackClass != null)
                                workList.offer(callBackClass);
                        }
                        if (tgt.getSignature().equals("<android.content.Intent: void <init>(java.lang.String)>")
                                && srcStmt.getInvokeExpr().getArg(0) instanceof StringConstant
                                && ((StringConstant) srcStmt.getInvokeExpr().getArg(0)).value.equals("android.speech.action.RECOGNIZE_SPEECH")) {
                            List<ISourceSink> vuiSourceTraceShort = new LinkedList<>();
                            vuiSourceTraceShort.add(source);
                            vuiSourceTraceShort.add(new Sink(tgt, srcStmt, method));
                            shortVUISourceTraces.add(vuiSourceTraceShort);
                            callersOfStartListening.add(method);
                            break;
                        }
                    }
                }
            }
        }
        else{
            SootClass callBackDeclaredClass = vuiSource.getDeclaringClass();
            SootMethod listener = findSetListenerMethod(vuiSource);
            SootMethod startListening = findStartListeningMethod(vuiSource);
            if(listener == null || startListening == null) {
                System.out.println(listener);
                System.out.println(startListening);
                System.out.println("Listener or startListening is null");
                System.exit(-1);
            }
            for (Iterator<Edge> it = callgraph.edgesInto(listener); it.hasNext(); ) {
                Edge edge = it.next();
                SootMethod callerOfListener = edge.src();
                boolean findRightCallbackClass = isCallbackClassEqualToSetListener(edge.srcStmt(), callerOfListener, callBackDeclaredClass.getName());

                if(!findRightCallbackClass)
                    continue;
                SootClass declaringClassOfcallerOfListener = callerOfListener.getDeclaringClass();
                Queue<SootClass> workList = new LinkedList<>();
                Set<SootClass> processedClasses = new HashSet<>();
                Set<SootMethod> processedMethods = new HashSet<>();
                workList.offer(declaringClassOfcallerOfListener);
                String declaringClassNameOfcallerOfListener = declaringClassOfcallerOfListener.getName();
                for(SootClass sc: Scene.v().getClasses()) {
                    if(sc.getName().startsWith(declaringClassNameOfcallerOfListener + "$"))
                        workList.offer(sc);
                }
                while(!workList.isEmpty()) {
                    SootClass sc = workList.poll();
                    if(processedClasses.contains(sc))
                        continue;
                    processedClasses.add(sc);
                    for (SootMethod method : sc.getMethods()) {
                        if(processedMethods.contains(method))
                            continue;
                        processedMethods.add(method);
                        Source src = new Source(method);
                        List<ISourceSink> vuiSourceTraceShort = new LinkedList<>();
                        vuiSourceTraceShort.add(src);
                        Queue<SootMethod> workList1 = new LinkedList<>();
                        workList1.offer(method);
                        boolean findStartListening = false;
                        while(!workList1.isEmpty() && !findStartListening) {
                            SootMethod sm = workList1.poll();
                            Stmt startListeningStmt = null;
                            for (Iterator<Edge> it0 = callgraph.edgesOutOf(sm); it0.hasNext(); ) {
                                Edge edge0 = it0.next();
                                Stmt srcStmt = edge0.srcStmt();
                                SootMethod methodOfStmt = myCallgraph.getMethodFromStmt(srcStmt);
                                SootMethod tgt = edge0.tgt();
                                if (methodOfStmt != null
                                        && (methodOfStmt.getName().equals("start") && tgt.getName().equals("run")
                                        || methodOfStmt.getName().equals("execute") && tgt.getName().equals("doInBackground"))) {
                                    // if methodOfStmt is start && tgt is run, set the inMainThread to false
                                    vuiSourceTraceShort.add(new Source(methodOfStmt));
                                    vuiSourceTraceShort.add(new Source(tgt));
                                    workList1.offer(tgt);
                                }
                                if(tgt == null)
                                    continue;
                                if (tgt.getSubSignature().equals(startListening.getSubSignature()) &&
                                        (!tgt.getName().equals("send") ||
                                                (srcStmt.getInvokeExpr().getArg(0) instanceof StringConstant
                                                        && ((StringConstant) srcStmt.getInvokeExpr().getArg(0)).value.equals("asr.start")))) {
                                    vuiSourceTraceShort.add(new Source(tgt));
                                    startListeningStmt = srcStmt;
                                    findStartListening = true;
                                    break;
                                }
                                if (tgt.getSignature().equals("<android.view.View: void setOnClickListener(android.view.View$OnClickListener)>")
                                        || (tgt.getParameterCount() >= 1 && tgt.getParameterType(0).toString().equals("android.view.View$OnClickListener"))) {
                                    Value v = srcStmt.getInvokeExpr().getArg(0);//setOnClickListener(class1))
                                    String setOnClickClass = v.getType().toString();
                                    SootClass callBackClass = Scene.v().getSootClassUnsafe(setOnClickClass);
                                    if (callBackClass != null)
                                        workList.offer(callBackClass);
                                }
                            }
                            if(findStartListening) {
                                boolean hasStartActivityForResult = false;
                                for (Iterator<Edge> it0 = callgraph.edgesOutOf(sm); it0.hasNext(); ) {
                                    Edge edge1 = it0.next();
                                    SootMethod tgt = edge1.tgt();
                                    Stmt stmt = edge1.srcStmt();
                                    if(tgt != null
                                            && tgt.getSubSignature().equals("void startActivityForResult(android.content.Intent,int)")
                                            && stmt.getInvokeExpr().getArg(0).equivTo(startListeningStmt.getInvokeExpr().getArg(0))) {
                                        hasStartActivityForResult = true;
                                        break;
                                    }
                                }
                                if(!hasStartActivityForResult) {
                                    shortVUISourceTraces.add(vuiSourceTraceShort);
                                    callersOfStartListening.add(method);
                                } else
                                    findStartListening = false;
                            }
                        }
                    }
                }
            }
        }

        boolean isResult = false;
        Set<SootMethod> realSinks = new HashSet<>();
        List<List<ISourceSink>> longVUISourceTraces = new LinkedList<>();
        for (int i = 0; i < callersOfStartListening.size(); i++) {
            SootMethod callerOfStartListening = callersOfStartListening.get(i);
            List<ISourceSink> shortVUISourceTrace = shortVUISourceTraces.get(i);
            for (SootMethod source: guiSourcesExpected) {
                if (source.getSubSignature().equals(callerOfStartListening.getSubSignature())) {
                    isResult = true;
                    break;
                }
            }
            if(!isResult) {
                realSinks.add(callerOfStartListening);
                longVUISourceTraces.add(shortVUISourceTrace);
            } else {
                List<Pair<ISourceSink, Integer>> vuiSourceTrace = new LinkedList<>();
                boolean hasSynchronized = callgraph.hasSynchronized(shortVUISourceTrace.get(0).method());
                if(shortVUISourceTrace.size() == 2) {
                    vuiSourceTrace.add(new Pair<>(shortVUISourceTrace.get(0), 1));
                    if(!callgraph.hasBrunch(callerOfStartListening)) {
                        for(ISourceSink importFunc: callgraph.getImportantFuncsInMethod(shortVUISourceTrace.get(0))) {
                            if(hasSynchronized) {
                                importFunc.setLocked(true);
                            }
                            vuiSourceTrace.add(new Pair<>(importFunc, 0));
                        }
                        if(vuiSource.getSubSignature().equals("void onActivityResult(int,int,android.content.Intent)")) {
                            ISourceSink startLis = shortVUISourceTrace.get(1);
                            if(hasSynchronized)
                                startLis.setLocked(true);
                            vuiSourceTrace.add(new Pair<>(startLis, 0));
                        }
                    }
                    else {
                        ISourceSink startLis = shortVUISourceTrace.get(1);
                        if(hasSynchronized)
                            startLis.setLocked(true);
                        vuiSourceTrace.add(new Pair<>(startLis, 0));
                    }
                }
                else {
                    vuiSourceTrace.add(new Pair<>(shortVUISourceTrace.get(0), 2));
                    if(!callgraph.hasBrunch(callerOfStartListening)) {
                        for(ISourceSink importFunc: callgraph.getImportantFuncsInMethod(shortVUISourceTrace.get(0))) {
                            if(hasSynchronized) {
                                importFunc.setLocked(true);
                            }
                            vuiSourceTrace.add(new Pair<>(importFunc, 1));
                        }
                    }
                    for(int ind = 1; ind < shortVUISourceTrace.size() - 1; ++ind) {
                        ISourceSink importFunc = shortVUISourceTrace.get(ind);
                        if(hasSynchronized) {
                            importFunc.setLocked(true);
                        }
                        vuiSourceTrace.add(new Pair<>(importFunc, 1));
                    }
                    if(!hasSynchronized)
                        hasSynchronized = callgraph.hasSynchronized(shortVUISourceTrace.get(shortVUISourceTrace.size() - 2).method());
                    if(!callgraph.hasBrunch(shortVUISourceTrace.get(shortVUISourceTrace.size() - 2).method())) {
                        for(ISourceSink importFunc: callgraph.getImportantFuncsInMethod(shortVUISourceTrace.get(shortVUISourceTrace.size() - 2))) {
                            if(hasSynchronized) {
                                importFunc.setLocked(true);
                            }
                            vuiSourceTrace.add(new Pair<>(importFunc, 0));
                        }
                        if(vuiSource.getSubSignature().equals("void onActivityResult(int,int,android.content.Intent)")) {
                            ISourceSink startLis = shortVUISourceTrace.get(shortVUISourceTrace.size() - 1);
                            if(hasSynchronized)
                                startLis.setLocked(true);
                            vuiSourceTrace.add(new Pair<>(startLis, 0));
                        }
                    }
                    else {
                        ISourceSink startLis = shortVUISourceTrace.get(shortVUISourceTrace.size() - 1);
                        if(hasSynchronized) {
                            startLis.setLocked(true);
                        }
                        vuiSourceTrace.add(new Pair<>(startLis, 0));
                    }
                }
                vuiSourceTraces.add(vuiSourceTrace);
            }
        }
        Map<SootMethod, List<Pair<ISourceSink, Integer>>> onClickVUIToVUISourceTrace = new HashMap<>();
        for(SootMethod realSink: realSinks) {
            Set<SootMethod> singRealSinkSet = new HashSet<>(Collections.singletonList(realSink));
            for(List<Pair<ISourceSink, Integer>> trace: callgraph.analyzeCallGraphForSourceSinks(false, guiSourcesExpected, singRealSinkSet)) {
                ISourceSink onClick = trace.get(0).getKey();
                SootMethod onClickVUI = onClick.method();
                if(onClick instanceof Source && onClickVUI != null) {
                    List<Pair<ISourceSink, Integer>> vuiSourceTrace = onClickVUIToVUISourceTrace.get(onClickVUI);
                    if(vuiSourceTrace != null) {
                        if(trace.size() < vuiSourceTrace.size())
                            onClickVUIToVUISourceTrace.put(onClickVUI, trace);
                    } else {
                        onClickVUIToVUISourceTrace.put(onClickVUI, trace);
                    }
                }
            }
        }
        for (SootMethod onClickVUI: onClickVUIToVUISourceTrace.keySet()) {
            List<Pair<ISourceSink, Integer>> vuiSourceTrace = onClickVUIToVUISourceTrace.get(onClickVUI);
            for(List<ISourceSink> longVUISourceTrace: longVUISourceTraces) {
                Pair<ISourceSink, Integer> pair = vuiSourceTrace.get(vuiSourceTrace.size() - 1);
                String name = pair.getKey().method().getName();
                if(name.equals("post") || name.equals("postDelayed") || name.equals("runOnUiThread") || name.equals("execute") || name.equals("start") && pair.getKey().method().getDeclaringClass().getName().equals("java.lang.Thread"))
                    pair = vuiSourceTrace.get(vuiSourceTrace.size() - 2);
                ISourceSink lastSourceSink = pair.getKey();
                if(longVUISourceTrace.get(0).method().equals(lastSourceSink.method())) {
                    List<Pair<ISourceSink, Integer>> fullVUISourceTrace = new LinkedList<>(vuiSourceTrace);
                    boolean isLocked = lastSourceSink.isLocked();
                    boolean hasSynchronized = callgraph.hasSynchronized(lastSourceSink.method());
                    if(!callgraph.hasBrunch(longVUISourceTrace.get(0).method())) {
                        for(ISourceSink importFunc: callgraph.getImportantFuncsInMethod(longVUISourceTrace.get(0))) {
                            if(isLocked || hasSynchronized)
                                importFunc.setLocked(true);
                            fullVUISourceTrace.add(new Pair<>(importFunc, -1));
                        }
                        if(vuiSource.getSubSignature().equals("void onActivityResult(int,int,android.content.Intent)")) {
                            ISourceSink startLis = longVUISourceTrace.get(1);
                            if(isLocked || hasSynchronized)
                                startLis.setLocked(true);
                            fullVUISourceTrace.add(new Pair<>(startLis, -1));
                        }
                    }
                    else {
                        ISourceSink startLis = longVUISourceTrace.get(1);
                        if(isLocked || hasSynchronized)
                            startLis.setLocked(true);
                        fullVUISourceTrace.add(new Pair<>(startLis, -1));
                    }
                    vuiSourceTraces.add(fullVUISourceTrace);
                    break;
                }
            }
        }
        return vuiSourceTraces;
    }

    private SootMethod findStartListeningMethod(VUISource vuiSource) {
        SootMethod startListening = null;
        String vuiSourceName = vuiSource.method().getName();
        switch (vuiSourceName) {
            case "onResults":
            case "onPartialResults":  //google or huawei
                startListening = Scene.v().grabMethod("<android.speech.SpeechRecognizer: void startListening(android.content.Intent)>");
                if (startListening == null)
                    startListening = Scene.v().grabMethod("<com.huawei.hiai.asr.AsrRecognizer: void startListening(android.content.Intent)>");
                break;
            case "onEvent": //baidu
                startListening = Scene.v().grabMethod("<com.baidu.speech.EventManager: void send(java.lang.String,java.lang.String,byte[],int,int)>");
                break;
            case "onAsrFinalResult": //baidu
                startListening = Scene.v().grabMethod("<com.baidu.aip.asrwakeup3.core.recog.MyRecognizer: void start(java.util.Map)>");
                break;
            case "onNuiEventCallback":  //alibaba
                startListening = Scene.v().grabMethod("<com.alibaba.idst.nui.NativeNui: int startDialog(com.alibaba.idst.nui.Constants$VadMode,java.lang.String)>");
                break;
            case "onSuccess":
            case "onSegmentSuccess":
            case "onSliceSuccess":  //tencent
                startListening = Scene.v().grabMethod("<com.tencent.aai.AAIClient: void startAudioRecognize(com.tencent.aai.model.AudioRecognizeRequest,com.tencent.aai.listener.AudioRecognizeResultListener,com.tencent.aai.listener.AudioRecognizeStateListener,com.tencent.aai.listener.AudioRecognizeTimeoutListener,com.tencent.aai.model.AudioRecognizeConfiguration)>");
                if(startListening == null)
                    startListening = Scene.v().grabMethod("<com.tencent.aai.AAIClient: void startAudioRecognize(com.tencent.aai.model.AudioRecognizeRequest,com.tencent.aai.listener.AudioRecognizeResultListener,com.tencent.aai.listener.AudioRecognizeStateListener,com.tencent.aai.model.AudioRecognizeConfiguration)>");
                if(startListening == null)
                    startListening = Scene.v().grabMethod("<com.tencent.aai.AAIClient: void startAudioRecognize(com.tencent.aai.model.AudioRecognizeRequest,com.tencent.aai.listener.AudioRecognizeResultListener,com.tencent.aai.model.AudioRecognizeConfiguration)>");
                break;
        }
        return startListening;
    }

    private SootMethod findSetListenerMethod(VUISource vuiSource) {
        SootMethod listener = null;
        String vuiSourceName = vuiSource.method().getName();
        switch (vuiSourceName) {
            case "onResults":
            case "onPartialResults":  //google or huawei
                listener = Scene.v().grabMethod("<android.speech.SpeechRecognizer: void setRecognitionListener(android.speech.RecognitionListener)>");
                if (listener == null)
                    listener = Scene.v().grabMethod("<com.huawei.hiai.asr.AsrRecognizer: void init(android.content.Intent,com.huawei.hiai.asr.AsrListener)>");
                break;
            case "onEvent"://baidu
                listener = Scene.v().grabMethod("<com.baidu.speech.EventManager: void registerListener(com.baidu.speech.EventListener)>");
                if(listener == null)
                    listener = Scene.v().grabMethod("<com.baidu.speech.EventManager: void registerListener(com.baidu.speech.IEventListener)>");
                break;
            case "onAsrFinalResult"://baidu
                listener = Scene.v().grabMethod("<com.baidu.aip.asrwakeup3.core.recog.MyRecognizer: void <init>(android.content.Context,com.baidu.aip.asrwakeup3.core.recog.listener.IRecogListener)>");
                break;
            case "onNuiEventCallback":  //alibaba
                listener = Scene.v().grabMethod("<com.alibaba.idst.nui.NativeNui: int initialize(com.alibaba.idst.nui.INativeNuiCallback,java.lang.String,com.alibaba.idst.nui.Constants$LogLevel,boolean)>");
                break;
            case "onSuccess":
            case "onSegmentSuccess":
            case "onSliceSuccess":  //tencent
                listener = Scene.v().grabMethod("<com.tencent.aai.AAIClient: void startAudioRecognize(com.tencent.aai.model.AudioRecognizeRequest,com.tencent.aai.listener.AudioRecognizeResultListener,com.tencent.aai.listener.AudioRecognizeStateListener,com.tencent.aai.listener.AudioRecognizeTimeoutListener,com.tencent.aai.model.AudioRecognizeConfiguration)>");
                if(listener == null)
                    listener = Scene.v().grabMethod("<com.tencent.aai.AAIClient: void startAudioRecognize(com.tencent.aai.model.AudioRecognizeRequest,com.tencent.aai.listener.AudioRecognizeResultListener,com.tencent.aai.listener.AudioRecognizeStateListener,com.tencent.aai.model.AudioRecognizeConfiguration)>");
                if(listener == null)
                    listener = Scene.v().grabMethod("<com.tencent.aai.AAIClient: void startAudioRecognize(com.tencent.aai.model.AudioRecognizeRequest,com.tencent.aai.listener.AudioRecognizeResultListener,com.tencent.aai.model.AudioRecognizeConfiguration)>");
                break;
        }
        return listener;
    }

    private boolean isCallbackClassEqualToSetListener(Stmt setListenerStmt, SootMethod callerOfListener, String callBackClassName) {
        int argInd = -1;
        SootMethod setListenerMethod = myCallgraph.getMethodFromStmt(setListenerStmt);
        if(setListenerMethod == null)
            return false;
        String listenerName = setListenerMethod.getName();
        switch (listenerName) {
            case "setRecognitionListener":
            case "registerListener":
            case "initialize":
                argInd = 0;
                break;
            case "init":
            case "startAudioRecognize":
            case "<init>":
                argInd = 1;
                break;
            default:
                System.out.println(listenerName + " is not covered?");
                System.exit(-1);
        }
        Value value = setListenerStmt.getInvokeExpr().getArg(argInd);
        String basicCallbackClassName = setListenerMethod.getParameterType(argInd).toString();
        String setCallbackClass = value.getType().toString();
        if(setCallbackClass.equals(callBackClassName))
            return true;
        else if(setCallbackClass.equals(basicCallbackClassName)) {
            //find usage of src method
            SootMethod src = callerOfListener;
            for(int ind = 0; ind < src.getParameterCount(); ++ind) {
                Type typeOfSrc = src.getParameterType(ind);
                String typeNameOfSrc = typeOfSrc.toString();
                if(typeNameOfSrc.equals(callBackClassName)) {
                    return true;
                }
                if(typeOfSrc.toString().equals(basicCallbackClassName)) {
                    for(Iterator<Edge> it0 = callgraph.edgesInto(src); it0.hasNext();) {
                        Edge edgeToSrc = it0.next();
                        Stmt stmtOfSrc = edgeToSrc.srcStmt();
                        Value arg = stmtOfSrc.getInvokeExpr().getArg(ind);
                        if(arg.getType().toString().equals(callBackClassName)) {
                            return true;
                        }
                    }
                    break;
                }
            }
        }
        return false;
    }

    private boolean isReachableClasses(Set<SootClass> sootClasses) {
        Set<SootClass> processedClasses = new HashSet<>();
        Queue<SootClass> workList = new LinkedList<>();
        for(SootClass sc: sootClasses)
            workList.offer(sc);
        while(!workList.isEmpty()) {
            SootClass sc = workList.poll();
            if(sc.hasOuterClass()) {
                SootClass outClass = sc.getOuterClass();
                sc = outClass;
            }
            if(processedClasses.contains(sc))
                continue;
            processedClasses.add(sc);
            if(entryPointClasses.contains(sc))
                return true;
            Set<SootClass> classesUseMethodsInSc = new HashSet<>();
            for(SootMethod sm: sc.getMethods()) {
                Iterator<Edge> iterator = callgraph.edgesInto(sm);
                while(iterator.hasNext()) {
                    Edge edge = iterator.next();
                    classesUseMethodsInSc.add(edge.src().getDeclaringClass());
                }
            }
            if(sc.isInterface()) {
                for(SootClass parent: Scene.v().getActiveHierarchy().getDirectImplementersOf(sc))
                    workList.offer(parent);
            } else {
                for (SootClass parent : Scene.v().getActiveHierarchy().getDirectSubclassesOf(sc))
                    workList.offer(parent);
            }
            workList.addAll(classesUseMethodsInSc);
        }
        return false;
    }

    private VUISink findEqualSink(Sink vuiSink, Map<VUISink, List<Set<Sink>>> vuiSinkToGuiSink) {
        for(VUISink key: vuiSinkToGuiSink.keySet()) {
            if(key.stmt().equals(vuiSink.stmt()) && key.method().equals(vuiSink.method()))
                return key;
            for(Sink value: vuiSinkToGuiSink.get(key).get(0))
                if(value.stmt().equals(vuiSink.stmt()) && value.method().equals(vuiSink.method()))
                    return key;
        }
        return null;
    }

    private List<Set<Source>> getNormalGUISources(Set<Sink> guiSinks, String VUISourceName, Set<SootMethod> onClickVUIs) throws IOException {
        Set<SootMethod> guiSourcesExpectedWithoutVUISource = new HashSet<>(guiSourcesExpected);
        guiSourcesExpectedWithoutVUISource.removeAll(onClickVUIs);
        List<Set<Source>> guiSources = new LinkedList<>();
        Set<Source> allGUISource = new HashSet<>();
        Set<Source> conflictGUISource = new HashSet<>();
        Set<Sink> realGUISinks = new HashSet<>();
        // no sinks found for VUI
        if (guiSinks.isEmpty()) {
            guiSources.add(allGUISource);
            guiSources.add(conflictGUISource);
            return guiSources;
        }

        Set<SootMethod> stopListeningMethods = getStopListeningMethods(VUISourceName);

        Set<SootMethod> processed = new HashSet<>();
        for (Sink sink: guiSinks) {
            // find corresponding real GUI sources for stmts
            SootMethod methodOfSink = sink.getDeclaringMethod();
            if(!callgraph.hasBrunch(methodOfSink)) {
                boolean containsStopListeningMethod = false;
                Iterator<Edge> it = callgraph.edgesOutOf(methodOfSink);
                while (it.hasNext()) {
                    Edge edge = it.next();
                    SootMethod tgt = edge.tgt();
                    if (stopListeningMethods.contains(tgt)) {
                        containsStopListeningMethod = true;
                        break;
                    }
                }
                if(containsStopListeningMethod)
                    continue;
            }
            if(processed.contains(methodOfSink))
                continue;
            processed.add(methodOfSink);

            boolean isResult = false;
            //if sootMethod is source, add it to guiSources
            for (SootMethod source: guiSourcesExpectedWithoutVUISource) {
                if(source.getSubSignature().equals(methodOfSink.getSubSignature())) {
                    isResult = true;
                    Source guiSource = new Source(methodOfSink);
                    List<Pair<ISourceSink, Integer>> sinkTrace = new LinkedList<>();
                    sinkTrace.add(new Pair<>(guiSource, 1));
                    boolean hasSynchronized = callgraph.hasSynchronized(guiSource.method());
                    if(!callgraph.hasBrunch(guiSource.method())) {
                        for(ISourceSink importFunc: callgraph.getImportantFuncsInMethod(guiSource)) {
                            if(hasSynchronized)
                                importFunc.setLocked(true);
                            sinkTrace.add(new Pair<>(importFunc, -1));
                        }
                    }
                    if(hasSynchronized)
                        sink.setLocked(true);
                    sinkTrace.add(new Pair<>(sink, -1));
                    guiSource.addSinkTrace(sinkTrace);
                    conflictGUISource.add(guiSource);
                    allGUISource.add(guiSource);
                    System.out.println("GUI sink trace: " + sinkTrace);
                    break;
                }
            }
            if(isResult)
                continue;
            Set<SootMethod> singRealSinkSet = new HashSet<>(Collections.singletonList(methodOfSink));
            Map<SootMethod, List<Pair<ISourceSink, Integer>>> onClickGUIToGUISinkTrace = new HashMap<>();
            for(List<Pair<ISourceSink, Integer>> guiSources0: callgraph.analyzeCallGraphForSourceSinks(false, guiSourcesExpectedWithoutVUISource, singRealSinkSet)) {
                ISourceSink guiSrc = guiSources0.get(0).getKey();
                if(guiSrc instanceof Source && !onClickVUIs.contains(guiSrc.method())) {
                    Source guiSource = (Source) guiSrc;
                    SootMethod onClickGUI = guiSource.method();
                    List<Pair<ISourceSink, Integer>> guiSinkTrace = onClickGUIToGUISinkTrace.get(onClickGUI);
                    if(guiSinkTrace != null) {
                        if(guiSources0.size() < guiSinkTrace.size())
                            onClickGUIToGUISinkTrace.put(onClickGUI, guiSources0);
                    } else
                        onClickGUIToGUISinkTrace.put(onClickGUI, guiSources0);
                }
            }
            for(SootMethod onClickGUI: onClickGUIToGUISinkTrace.keySet()) {
                List<Pair<ISourceSink, Integer>> sinkTrace = onClickGUIToGUISinkTrace.get(onClickGUI);
                Pair<ISourceSink, Integer> pair = sinkTrace.get(sinkTrace.size() - 1);
                String name = pair.getKey().method().getName();
                if(name.equals("post") || name.equals("postDelayed") || name.equals("runOnUiThread") || name.equals("execute") || name.equals("start"))
                    pair = sinkTrace.get(sinkTrace.size() - 2);
                boolean hasSynchronized = callgraph.hasSynchronized(pair.getKey().method());
                boolean isLocked = pair.getKey().isLocked();
                if(!callgraph.hasBrunch(pair.getKey().method())) {
                    for(ISourceSink importFunc: callgraph.getImportantFuncsInMethod(pair.getKey())) {
                        if(isLocked || hasSynchronized)
                            importFunc.setLocked(true);
                        sinkTrace.add(new Pair<>(importFunc, -1));
                    }
                }
                if(isLocked || hasSynchronized)
                    sink.setLocked(true);
                sinkTrace.add(new Pair<>(sink, -1));
                Source guiSource = (Source) (sinkTrace.get(0).getKey());
                if (!constainsStopListening(sinkTrace, stopListeningMethods)) {
                    guiSource.addSinkTrace(sinkTrace);
                    conflictGUISource.add(guiSource);
                    allGUISource.add(guiSource);
                    System.out.println("GUI sink trace: " + sinkTrace);
                } else {
                    allGUISource.add(guiSource);
                    System.out.println("GUI sink trace: " + sinkTrace + " contains method to stop VUI.");
                }
            }
        }
        guiSources.add(allGUISource);
        guiSources.add(conflictGUISource);
        return guiSources;
    }

    private Set<SootMethod> getStopListeningMethods(String VUISourceName) {
        Set<SootMethod> stopListeningMethods = new HashSet<>();
        SootMethod stopListening, startListening, cancel;
        switch (VUISourceName) {
            case "onResults":
            case "onPartialResults":  //google or huawei
                stopListening = Scene.v().grabMethod("<android.speech.SpeechRecognizer: void stopListening()>");
                startListening = Scene.v().grabMethod("<android.speech.SpeechRecognizer: void startListening(android.content.Intent)>");
                cancel = Scene.v().grabMethod("<android.speech.SpeechRecognizer: void cancel()>");
                if(stopListening == null || startListening == null || cancel == null) {
                    stopListening = Scene.v().grabMethod("<com.huawei.hiai.asr.AsrRecognizer: void stopListening()>");
                    startListening = Scene.v().grabMethod("<com.huawei.hiai.asr.AsrRecognizer: void startListening(android.content.Intent)>");
                    cancel = Scene.v().grabMethod("<com.huawei.hiai.asr.AsrRecognizer: void cancel()>");
                }
                stopListeningMethods.add(stopListening);
                stopListeningMethods.add(startListening);
                stopListeningMethods.add(cancel);
                break;
            case "onEvent": case "onAsrFinalResult"://baidu
                stopListening = Scene.v().grabMethod("<com.baidu.speech.EventManager: void send(java.lang.String,java.lang.String,byte[],int,int)>");
                stopListeningMethods.add(stopListening);
                break;
            case "onNuiEventCallback":  //alibaba
                stopListening = Scene.v().grabMethod("<com.alibaba.idst.nui.NativeNui: int stopDialog()>");
                startListening = Scene.v().grabMethod("<com.alibaba.idst.nui.NativeNui: int startDialog(com.alibaba.idst.nui.Constants$VadMode,java.lang.String)>");
                stopListeningMethods.add(stopListening);
                stopListeningMethods.add(startListening);
                break;
            case "onSuccess":
            case "onSegmentSuccess":
            case "onSliceSuccess":  //tencent
                stopListening = Scene.v().grabMethod("<com.tencent.aai.AAIClient: void stopAudioRecognize()>");
                if(stopListening == null)
                    stopListening = Scene.v().grabMethod("<com.tencent.aai.AAIClient: boolean stopAudioRecognize(int)>");
                startListening = Scene.v().grabMethod("<com.tencent.aai.AAIClient: void startAudioRecognize(com.tencent.aai.model.AudioRecognizeRequest,com.tencent.aai.listener.AudioRecognizeResultListener,com.tencent.aai.listener.AudioRecognizeStateListener,com.tencent.aai.listener.AudioRecognizeTimeoutListener,com.tencent.aai.model.AudioRecognizeConfiguration)>");
                if(startListening == null)
                    startListening = Scene.v().grabMethod("<com.tencent.aai.AAIClient: void startAudioRecognize(com.tencent.aai.model.AudioRecognizeRequest,com.tencent.aai.listener.AudioRecognizeResultListener,com.tencent.aai.listener.AudioRecognizeStateListener,com.tencent.aai.model.AudioRecognizeConfiguration)>");
                if(startListening == null)
                    startListening = Scene.v().grabMethod("<com.tencent.aai.AAIClient: void startAudioRecognize(com.tencent.aai.model.AudioRecognizeRequest,com.tencent.aai.listener.AudioRecognizeResultListener,com.tencent.aai.model.AudioRecognizeConfiguration)>");
                cancel = Scene.v().grabMethod("<com.tencent.aai.AAIClient: void cancelAudioRecognize()>");
                if(cancel == null)
                    cancel = Scene.v().grabMethod("<com.tencent.aai.AAIClient: boolean cancelAudioRecognize(int)>");
                stopListeningMethods.add(stopListening);
                stopListeningMethods.add(startListening);
                stopListeningMethods.add(cancel);
                break;
            case "toString":
                startListening = Scene.v().grabMethod("<com.microsoft.cognitiveservices.speech.SpeechRecognizer: java.util.concurrent.Future recognizeOnceAsync()>");
                stopListeningMethods.add(startListening);
                break;
            default:
                return stopListeningMethods;
        }
        return stopListeningMethods;
    }

    private boolean constainsStopListening(List<Pair<ISourceSink, Integer>> sinkTrace, Set<SootMethod> stopListeningMethods) {
        for(Pair<ISourceSink, Integer> pair: sinkTrace) {
            if(stopListeningMethods.contains(pair.getKey().method()))
                return true;
        }
        return false;
    }

    private Set<Stmt> getHiddenGUISources(Set<Sink> vuiSinks) {
        Set<Stmt> guiHiddenGUISources = new HashSet<>();
        for(Sink sink: vuiSinks) {
            Stmt stmt = sink.stmt();
            SootMethod method = myCallgraph.getMethodFromStmt(stmt);
            if(method == null)
                continue;
            if(stmt.toString().contains("android.widget.EditText: void setText")) {
                guiHiddenGUISources.add(stmt);
            } else if(method.getName().equals("setText")){
                SootClass sc = stmt.getInvokeExpr().getMethodRef().getDeclaringClass();
//                if(stmt.toString().contains("$r14.<com.lge.app1.view.BackPressEditText: void setText(java.lang.CharSequence)>($r5)"))
//                    System.out.println(sc);
                if(sc.isConcrete()) {
                    for (SootClass parentClass : Scene.v().getActiveHierarchy().getSuperclassesOf(sc)) {
                        if (parentClass.getName().equals("android.widget.EditText")) {
                            guiHiddenGUISources.add(stmt);
                            break;
                        }
                    }
                }
            }
        }
        return guiHiddenGUISources;
    }

    private Set<SootClass> findUsageOfOnClickMethod(SootMethod onClickMethod) {
        Set<SootClass> result = new HashSet<>();
        SootClass onClickClass = onClickMethod.getDeclaringClass();
        SootMethod initMethod = null;
        for(SootMethod sm: onClickClass.getMethods()) {
            if(sm.getName().equals("<init>")) {
                initMethod = sm;
                break;
            }
        }
        if(initMethod == null) {
            System.out.println("WARNING: no init method for class " + onClickClass);
        } else {
            for (Iterator<Edge> it = callgraph.edgesInto(initMethod); it.hasNext(); ) {
                Edge edge = it.next();
                result.add(edge.src().getDeclaringClass());
            }
            // remove added edges
//            if (result.isEmpty()) {
//                result.addAll(callgraph.addMethodsInReachableClasses(initMethod));
//            }
            // remove added edges
        }
        result.add(onClickClass);
        return result;
    }

    private Set<String> findLayoutFileOfClass(SootClass sootClass, SootMethod onClickMethod) {
        Set<String> layoutFileNames = new HashSet<>();
        if(sootClass == null)
            return layoutFileNames;
        if(sootClass.getName().equals("dummyMainClass")) {
//            String[] filePaths = widgetInfo.findFile(onClickMethod).split("/");
//            String fileName = filePaths[filePaths.length - 1];
            String fileName = widgetInfo.findFile(onClickMethod);
            if(!Objects.equals(fileName, ""))
                layoutFileNames.add(fileName);
        }
        else {
            Set<Integer> classIds = jimpleClass.getLayoutClasses().get(sootClass);
            for (Integer classId : classIds) {
                String layoutFileName = "";
                ARSCFileParser.AbstractResource resource = this.resources.findResource(classId);
                if (resource instanceof ARSCFileParser.StringResource) {
//                    String[] layoutFilePath = ((ARSCFileParser.StringResource) resource).getValue().split("/");
                    layoutFileName = ((ARSCFileParser.StringResource) resource).getValue();
                    layoutFileNames.add(layoutFileName);
                }
            }
        }
        if(layoutFileNames.isEmpty()) {
            Queue<Pair<SootMethod, Integer>> workList = new LinkedList<>();
            for(SootMethod method: sootClass.getMethods()) {
                String methodName = method.getName();
                if(methodName.equals("onCreate"))
                    workList.offer(new Pair<>(method, 0));
                if(methodName.equals("<init>"))
                    workList.offer(new Pair<>(method, 0));
                if(methodName.equals("onCreateView"))
                    workList.offer(new Pair<>(method, 0));
            }
            boolean findLayout = false;
            while(!workList.isEmpty() && !findLayout) {
                Pair<SootMethod, Integer> pair = workList.poll();
                SootMethod sootMethod = pair.getKey();
                int depth = pair.getValue();
                for (Iterator<Edge> it = callgraph.edgesOutOf(sootMethod); it.hasNext(); ) {
                    Edge edge = it.next();
                    Stmt stmt = edge.srcStmt();
                    SootMethod tgt = edge.tgt();
                    if (tgt != null) {
                        String tgtName = tgt.getName();
                        if(tgtName.equals("setContentView")) {
                            if (stmt.getInvokeExpr().getArg(0) instanceof IntConstant) {
                                int id = ((IntConstant) stmt.getInvokeExpr().getArg(0)).value;
                                layoutFileNames.add(String.valueOf(id));
                            } else {
                                layoutFileNames.add(sootClass.getName());
                            }
                            findLayout = true;
                            break;
                        } else if (tgtName.equals("inflate")){
                            for(int index = 0; index < tgt.getParameterCount(); ++index) {
                                if(tgt.getParameterType(index) instanceof IntType) {
                                    Value arg = stmt.getInvokeExpr().getArg(index);
                                    if(arg instanceof IntConstant) {
                                        int id = ((IntConstant) arg).value;
                                        layoutFileNames.add(String.valueOf(id));
                                        findLayout = true;
                                    } else if(arg instanceof JimpleLocal) {
                                        int id = myCallgraph.getDefOfIntValue(sootMethod, stmt, arg);
                                        if(id != -1)
                                            layoutFileNames.add(String.valueOf(id));
                                        findLayout = true;
                                    }
                                    break;
                                }
                            }
                            if(findLayout)
                                break;
                        } else {
                            if(depth + 1 <= 1)
                                workList.offer(new Pair<>(tgt, depth + 1));
                        }
                    }
                }
            }
        }
        return layoutFileNames;
    }

    private void recordStep1Results(boolean hasRace1, JSONArray array) throws IOException, BiffException, WriteException {
        if(printResult) {
            File file = new File(outputDir, apkFileName + "_step1.json");
            if (file.exists())
                file.delete();
            file.createNewFile();
            String guiWidgetPath = file.getPath();
            writeToFiles(guiWidgetPath, array.toString());
        }

//        File file = new File(outputDir, "result.xls");
//        FileInputStream in = new FileInputStream(file);
//        Workbook book = Workbook.getWorkbook(in);
//        WritableWorkbook wbook = Workbook.createWorkbook(file, book);
//        WritableSheet sh = wbook.getSheet(0);
//        int length = sh.getRows();
//
//        String result = "true";

        if(hasRace1) {
            File file1 = new File(outputDir, "apksWithRace(step1).txt");
            if(!file1.exists())
                file1.createNewFile();
            String apkFileNameAfterStep1 = file1.getPath();
            writeToFiles(apkFileNameAfterStep1, apkFileName);
//            result = "true";
        } else {
            File file2 = new File(outputDir, "apksWithoutRace(step1).txt");
            if(!file2.exists())
                file2.createNewFile();
            String apkFileNameAfterStep1 = file2.getPath();
            writeToFiles(apkFileNameAfterStep1, apkFileName);
//            result = "false";
        }
//        Label label = new Label(2, length - 1, result);
//        sh.addCell(label);
//        wbook.write();
//        wbook.close();
//        book.close();
    }

    private void writeToFiles(String fileName, String line) throws IOException {
        File file = new File(fileName);
        if(!file.exists())
            file.createNewFile();
        FileWriter fw = new FileWriter(fileName, true);
        PrintWriter pw = new PrintWriter(fw);
        pw.println(line);
        pw.flush();
        pw.close();
        fw.close();
    }

    private boolean isFragmentClass(SootClass sc) {
        for(SootClass parentClass: Scene.v().getActiveHierarchy().getSuperclassesOf(sc)) {
            if(parentClass.getName().equals("androidx.fragment.app.Fragment"))
                return true;
        }
        return false;
    }

}
