package src.callGraphAnalyze.flowdroid;

import soot.jimple.infoflow.Infoflow;
import soot.jimple.infoflow.android.data.AndroidMemoryManager;
import soot.jimple.infoflow.android.entryPointCreators.components.ComponentEntryPointCollection;
import soot.jimple.infoflow.cfg.BiDirICFGFactory;
import soot.jimple.infoflow.data.Abstraction;
import soot.jimple.infoflow.data.FlowDroidMemoryManager;
import soot.jimple.infoflow.handlers.PostAnalysisHandler;
import soot.jimple.infoflow.handlers.ResultsAvailableHandler;
import soot.jimple.infoflow.memory.FlowDroidMemoryWatcher;
import soot.jimple.infoflow.results.InfoflowPerformanceData;
import soot.jimple.infoflow.solver.cfg.IInfoflowCFG;
import soot.jimple.infoflow.solver.memory.IMemoryManager;
import soot.jimple.infoflow.solver.memory.IMemoryManagerFactory;
import soot.jimple.infoflow.sourcesSinks.manager.ISourceSinkManager;
import src.callGraphAnalyze.flowdroid.myLayoutFileParser;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.xml.sax.SAXException;
import org.xmlpull.v1.XmlPullParserException;
import soot.*;
import soot.Main;
import soot.jimple.infoflow.AbstractInfoflow;
import soot.jimple.infoflow.InfoflowConfiguration;
import soot.jimple.infoflow.android.InfoflowAndroidConfiguration;
import soot.jimple.infoflow.android.SetupApplication;
import soot.jimple.infoflow.android.callbacks.AbstractCallbackAnalyzer;
import soot.jimple.infoflow.android.callbacks.AndroidCallbackDefinition;
import soot.jimple.infoflow.android.callbacks.DefaultCallbackAnalyzer;
import soot.jimple.infoflow.android.callbacks.FastCallbackAnalyzer;
import soot.jimple.infoflow.android.callbacks.filters.AlienHostComponentFilter;
import soot.jimple.infoflow.android.callbacks.filters.ApplicationCallbackFilter;
import soot.jimple.infoflow.android.callbacks.filters.UnreachableConstructorFilter;
import soot.jimple.infoflow.android.callbacks.xml.CollectedCallbacks;
import soot.jimple.infoflow.android.callbacks.xml.CollectedCallbacksSerializer;
import soot.jimple.infoflow.android.data.parsers.PermissionMethodParser;
import soot.jimple.infoflow.android.entryPointCreators.AndroidEntryPointCreator;
import soot.jimple.infoflow.android.resources.ARSCFileParser;
import soot.jimple.infoflow.android.resources.controls.AndroidLayoutControl;
import soot.jimple.infoflow.android.source.ConfigurationBasedCategoryFilter;
import soot.jimple.infoflow.android.source.UnsupportedSourceSinkFormatException;
import soot.jimple.infoflow.android.source.parsers.xml.XMLSourceSinkParser;
import soot.jimple.infoflow.cfg.LibraryClassPatcher;
import soot.jimple.infoflow.ipc.IIPCManager;
import soot.jimple.infoflow.memory.IMemoryBoundedSolver;
import soot.jimple.infoflow.results.InfoflowResults;
import soot.jimple.infoflow.rifl.RIFLSourceSinkDefinitionProvider;
import soot.jimple.infoflow.sourcesSinks.definitions.ISourceSinkDefinition;
import soot.jimple.infoflow.sourcesSinks.definitions.ISourceSinkDefinitionProvider;
import soot.jimple.infoflow.util.SystemClassHandler;
import soot.jimple.toolkits.callgraph.CallGraph;
import soot.options.Options;
import soot.util.HashMultiMap;
import soot.util.MultiMap;

import java.io.File;
import java.io.IOException;
import java.io.PrintWriter;
import java.io.StringWriter;
import java.util.*;

public class MySetupApplication extends SetupApplication {

    private Logger logger;
    private MultiMap<SootClass, AndroidCallbackDefinition> xmlBasedCallbackMethods = new HashMultiMap();
    private MultiMap<SootClass, AndroidCallbackDefinition> otherCallbackMethods = new HashMultiMap<>();
    private MultiMap<AndroidCallbackDefinition, String> xmlCallbackToWidget = new HashMultiMap<>();
    private Map<AndroidCallbackDefinition, String> xmlCallbackToFile = new HashMap<>();
    private AbstractCallbackAnalyzer jimpleClass = null;

    private IInfoflowCFG iCfg;

    protected myInPlaceInfoflow infoflow;

    public MySetupApplication(InfoflowAndroidConfiguration config) {
        super(config);
        this.logger = LoggerFactory.getLogger(this.getClass());
    }

    public MySetupApplication(String androidJar, String apkFileLocation) {
        super(androidJar, apkFileLocation);
        this.logger = LoggerFactory.getLogger(this.getClass());
    }

    public MySetupApplication(String androidJar, String apkFileLocation, IIPCManager ipcManager) {
        super(androidJar, apkFileLocation, ipcManager);
        this.logger = LoggerFactory.getLogger(this.getClass());
    }

    public MySetupApplication(InfoflowAndroidConfiguration config, IIPCManager ipcManager) {
        super(config, ipcManager);
        this.logger = LoggerFactory.getLogger(this.getClass());
    }

    public MultiMap<SootClass, AndroidCallbackDefinition> getXmlBasedCallbackMethods(){
        if(this.callbackMethods.isEmpty())
            constructCallgraph();
        return this.xmlBasedCallbackMethods;
    }

    public MultiMap<SootClass, AndroidCallbackDefinition> getOtherCallbackMethods(){
        if(this.callbackMethods.isEmpty())
            constructCallgraph();
        return this.otherCallbackMethods;
    }

    public MultiMap<SootClass, AndroidCallbackDefinition> getCallbackMethods(){
        if(this.callbackMethods.isEmpty())
            constructCallgraph();
        return this.callbackMethods;
    }

    public MultiMap<AndroidCallbackDefinition, String> getXmlCallbackToWidget() {
        return this.xmlCallbackToWidget;
    }

    public Map<AndroidCallbackDefinition, String> getXmlCallbackToFile() { return this.xmlCallbackToFile; }

    public AbstractCallbackAnalyzer getJimpleClass() { return this.jimpleClass; }

    public ARSCFileParser getResources() { return this.resources; }

    public CallGraph getCallGraph() throws IOException, XmlPullParserException {
        if(!(Scene.v().hasCallGraph())){
            constructCallgraph();
            // add for iCfg
            this.infoflow = null;
            // add for iCfg
        }
        CallGraph callGraph = Scene.v().getCallGraph();
        return callGraph;
    }

    // add for iCfg
    public IInfoflowCFG getiCfg() {
        if(!(Scene.v().hasCallGraph())) {
            constructCallgraph();
        }
        IInfoflowCFG iCfg = this.infoflow.getiCfg();
        return iCfg;

    }
    // add for iCfg

    public void constructCallgraph() {
        boolean oldRunAnalysis = this.config.isTaintAnalysisEnabled();

        try {
            this.config.setTaintAnalysisEnabled(false);
            if (!this.config.getSootIntegrationMode().needsToBuildCallgraph()) {
                throw new RuntimeException("FlowDroid is configured to use an existing callgraph. Please change this option before trying to create a new callgraph.");
            }

            this.runInfoflow();
        } catch (RuntimeException | IOException var6) {
            this.logger.error("Could not construct callgraph", var6);
            try {
                throw var6;
            } catch (IOException e) {
                e.printStackTrace();
            }
        } finally {
            this.config.setTaintAnalysisEnabled(oldRunAnalysis);
        }
    }

    public InfoflowResults runInfoflow() throws IOException{
        String sourceSinkFile = this.config.getAnalysisFileConfig().getSourceSinkFile();
        if (sourceSinkFile != null && !sourceSinkFile.isEmpty()) {
            String fileExtension = sourceSinkFile.substring(sourceSinkFile.lastIndexOf("."));
            fileExtension = fileExtension.toLowerCase();
            Object parser = null;

            try {
                if (fileExtension.equals(".xml")) {
                    parser = XMLSourceSinkParser.fromFile(sourceSinkFile, new ConfigurationBasedCategoryFilter(this.config.getSourceSinkConfig()));
                } else if (fileExtension.equals(".txt")) {
                    parser = PermissionMethodParser.fromFile(sourceSinkFile);
                } else {
                    if (!fileExtension.equals(".rifl")) {
                        throw new UnsupportedSourceSinkFormatException("The Inputfile isn't a .txt or .xml file.");
                    }

                    parser = new RIFLSourceSinkDefinitionProvider(sourceSinkFile);
                }
            } catch (SAXException var5) {
                throw new IOException("Could not read XML file", var5);
            }

            return this.runInfoflow((ISourceSinkDefinitionProvider)parser);
        } else {
            throw new RuntimeException("No source/sink file specified for the data flow analysis");
        }
    }

    public InfoflowResults runInfoflow(ISourceSinkDefinitionProvider sourcesAndSinks) {
        this.collectedSources = this.config.getLogSourcesAndSinks() ? new HashSet() : null;
        this.collectedSinks = this.config.getLogSourcesAndSinks() ? new HashSet() : null;
        this.sourceSinkProvider = sourcesAndSinks;
        this.infoflow = null;
        if (this.config.getSourceSinkConfig().getEnableLifecycleSources() && this.config.getIccConfig().isIccEnabled()) {
            this.logger.warn("ICC model specified, automatically disabling lifecycle sources");
            this.config.getSourceSinkConfig().setEnableLifecycleSources(false);
        }

        if (this.config.getSootIntegrationMode() == InfoflowConfiguration.SootIntegrationMode.CreateNewInstance) {
            G.reset();
            this.initializeSoot();
        }

        try {
            this.parseAppResources();
        } catch (XmlPullParserException | IOException var5) {
            this.logger.error("Parse app resource failed", var5);
            throw new RuntimeException("Parse app resource failed", var5);
        }

        if (this.entrypoints != null && !this.entrypoints.isEmpty()) {
            this.processEntryPoint(sourcesAndSinks);
            // delete for iCfg
//            this.infoflow = null;
            // delete for iCfg
        } else {
            this.logger.warn("No entry points");
        }
        return null;
    }

    protected void processEntryPoint(ISourceSinkDefinitionProvider sourcesAndSinks) {
        long callbackDuration = System.nanoTime();

        try {
            this.calculateCallbacks(sourcesAndSinks);
        } catch (XmlPullParserException | IOException var14) {
            this.logger.error("Callgraph construction failed: " + var14.getMessage(), var14);
            throw new RuntimeException("Callgraph construction failed", var14);
        }

        callbackDuration = Math.round((double)(System.nanoTime() - callbackDuration) / 1.0E9D);
        this.logger.info(String.format("Collecting callbacks and building a callgraph took %d seconds", (int)callbackDuration));
        Set<? extends ISourceSinkDefinition> sources = this.getSources();
        Set<? extends ISourceSinkDefinition> sinks = this.getSinks();
        String apkFileLocation = this.config.getAnalysisFileConfig().getTargetAPKFile();
        this.logger.info("Running data flow analysis on {} with {} sources and {} sinks...", apkFileLocation, sources == null ? 0 : sources.size(), sinks == null ? 0 : sinks.size());
        // add for iCfg
        this.infoflow = this.createInfoflow();
//        this.infoflow.addResultsAvailableHandler(resultAggregator);
        this.infoflow.runAnalysis(this.sourceSinkManager, this.entryPointCreator.getGeneratedMainMethod());
        // add for iCfg

    }

    private void calculateCallbacks(ISourceSinkDefinitionProvider sourcesAndSinks) throws IOException, XmlPullParserException {
        this.calculateCallbacks(sourcesAndSinks, (SootClass)null);
    }

    private void calculateCallbacks(ISourceSinkDefinitionProvider sourcesAndSinks, SootClass entryPoint) throws IOException, XmlPullParserException {
        myLayoutFileParser lfp = null;
        InfoflowAndroidConfiguration.CallbackConfiguration callbackConfig = this.config.getCallbackConfig();
        if (callbackConfig.getEnableCallbacks()) {
            String callbackFile = callbackConfig.getCallbacksFile();
            if (callbackFile != null && !callbackFile.isEmpty()) {
                File cbFile = new File(callbackFile);
                if (cbFile.exists()) {
                    CollectedCallbacks callbacks = CollectedCallbacksSerializer.deserialize(callbackConfig);
                    if (callbacks != null) {
                        this.entrypoints = callbacks.getEntryPoints();
                        this.fragmentClasses = callbacks.getFragmentClasses();
                        this.callbackMethods = callbacks.getCallbackMethods();
                        this.createMainMethod(entryPoint);
                        this.constructCallgraphInternal();
                        this.createSourceSinkProvider(entryPoint, lfp);
                        return;
                    }
                }
            }

            if (this.callbackClasses != null && this.callbackClasses.isEmpty()) {
                this.logger.warn("Callback definition file is empty, disabling callbacks");
            } else {
                lfp = this.createLayoutFileParser();
                switch(callbackConfig.getCallbackAnalyzer()) {
                    case Fast:
                        this.calculateCallbackMethodsFast(lfp, entryPoint);
                        break;
                    case Default:
                        this.calculateCallbackMethods(lfp, entryPoint);
                        break;
                    default:
                        throw new RuntimeException("Unknown callback analyzer");
                }
            }
        } else if (this.config.getSootIntegrationMode().needsToBuildCallgraph()) {
            this.createMainMethod(null);
            this.constructCallgraphInternal();
        }
        this.logger.info("Entry point calculation done.");
        this.createSourceSinkProvider(null, lfp);
    }

    protected myLayoutFileParser createLayoutFileParser() {
        return new myLayoutFileParser(this.manifest.getPackageName(), this.resources);
    }

    private void calculateCallbackMethodsFast(myLayoutFileParser lfp, SootClass component) throws IOException {
        this.releaseCallgraph();
        this.createMainMethod(component);
        this.constructCallgraphInternal();
        Set<SootClass> entryPointClasses = this.entrypoints;
        AbstractCallbackAnalyzer jimpleClass = this.callbackClasses == null ? new FastCallbackAnalyzer(this.config, entryPointClasses, this.callbackFile) : new FastCallbackAnalyzer(this.config, entryPointClasses, this.callbackClasses);
        if (this.valueProvider != null) {
            jimpleClass.setValueProvider(this.valueProvider);
        }

        jimpleClass.collectCallbackMethods();
        this.callbackMethods.putAll(jimpleClass.getCallbackMethods());
        this.entrypoints.addAll(jimpleClass.getDynamicManifestComponents());
        lfp.parseLayoutFileDirect(this.config.getAnalysisFileConfig().getTargetAPKFile());
        this.collectXmlBasedCallbackMethods(lfp, jimpleClass);
        this.releaseCallgraph();
        this.createMainMethod(component);
        this.constructCallgraphInternal();
        this.jimpleClass = jimpleClass;
    }

    private void calculateCallbackMethods(myLayoutFileParser lfp, SootClass component) throws IOException {
        InfoflowAndroidConfiguration.CallbackConfiguration callbackConfig = this.config.getCallbackConfig();
        if (this.config.getSootIntegrationMode().needsToBuildCallgraph()) {
            this.releaseCallgraph();
        }

        PackManager.v().getPack("wjtp").remove("wjtp.lfp");
        PackManager.v().getPack("wjtp").remove("wjtp.ajc");
        Set<SootClass> entryPointClasses = this.entrypoints;
        AbstractCallbackAnalyzer jimpleClass = this.callbackClasses == null ? new DefaultCallbackAnalyzer(this.config, entryPointClasses, this.callbackMethods, this.callbackFile) : new DefaultCallbackAnalyzer(this.config, entryPointClasses, this.callbackMethods, this.callbackClasses);
        if (this.valueProvider != null) {
            jimpleClass.setValueProvider(this.valueProvider);
        }

        jimpleClass.addCallbackFilter(new AlienHostComponentFilter(this.entrypoints));
        jimpleClass.addCallbackFilter(new ApplicationCallbackFilter(this.entrypoints));
        jimpleClass.addCallbackFilter(new UnreachableConstructorFilter());
        jimpleClass.collectCallbackMethods();
        lfp.parseLayoutFile(this.config.getAnalysisFileConfig().getTargetAPKFile());

        boolean abortedEarly;
        try {
            int depthIdx = 0;
            abortedEarly = true;
            boolean isInitial = true;

            while(abortedEarly) {
                abortedEarly = false;
                if (jimpleClass instanceof IMemoryBoundedSolver && ((IMemoryBoundedSolver)jimpleClass).isKilled()) {
                    break;
                }

                this.createMainMethod(component);
                int numPrevEdges = 0;
                if (Scene.v().hasCallGraph()) {
                    numPrevEdges = Scene.v().getCallGraph().size();
                }

                if (jimpleClass instanceof IMemoryBoundedSolver && ((IMemoryBoundedSolver)jimpleClass).isKilled()) {
                    this.logger.warn("Callback calculation aborted due to timeout");
                    break;
                }

                if (!isInitial) {
                    this.releaseCallgraph();
                    PackManager.v().getPack("wjtp").remove("wjtp.lfp");
                }

                isInitial = false;
                this.constructCallgraphInternal();
                if (!Scene.v().hasCallGraph()) {
                    throw new RuntimeException("No callgraph in Scene even after creating one. That's very sad and should never happen.");
                }

                lfp.parseLayoutFileDirect(this.config.getAnalysisFileConfig().getTargetAPKFile());
                PackManager.v().getPack("wjtp").apply();
                if (jimpleClass instanceof IMemoryBoundedSolver && ((IMemoryBoundedSolver)jimpleClass).isKilled()) {
                    this.logger.warn("Aborted callback collection because of low memory");
                    break;
                }

                if (numPrevEdges < Scene.v().getCallGraph().size()) {
                    logger.info(numPrevEdges + " < " + Scene.v().getCallGraph().size());
                    abortedEarly = true;
                }

                if (this.callbackMethods.putAll(jimpleClass.getCallbackMethods())) {
                    logger.info("new callbacks");
                    abortedEarly = true;
                }

                if (this.entrypoints.addAll(jimpleClass.getDynamicManifestComponents())) {
                    logger.info("new manifest components");
                    abortedEarly = true;
                }

                if (this.collectXmlBasedCallbackMethods(lfp, jimpleClass)) {
                    logger.info("new xml based callback methods");
                    abortedEarly = true;
                }

                ++depthIdx;
                if (depthIdx >= 5 || this.config.getSootIntegrationMode() == InfoflowConfiguration.SootIntegrationMode.UseExistingCallgraph) {
                    break;
                }
            }
        } catch (Exception var17) {
            this.logger.error("Could not calculate callback methods", var17);
            throw var17;
        }

        if (callbackConfig.isSerializeCallbacks()) {
            CollectedCallbacks callbacks = new CollectedCallbacks(entryPointClasses, this.callbackMethods, this.fragmentClasses);
            CollectedCallbacksSerializer.serialize(callbacks, callbackConfig);
        }
        this.jimpleClass = jimpleClass;
    }

    ////////////////////////////////
    private Set<String> callbackToWidget(myLayoutFileParser lfp, String layoutFileName, String methodName) {
        MultiMap<String, String> handerAttribute = lfp.getHanderAttribute();
        Set<String> ids = handerAttribute.get(methodName);
        return ids;
    }
    ////////////////////////////////

    private boolean collectXmlBasedCallbackMethods(myLayoutFileParser lfp, AbstractCallbackAnalyzer jimpleClass) {
        SootMethod smViewOnClick = Scene.v()
                .grabMethod("<android.view.View$OnClickListener: void onClick(android.view.View)>");

        // Collect the XML-based callback methods
        boolean hasNewCallback = false;
        for (final SootClass callbackClass : jimpleClass.getLayoutClasses().keySet()) {
            if (jimpleClass.isExcludedEntryPoint(callbackClass))
                continue;

            Set<Integer> classIds = jimpleClass.getLayoutClasses().get(callbackClass);
            for (Integer classId : classIds) {
                ARSCFileParser.AbstractResource resource = this.resources.findResource(classId);
                if (resource instanceof ARSCFileParser.StringResource) {
                    final String layoutFileName = ((ARSCFileParser.StringResource) resource).getValue();

                    // Add the callback methods for the given class
                    Set<String> callbackMethods = lfp.getCallbackMethods().get(layoutFileName);
                    if (callbackMethods != null) {
                        for (String methodName : callbackMethods) {
                            final String subSig = "void " + methodName + "(android.view.View)";

                            // The callback may be declared directly in the
                            // class or in one of the superclasses
                            SootClass currentClass = callbackClass;
                            while (true) {
                                SootMethod callbackMethod = currentClass.getMethodUnsafe(subSig);
                                if (callbackMethod != null) {
                                    AndroidCallbackDefinition androidCallbackDefinition = new AndroidCallbackDefinition(callbackMethod, smViewOnClick, AndroidCallbackDefinition.CallbackType.Widget);
                                    if (this.callbackMethods.put(callbackClass, androidCallbackDefinition)) {
                                        this.xmlBasedCallbackMethods.put(callbackClass, androidCallbackDefinition);
                                        /////////////////////////////////////
                                        Set<String> ids = callbackToWidget(lfp, layoutFileName, methodName);
                                        this.xmlCallbackToWidget.putAll(androidCallbackDefinition, ids);
                                        this.xmlCallbackToFile.put(androidCallbackDefinition, layoutFileName);
                                        /////////////////////////////////////
                                        hasNewCallback = true;
                                    }
                                    break;
                                }

                                SootClass sclass = currentClass.getSuperclassUnsafe();
                                if (sclass == null) {
                                    logger.error(String.format("Callback method %s not found in class %s", methodName,
                                            callbackClass.getName()));
                                    break;
                                }
                                currentClass = sclass;
                            }
                        }
                    }

                    // Add the fragments for this class
                    Set<SootClass> fragments = lfp.getFragments().get(layoutFileName);
                    if (fragments != null) {
                        for (SootClass fragment : fragments) {
                            if (fragmentClasses.put(callbackClass, fragment))
                                hasNewCallback = true;
                        }
                    }

                    // For user-defined views, we need to emulate their
                    // callbacks
                    Set<AndroidLayoutControl> controls = lfp.getUserControls().get(layoutFileName);
                    if (controls != null) {
                        for (AndroidLayoutControl lc : controls) {
                            if (!SystemClassHandler.v().isClassInSystemPackage(lc.getViewClass().getName()))
                                hasNewCallback |= registerCallbackMethodsForView(callbackClass, lc);
                        }
                    }
                } else
                    logger.error("Unexpected resource type for layout class");
            }
        }

        // Collect the fragments, merge the fragments created in the code with
        // those declared in Xml files
        if (fragmentClasses.putAll(jimpleClass.getFragmentClasses())) // Fragments
            // declared
            // in
            // code
            hasNewCallback = true;

        return hasNewCallback;
    }

    private boolean registerCallbackMethodsForView(SootClass callbackClass, AndroidLayoutControl lc) {
        // Ignore system classes
        if (SystemClassHandler.v().isClassInSystemPackage(callbackClass.getName()))
            return false;

        // Get common Android classes
        if (scView == null)
            scView = Scene.v().getSootClass("android.view.View");

        // Check whether the current class is actually a view
        if (!Scene.v().getOrMakeFastHierarchy().canStoreType(lc.getViewClass().getType(), scView.getType()))
            return false;

        // There are also some classes that implement interesting callback
        // methods.
        // We model this as follows: Whenever the user overwrites a method in an
        // Android OS class, we treat it as a potential callback.
        SootClass sc = lc.getViewClass();
        Map<String, SootMethod> systemMethods = new HashMap<>(10000);
        for (SootClass parentClass : Scene.v().getActiveHierarchy().getSuperclassesOf(sc)) {
            if (parentClass.getName().startsWith("android."))
                for (SootMethod sm : parentClass.getMethods())
                    if (!sm.isConstructor())
                        systemMethods.put(sm.getSubSignature(), sm);
        }

        boolean changed = false;
        // Scan for methods that overwrite parent class methods
        for (SootMethod sm : sc.getMethods()) {
            if (!sm.isConstructor()) {
                SootMethod parentMethod = systemMethods.get(sm.getSubSignature());
                if (parentMethod != null) {
                    // This is a real callback method
                    if(this.callbackMethods.put(callbackClass, new AndroidCallbackDefinition(sm, parentMethod, AndroidCallbackDefinition.CallbackType.Widget))) {
                        changed = true;
                        this.otherCallbackMethods.put(callbackClass, new AndroidCallbackDefinition(sm, parentMethod, AndroidCallbackDefinition.CallbackType.Widget));
                    }
                }
            }
        }
        return changed;
    }

    private void createMainMethod(SootClass component) {
        if (this.config.getSootIntegrationMode() != InfoflowConfiguration.SootIntegrationMode.UseExistingCallgraph) {
            this.entryPointCreator = this.createEntryPointCreator(component);
            SootMethod dummyMainMethod = this.entryPointCreator.createDummyMain();
            Scene.v().setEntryPoints(Collections.singletonList(dummyMainMethod));
            if (!dummyMainMethod.getDeclaringClass().isInScene()) {
                Scene.v().addClass(dummyMainMethod.getDeclaringClass());
            }

            dummyMainMethod.getDeclaringClass().setApplicationClass();
        }
    }

    private AndroidEntryPointCreator createEntryPointCreator(SootClass component) {
        Set<SootClass> components = this.entrypoints;
        if (this.entryPointCreator == null) {
            this.entryPointCreator = this.createEntryPointCreator(components);
        } else {
            this.entryPointCreator.removeGeneratedMethods(false);
            this.entryPointCreator.reset();
        }

        MultiMap<SootClass, SootMethod> callbackMethodSigs = new HashMultiMap();
        Iterator var4;
        SootClass sc;
        Set callbackDefs;
        Iterator var7;
        AndroidCallbackDefinition cd;
        if (component == null) {
            var4 = this.callbackMethods.keySet().iterator();

            label51:
            while(true) {
                do {
                    if (!var4.hasNext()) {
                        break label51;
                    }

                    sc = (SootClass)var4.next();
                    callbackDefs = this.callbackMethods.get(sc);
                } while(callbackDefs == null);

                var7 = callbackDefs.iterator();

                while(var7.hasNext()) {
                    cd = (AndroidCallbackDefinition)var7.next();
                    callbackMethodSigs.put(sc, cd.getTargetMethod());
                }
            }
        } else {
            var4 = components.iterator();

            label37:
            while(true) {
                do {
                    if (!var4.hasNext()) {
                        break label37;
                    }

                    sc = (SootClass)var4.next();
                    callbackDefs = this.callbackMethods.get(sc);
                } while(callbackDefs == null);

                var7 = callbackDefs.iterator();

                while(var7.hasNext()) {
                    cd = (AndroidCallbackDefinition)var7.next();
                    callbackMethodSigs.put(sc, cd.getTargetMethod());
                }
            }
        }

        this.entryPointCreator.setCallbackFunctions(callbackMethodSigs);
        this.entryPointCreator.setFragments(this.fragmentClasses);
        this.entryPointCreator.setComponents(components);
        return this.entryPointCreator;
    }

    private void initializeSoot() {
        this.logger.info("Initializing Soot...");
        String androidJar = this.config.getAnalysisFileConfig().getAndroidPlatformDir();
        String apkFileLocation = this.config.getAnalysisFileConfig().getTargetAPKFile();
        G.reset();
        Options.v().set_no_bodies_for_excluded(true);
        Options.v().set_allow_phantom_refs(true);
        if (this.config.getWriteOutputFiles()) {
            Options.v().set_output_format(1);
        } else {
            Options.v().set_output_format(12);
        }

        Options.v().set_whole_program(true);
        Options.v().set_process_dir(Collections.singletonList(apkFileLocation));
        if (this.forceAndroidJar) {
            Options.v().set_force_android_jar(androidJar);
        } else {
            Options.v().set_android_jars(androidJar);
        }

        Options.v().set_src_prec(6);
        Options.v().set_keep_offset(false);
        Options.v().set_keep_line_number(this.config.getEnableLineNumbers());
        Options.v().set_throw_analysis(3);
        Options.v().set_process_multiple_dex(this.config.getMergeDexFiles());
        Options.v().set_ignore_resolution_errors(true);
        if (this.config.getEnableOriginalNames()) {
            Options.v().setPhaseOption("jb", "use-original-names:true");
        }

        if (this.sootConfig != null) {
            this.sootConfig.setSootOptions(Options.v(), this.config);
        }

        Options.v().set_soot_classpath(this.getClasspath());
        Main.v().autoSetOptions();
        this.configureCallgraph();
        this.logger.info("Loading dex files...");
        Scene.v().loadNecessaryClasses();
        PackManager.v().getPack("wjpp").apply();
        LibraryClassPatcher patcher = this.getLibraryClassPatcher();
        patcher.patchLibraries();
    }

    protected void configureCallgraph() {
        switch(this.config.getCallgraphAlgorithm()) {
            case AutomaticSelection:
            case SPARK:
                Options.v().setPhaseOption("cg.spark", "on");
                break;
            case GEOM:
                Options.v().setPhaseOption("cg.spark", "on");
                AbstractInfoflow.setGeomPtaSpecificOptions();
                break;
            case CHA:
                Options.v().setPhaseOption("cg.cha", "on");
                break;
            case RTA:
                Options.v().setPhaseOption("cg.spark", "on");
                Options.v().setPhaseOption("cg.spark", "rta:true");
                Options.v().setPhaseOption("cg.spark", "on-fly-cg:false");
                break;
            case VTA:
                Options.v().setPhaseOption("cg.spark", "on");
                Options.v().setPhaseOption("cg.spark", "vta:true");
                break;
            default:
                throw new RuntimeException("Invalid callgraph algorithm");
        }

        if (this.config.getEnableReflection()) {
            Options.v().setPhaseOption("cg", "types-for-invoke:true");
        }

    }

    private String getClasspath() {
        String androidJar = this.config.getAnalysisFileConfig().getAndroidPlatformDir();
        String apkFileLocation = this.config.getAnalysisFileConfig().getTargetAPKFile();
        String additionalClasspath = this.config.getAnalysisFileConfig().getAdditionalClasspath();
        String classpath = this.forceAndroidJar ? androidJar : Scene.v().getAndroidJarPath(androidJar, apkFileLocation);
        if (additionalClasspath != null && !additionalClasspath.isEmpty()) {
            classpath = classpath + File.pathSeparator + additionalClasspath;
        }

        this.logger.debug("soot classpath: " + classpath);
        return classpath;
    }

    public String getApkId() throws XmlPullParserException, IOException {
        if(this.manifest == null) {
            File targetAPK = new File(this.config.getAnalysisFileConfig().getTargetAPKFile());
            this.manifest = this.createManifestParser(targetAPK);
        }
        return this.manifest.getPackageName();
    }

    // add for iCfg
    private myInPlaceInfoflow createInfoflow() {
        if (this.config.getSootIntegrationMode().needsToBuildCallgraph()) {
            if (this.entryPointCreator == null) {
                throw new RuntimeException("No entry point available");
            }

            if (this.entryPointCreator.getComponentToEntryPointInfo() == null) {
                throw new RuntimeException("No information about component entry points available");
            }
        }

        Collection<SootMethod> lifecycleMethods = Collections.emptySet();
        if (this.entryPointCreator != null) {
            ComponentEntryPointCollection entryPoints = this.entryPointCreator.getComponentToEntryPointInfo();
            if (entryPoints != null) {
                lifecycleMethods = entryPoints.getLifecycleMethods();
            }
        }

        String androidJar = this.config.getAnalysisFileConfig().getAndroidPlatformDir();
        myInPlaceInfoflow info = new myInPlaceInfoflow(androidJar, this.forceAndroidJar, this.cfgFactory, lifecycleMethods);

        if (this.ipcManager != null) {
            info.setIPCManager(this.ipcManager);
        }

        info.setConfig(this.config);
        info.setSootConfig(this.sootConfig);
        info.setTaintWrapper(this.taintWrapper);
        info.setTaintPropagationHandler(this.taintPropagationHandler);
        info.setBackwardsPropagationHandler(this.backwardsPropagationHandler);
        info.setMemoryManagerFactory(new IMemoryManagerFactory() {
            public IMemoryManager<Abstraction, Unit> getMemoryManager(boolean tracingEnabled, FlowDroidMemoryManager.PathDataErasureMode erasePathData) {
                return new AndroidMemoryManager(tracingEnabled, erasePathData, MySetupApplication.this.entrypoints);
            }
        });
        info.setMemoryManagerFactory((IMemoryManagerFactory)null);
        info.setPostProcessors(Collections.singleton(new PostAnalysisHandler() {
            public InfoflowResults onResultsAvailable(InfoflowResults results, IInfoflowCFG cfg) {
                InfoflowAndroidConfiguration.IccConfiguration iccConfig = MySetupApplication.this.config.getIccConfig();
                if (iccConfig.isIccResultsPurifyEnabled()) {
                }

                return results;
            }
        }));
        return info;
    }

    protected class myInPlaceInfoflow extends Infoflow implements IInPlaceInfoflow {

        private IInfoflowCFG iCfg;
        public myInPlaceInfoflow(String androidPath, boolean forceAndroidJar, BiDirICFGFactory icfgFactory, Collection<SootMethod> additionalEntryPointMethods) {
            super(androidPath, forceAndroidJar, icfgFactory);
            this.additionalEntryPointMethods = additionalEntryPointMethods;
        }

        public void runAnalysis(ISourceSinkManager sourcesSinks, SootMethod entryPoint) {
            this.dummyMainMethod = entryPoint;
            InfoflowPerformanceData performanceData = this.createPerformanceDataClass();

            try {
                this.results = new InfoflowResults();
                this.results.setPerformanceData(performanceData);
                if (this.config.getSolverConfiguration().getDataFlowSolver() == InfoflowConfiguration.DataFlowSolver.FlowInsensitive) {
                    this.config.setFlowSensitiveAliasing(false);
                    this.config.setEnableTypeChecking(false);
                    MySetupApplication.this.logger.warn("Disabled flow-sensitive aliasing because we are running with a flow-insensitive data flow solver");
                }
                this.config.printSummary();
                if (this.memoryWatcher != null) {
                    this.memoryWatcher.clearSolvers();
                    this.memoryWatcher = null;
                }

                this.memoryWatcher = new FlowDroidMemoryWatcher(this.results, this.config.getMemoryThreshold());
                Abstraction.initialize(this.config);
                long beforeCallgraph = System.nanoTime();
                this.constructCallgraph();
                performanceData.setCallgraphConstructionSeconds((int)Math.round((double)(System.nanoTime() - beforeCallgraph) / 1.0E9));
                MySetupApplication.this.logger.info(String.format("Callgraph construction took %d seconds", performanceData.getCallgraphConstructionSeconds()));
                if (sourcesSinks != null) {
                    sourcesSinks.initialize();
                }

                if (this.config.getCodeEliminationMode() != InfoflowConfiguration.CodeEliminationMode.NoCodeElimination) {
                    long currentMillis = System.nanoTime();
                    this.eliminateDeadCode(sourcesSinks);
                    MySetupApplication.this.logger.info("Dead code elimination took " + (double)(System.nanoTime() - currentMillis) / 1.0E9 + " seconds");
                }

                if (this.config.getCallgraphAlgorithm() != InfoflowConfiguration.CallgraphAlgorithm.OnDemand) {
                    MySetupApplication.this.logger.info("Callgraph has {} edges", Scene.v().getCallGraph().size());
                }

                this.iCfg = this.icfgFactory.buildBiDirICFG(this.config.getCallgraphAlgorithm(), this.config.getEnableExceptionTracking());

                performanceData.setTotalRuntimeSeconds((int)Math.round((double)(System.nanoTime() - beforeCallgraph) / 1.0E9));
                Runtime runtime = Runtime.getRuntime();
                int usedMemory =  (int)Math.round((double)(runtime.totalMemory() - runtime.freeMemory()) / 1000000.0);
                performanceData.updateMaxMemoryConsumption(usedMemory);
                MySetupApplication.this.logger.info(String.format("Data flow solver took %d seconds. Maximum memory consumption: %d MB", performanceData.getTotalRuntimeSeconds(), performanceData.getMaxMemoryConsumption()));
            } catch (Exception var9) {
                StringWriter stacktrace = new StringWriter();
                PrintWriter pw = new PrintWriter(stacktrace);
                var9.printStackTrace(pw);
                MySetupApplication.this.logger.error("Exception during data flow analysis", var9);
            }
            return;
        }

        protected boolean isUserCodeClass(String className) {
            String packageName = MySetupApplication.this.manifest.getPackageName() + ".";
            return super.isUserCodeClass(className) || className.startsWith(packageName);
        }

        public IInfoflowCFG getiCfg() {
            return this.iCfg;
        }
    }
    // add for iCfg
}
