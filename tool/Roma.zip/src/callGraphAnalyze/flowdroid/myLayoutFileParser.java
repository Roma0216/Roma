package src.callGraphAnalyze.flowdroid;

import soot.*;
import soot.jimple.infoflow.android.axml.AXmlAttribute;
import soot.jimple.infoflow.android.axml.AXmlHandler;
import soot.jimple.infoflow.android.axml.AXmlNode;
import soot.jimple.infoflow.android.axml.parsers.AXML20Parser;
import soot.jimple.infoflow.android.resources.ARSCFileParser;
import soot.jimple.infoflow.android.resources.IResourceHandler;
import soot.jimple.infoflow.android.resources.LayoutFileParser;
import soot.jimple.infoflow.android.resources.controls.AndroidLayoutControl;
import soot.jimple.infoflow.android.resources.controls.LayoutControlFactory;
import soot.util.HashMultiMap;
import soot.util.MultiMap;

import java.io.InputStream;
import java.util.Iterator;
import java.util.Map;
import java.util.Set;

public class myLayoutFileParser extends LayoutFileParser {

    private SootClass scViewGroup = null;
    private SootClass scView = null;
    private SootClass scWebView = null;
    private boolean loadOnlySensitiveControls = false;
    private LayoutControlFactory controlFactory = new LayoutControlFactory();
    private MultiMap<String, String> handlerAttribute = new HashMultiMap();

    public myLayoutFileParser(String packageName, ARSCFileParser resParser) {
        super(packageName, resParser);
    }

    public void parseLayoutFile(final String fileName) {
        Transform transform = new Transform("wjtp.lfp", new SceneTransformer() {
            protected void internalTransform(String phaseName, Map options) {
                parseLayoutFileDirect(fileName);
            }
        });
        PackManager.v().getPack("wjtp").add(transform);
    }

    public MultiMap<String, String> getHanderAttribute() {
        return handlerAttribute;
    }

    public void parseLayoutFileDirect(String fileName) {
        this.handleAndroidResourceFiles(fileName, (Set)null, new IResourceHandler() {
            public void handleResourceFile(String fileName, Set<String> fileNameFilter, InputStream stream) {
                if (fileName.startsWith("res/layout") || fileName.startsWith("res/navigation")) {
                    if (!fileName.endsWith(".xml")) {
                        logger.warn(String.format("Skipping file %s in layout folder...", fileName));
                    } else {
                        scViewGroup = Scene.v().getSootClassUnsafe("android.view.ViewGroup");
                        scView = Scene.v().getSootClassUnsafe("android.view.View");
                        scWebView = Scene.v().getSootClassUnsafe("android.webkit.WebView");
                        String entryClass = fileName.substring(0, fileName.lastIndexOf("."));
                        if (!packageName.isEmpty()) {
                            entryClass = packageName + "." + entryClass;
                        }

                        if (fileNameFilter != null) {
                            boolean found = false;
                            Iterator var6 = fileNameFilter.iterator();

                            while(var6.hasNext()) {
                                String s = (String)var6.next();
                                if (s.equalsIgnoreCase(entryClass)) {
                                    found = true;
                                    break;
                                }
                            }

                            if (!found) {
                                return;
                            }
                        }

                        try {
                            AXmlHandler handler = new AXmlHandler(stream, new AXML20Parser());
                            parseLayoutNode(fileName, handler.getDocument().getRootNode());
                        } catch (Exception var8) {
                            logger.error("Could not read binary XML file: " + var8.getMessage(), var8);
                        }

                    }
                }
            }
        });
    }

    private void parseLayoutNode(String layoutFile, AXmlNode rootNode) {
        if (rootNode.getTag() != null && !rootNode.getTag().isEmpty()) {
            String tname = rootNode.getTag().trim();
            if (!tname.equals("dummy")) {
                if (tname.equals("include")) {
                    parseIncludeAttributes(layoutFile, rootNode);
                } else if (!tname.equals("merge")) {
                    if (tname.equals("fragment")) {
                        AXmlAttribute<?> attr = rootNode.getAttribute("name");
                        if (attr == null) {
                            this.logger.warn("Fragment without class name or id detected");
                        } else if (rootNode.getAttribute("navGraph") != null) {
                            parseIncludeAttributes(layoutFile, rootNode);
                        } else {
                            addFragment(layoutFile, getLayoutClass(attr.getValue().toString()));
                            if (attr.getType() != 3) {
                                this.logger.warn("Invalid target resource " + attr.getValue() + "for fragment class value");
                            }

                            getLayoutClass(attr.getValue().toString());
                        }
                    } else {
                        SootClass childClass = getLayoutClass(tname);
                        if (childClass != null && (isLayoutClass(childClass) || isViewClass(childClass))) {
                            parseLayoutAttributes(layoutFile, childClass, rootNode);
                        }
                    }
                }
            }

            Iterator var7 = rootNode.getChildren().iterator();

            while(var7.hasNext()) {
                AXmlNode childNode = (AXmlNode)var7.next();
                this.parseLayoutNode(layoutFile, childNode);
            }

        } else {
            this.logger.warn("Encountered a null or empty node name in file %s, skipping node...", layoutFile);
        }
    }

    private void parseIncludeAttributes(String layoutFile, AXmlNode rootNode) {
        Iterator var3 = rootNode.getAttributes().entrySet().iterator();

        while(true) {
            AXmlAttribute attr;
            do {
                String attrName;
                do {
                    do {
                        Map.Entry entry;
                        do {
                            do {
                                if (!var3.hasNext()) {
                                    return;
                                }

                                entry = (Map.Entry)var3.next();
                                attrName = (String)entry.getKey();
                            } while(attrName == null);
                        } while(attrName.isEmpty());

                        attrName = attrName.trim();
                        attr = (AXmlAttribute)entry.getValue();
                    } while(!attrName.equals("layout") && !attrName.equals("navGraph"));
                } while(attr.getType() != 1 && attr.getType() != 17);
            } while(!(attr.getValue() instanceof Integer));

            ARSCFileParser.AbstractResource targetRes = this.resParser.findResource((Integer)attr.getValue());
            if (targetRes == null) {
                this.logger.warn("Target resource " + attr.getValue() + " for layout include not found");
                return;
            }

            if (!(targetRes instanceof ARSCFileParser.StringResource)) {
                this.logger.warn(String.format("Invalid target node for include tag in layout XML, was %s", targetRes.getClass().getName()));
                return;
            }

            String targetFile = ((ARSCFileParser.StringResource)targetRes).getValue();
            if (this.callbackMethods.containsKey(targetFile)) {
                Iterator var9 = this.callbackMethods.get(targetFile).iterator();

                while(var9.hasNext()) {
                    String callback = (String)var9.next();
                    addCallbackMethod(layoutFile, callback);
                }
            } else {
                this.includeDependencies.put(targetFile, layoutFile);
            }
        }
    }

    private void addFragment(String layoutFile, SootClass fragment) {
        if (fragment != null) {
            layoutFile = layoutFile.replace("/layout-large/", "/layout/");
            this.fragments.put(layoutFile, fragment);
            if (this.includeDependencies.containsKey(layoutFile)) {
                Iterator var3 = this.includeDependencies.get(layoutFile).iterator();

                while(var3.hasNext()) {
                    String target = (String)var3.next();
                    this.addFragment(target, fragment);
                }
            }

        }
    }

    private SootClass getLayoutClass(String className) {
        if (className.startsWith(";")) {
            className = className.substring(1);
        }

        if (!className.contains("(") && !className.contains("<") && !className.contains("/")) {
            SootClass sc = Scene.v().forceResolve(className, 3);
            if ((sc == null || sc.isPhantom()) && !this.packageName.isEmpty()) {
                sc = Scene.v().forceResolve(this.packageName + "." + className, 3);
            }

            if (!isRealClass(sc)) {
                sc = Scene.v().forceResolve("android.view." + className, 3);
            }

            if (!isRealClass(sc)) {
                sc = Scene.v().forceResolve("android.widget." + className, 3);
            }

            if (!isRealClass(sc)) {
                sc = Scene.v().forceResolve("android.webkit." + className, 3);
            }

            return !isRealClass(sc) ? null : sc;
        } else {
            this.logger.warn("Invalid class name %s", className);
            return null;
        }
    }

    private boolean isLayoutClass(SootClass theClass) {
        return theClass != null && Scene.v().getOrMakeFastHierarchy().canStoreType(theClass.getType(), this.scViewGroup.getType());
    }

    private boolean isViewClass(SootClass theClass) {
        if (theClass == null) {
            return false;
        } else if (Scene.v().getOrMakeFastHierarchy().canStoreType(theClass.getType(), this.scView.getType())) {
            return true;
        } else if (Scene.v().getOrMakeFastHierarchy().canStoreType(theClass.getType(), this.scWebView.getType())) {
            return true;
        } else {
            this.logger.warn(String.format("Layout class %s is not derived from android.view.View", theClass.getName()));
            return false;
        }
    }

    private void parseLayoutAttributes(String layoutFile, SootClass layoutClass, AXmlNode rootNode) {
        AndroidLayoutControl lc = controlFactory.createLayoutControl(layoutFile, layoutClass, rootNode);
        if (lc.getClickListener() != null) {
            addCallbackMethod(layoutFile, lc.getClickListener());
            int id = lc.getID();
            if (id != -1)
                this.handlerAttribute.put(lc.getClickListener(), String.valueOf(lc.getID()));
        }

        if (!loadOnlySensitiveControls || lc.isSensitive()) {
            this.userControls.put(layoutFile, lc);
        }

    }

    private void addCallbackMethod(String layoutFile, String callback) {
        layoutFile = layoutFile.replace("/layout-large/", "/layout/");
        this.callbackMethods.put(layoutFile, callback);
        if (this.includeDependencies.containsKey(layoutFile)) {
            Iterator var3 = this.includeDependencies.get(layoutFile).iterator();

            while(var3.hasNext()) {
                String target = (String)var3.next();
                this.addCallbackMethod(target, callback);
            }
        }

    }

    private boolean isRealClass(SootClass sc) {
        if (sc == null) {
            return false;
        } else {
            return !sc.isPhantom() || sc.getMethodCount() != 0 || sc.getFieldCount() != 0;
        }
    }
}
